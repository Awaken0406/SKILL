# -*- coding: utf-8 -*-
"""
把 config.json（研判文本）+ futures.json（期指持仓）转成可直接推送微信的 Markdown 摘要。

用法:
    python report_to_md.py --config config.json --futures futures.json --out push.md

设计要点:
  - 数字一律取自脚本产物（futures.json 的持仓手数、config 的 ladder/events），
    不靠模型二次手抄，避免推送内容与实际数据不一致。
  - config 里的 HTML 片段（<b> / <span class="up">）会降级为 Markdown，Server酱可正常渲染。
  - 第二章 2.1/2.2 已从报告模板移除，这里同步只输出「点位阶梯 + 盘中变量」。
"""
import argparse
import html as html_lib
import json
import re


def h2m(html):
    """极简 HTML → Markdown：保留粗体与段落，其余标签脱壳。"""
    if not html:
        return ""
    s = str(html)
    s = re.sub(r"<br\s*/?>", "\n", s)
    s = re.sub(r"<p[^>]*>", "", s)
    s = s.replace("</p>", "\n\n")
    s = re.sub(r"<b>(.*?)</b>", r"**\1**", s, flags=re.S)
    s = re.sub(r"<span[^>]*>(.*?)</span>", r"\1", s, flags=re.S)
    s = re.sub(r"<[^>]+>", "", s)
    s = re.sub(r"[ \t]+\n", "\n", s)
    s = re.sub(r"\n{3,}", "\n\n", s)
    # 去标签后再反转义：config 里存的 &gt; &amp; 等实体需还原成可读字符
    # （顺序不能反，先 unescape 会让转义出的 < > 被当成标签删掉）
    return re.sub(r"\n{3,}", "\n\n", html_lib.unescape(s).replace("\xa0", " ")).strip()


def table(head, rows):
    if not rows:
        return ""
    out = ["| " + " | ".join(str(c) for c in head) + " |",
           "|" + "|".join(["---"] * len(head)) + "|"]
    for r in rows:
        out.append("| " + " | ".join(h2m(c).replace("\n", " ") for c in r) + " |")
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--futures", default=None, help="futures_position.py 输出，可选")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    cfg = json.load(open(args.config, "r", encoding="utf-8"))
    fut = json.load(open(args.futures, "r", encoding="utf-8")) if args.futures else None

    P = []
    P.append("# " + cfg.get("title", "大盘指数复盘与推演"))
    sub = cfg.get("subtitle", "")
    if sub:
        P.append("> " + h2m(sub).replace("\n", " "))

    # --- 结论 ---
    tldr = cfg.get("tldr") or []
    if tldr:
        P.append("\n## 结论先行\n")
        for p in tldr:
            t = h2m(p)
            if t:
                P.append(t + "\n")

    badges = cfg.get("badges") or []
    if badges:
        P.append("**" + "　·　".join("%s" % b[0] for b in badges) + "**\n")

    # --- 核心指标 ---
    kpi = cfg.get("kpi") or []
    if kpi:
        P.append("\n## 核心指标\n")
        P.append(table(["指标", "数值", "说明"],
                       [[k.get("lb", ""), h2m(k.get("vl", "")), h2m(k.get("ex", ""))]
                        for k in kpi]))

    # --- 期指席位持仓 ---
    if fut:
        meta = fut.get("meta", {})
        vd = fut.get("verdict", {})
        P.append("\n## 股指期货席位持仓（%s）\n" % meta.get("date", ""))
        for label, k in (("中信期货席位", "seat_main"), ("机构整体", "inst_main")):
            v = vd.get(k)
            if v:
                P.append("- **%s：%s**" % (label, v["text"]))
        seat = fut.get("seat", {})
        mains = meta.get("main_contract", {})
        bp = seat.get("by_product", {})
        if bp:
            rows = []
            for p, r in bp.items():
                o = r.get("main", {})
                rows.append(["%s %s" % (p, r.get("cn", "")), mains.get(p, "-"),
                             "{:,}".format(o.get("long", 0)), "{:,}".format(o.get("short", 0)),
                             "{:,}".format(o.get("net", 0)), "%+d" % o.get("d_net", 0)])
            t = seat.get("total_main", {})
            rows.append(["**合计**", "—", "**{:,}**".format(t.get("long", 0)),
                         "**{:,}**".format(t.get("short", 0)),
                         "**{:,}**".format(t.get("net", 0)), "**%+d**" % t.get("d_net", 0)])
            P.append("\n中信席位（%s）· 主力合约\n" % seat.get("name", ""))
            P.append(table(["品种", "合约", "多单", "空单", "净持仓", "净变动"], rows))
        note = cfg.get("futures", {}).get("note") or fut.get("hint", "")
        if note:
            P.append("\n" + h2m(note) + "\n")

    # --- 关键点位阶梯（2.3） ---
    ladder = cfg.get("ladder") or []
    if ladder:
        P.append("\n## 关键点位阶梯\n")
        P.append(table(["点位", "性质", "说明"],
                       [[px, tag, desc] for px, tag, _k, desc in ladder]))

    # --- 盘中变量（2.4） ---
    ev = cfg.get("events") or {}
    if ev.get("rows"):
        P.append("\n## 盘中变量\n")
        P.append(table(ev.get("head", ["变量", "说明"]), ev["rows"]))
        if ev.get("note"):
            P.append("\n" + h2m(ev["note"]) + "\n")

    # --- 条件化决策 ---
    dec = cfg.get("decisions") or {}
    if dec.get("rows"):
        P.append("\n## 条件化决策\n")
        P.append(table(dec.get("head", ["触发条件", "含义", "应对"]), dec["rows"]))

    # --- 风险 ---
    risks = cfg.get("risks") or []
    if risks:
        P.append("\n## 反向声音与风险\n")
        for r in risks:
            P.append("- " + h2m(r).replace("\n", " "))

    # --- 来源与免责 ---
    src = cfg.get("sources") or []
    if src:
        P.append("\n## 数据来源\n")
        for s in src:
            P.append("- " + h2m(s))

    P.append("\n---\n*以上内容基于公开数据与量化分析，仅供参考，不构成投资建议。市场有风险，投资需谨慎。*")

    md = "\n".join(P)
    with open(args.out, "w", encoding="utf-8") as f:
        f.write(md)
    print("WROTE %s (%d chars)" % (args.out, len(md)))
    if len(md) > 32000:
        print("[warn] 超过 Server酱 32KB 上限，建议精简后推送")


if __name__ == "__main__":
    main()
