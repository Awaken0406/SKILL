# 主线板块 universe 码与扫描参数

## 0. 扫描范围总则（2026-08-25 更新）

**默认模式 = 全市场扫描**：`tool_ranking` 不传 `universe` 参数，一次调用扫全 A 股（limit=400 ≥ totalStocks）。实测 ma_long 全市场命中 322 只，远多于下方 8 板块合计约 60 只，且覆盖黄金/煤炭/航运/银行等"趋势强+低估值"品种（8 板块模式会漏掉）。

**可选对照模式（主线板块）**：仅当用户明确要求"只扫主线板块"时，才使用下方第 1 节的 8 个 universe 码逐板块调用。默认不使用。


## 0. 扫描范围总则（2026-08-25 更新）

**默认模式 = 全市场扫描**：`tool_ranking` 不传 `universe` 参数，一次调用扫全 A 股（limit=400 ≥ totalStocks）。实测 ma_long 全市场命中 322 只，远多于下方 8 板块合计约 60 只，且覆盖黄金/煤炭/航运/银行等"趋势强+低估值"品种（8 板块模式会漏掉）。

**可选对照模式（主线板块）**：仅当用户明确要求"只扫主线板块"时，才使用下方第 1 节的 8 个 universe 码逐板块调用。默认不使用。


本文件给出「定向扫描」的固定输入：8 个主线板块的 universe 码 + 策略名 + 主板/非ST 过滤规则。码若失效或需扩围，用 `data_sector` / `data_hot`(kind=board) 重新拉取最新板块码替换即可。

## 1. 八条主线板块 universe 码

| 板块 | universe 码 |
|------|-------------|
| 半导体 | pt01801081 |
| 光学光电子 | pt01801084 |
| 通信设备 | pt01801102 |
| 人形机器人 | pt02GN2238 |
| 元件 | pt01801083 |
| 存储器 | pt02GN2124 |
| 汽车零部件 | pt01801093 |
| 通用设备 | pt01801156 |

> 以上覆盖 AI算力/光模块/CPO、人形机器人、半导体国产替代、汽车智能化等当前核心主线。可按用户关注方向增删。

## 2. 策略名

- 干净多头策略：`ma_long`（与 `tool_ranking` 的 `within_strategy` 参数对应）
- 先用 `tool_list_strategies` 确认 `ma_long` 可用且非付费 unavailable；若改名以接口返回为准。

## 3. 主板 / 非ST 过滤规则

`tool_ranking(universe=板块码, within_strategy=ma_long)` 返回的是该板块内命中策略的全部股票，需二次过滤：

**保留（主板非ST）**：
- 沪市主板：`sh60xxxx`（60 开头）
- 深市主板：`sz000xxx` / `sz001xxx` / `sz002xxx` / `sz003xxx`

**剔除**：
- 科创板：`sh688xxx`
- 创业板：`sz300xxx` / `sz301xxx`
- ST / *ST：名称或代码含 ST 标记

> 目的：只保留主板、非 ST 的干净多头标的，规避涨跌停限制差异与退市风险。

## 4. 扫描路径（标准执行序）

```
for 每个板块码 in [8个主线码]:
    tool_ranking(metric=CompScore, universe=板块码, within_strategy=ma_long, order=desc, limit=50)
汇总 8 次结果 -> 去重 -> 候选池
候选池 -> 主板非ST过滤 -> 最终候选（典型 10–20 只）
对每只最终候选:
    并行 data_quote / data_technical(ma,kdj,macd,rsi) / data_kline(day,qfq,limit=120)
    -> 按 scoring.md 六维精算购买指数
-> 纯文本汇总表 + 90+ 稀缺根因说明
```

## 5. metric 取值说明

- 默认用 `CompScore`（综合评分）作为排行指标；若不确定可用 `tool_list_ranking_metrics` 列出股票类可用指标再选。
- `within_strategy` 与 `within_label` / `within_event` 互斥，扫描只用 `within_strategy=ma_long`。
- `date` 默认今天；复盘历史日可传 `YYYY-MM-DD`。
