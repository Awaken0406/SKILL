# 主线板块 universe 码与扫描参数

本文件给出「定向扫描」的固定输入：8 个主线板块的 universe 码 + 策略名 + 主板/非ST 过滤规则。码若失效或需扩围，用 `data_sector` / `data_hot`(kind=board) 重新拉取最新板块码替换即可。

## 1. 八条主线板块 universe 码

| 板块 | universe 码 |
|------|-------------|
| 半导体 | pt01801081 |
| 光学光电子 | pt01801084 |
| 通信设备 | pt01801102 |
| 人形机器人 | pt02GN2238 |
| 元件 | pt01801083 |
| 存储器 | pt02GN2124 |
| 汽车零部件 | pt01801093 |
| 通用设备 | pt01801156 |

> 以上覆盖 AI算力/光模块/CPO、人形机器人、半导体国产替代、汽车智能化等当前核心主线。可按用户关注方向增删。

## 2. 策略名与人气热度通道

- 干净多头策略：`ma_long`（与 `tool_ranking` 的 `within_strategy` 参数对应）
- 先用 `tool_list_strategies` 确认 `ma_long` 可用且非付费 unavailable；若改名以接口返回为准。

**人气热度前50固定通道**（每次扫描必调）：

```
data_hot(kind=stock, limit=50)
```

- 返回场内人气热度榜前50（逐日更新），解析出股票代码 + 人气排名。
- **不受干净多头(ma_long)条件限制**：热度股无论趋势/形态一律入池，交由六维评分与否决规则去劣汰。
- 与主线多头通道按代码去重合并，重叠股来源标注"热度+多头"。
- `kind=stock` 为个股人气榜；`board` 为板块热度，不要混用。

## 3. 主板 / 非ST 过滤规则

`tool_ranking(universe=板块码, within_strategy=ma_long)` 返回的是该板块内命中策略的全部股票，需二次过滤：

**保留（主板非ST）**：
- 沪市主板：`sh60xxxx`（60 开头）
- 深市主板：`sz000xxx` / `sz001xxx` / `sz002xxx` / `sz003xxx`

**剔除**：
- 科创板：`sh688xxx`
- 创业板：`sz300xxx` / `sz301xxx`
- ST / *ST：名称或代码含 ST 标记

> 目的：只保留主板、非 ST 的标的，规避涨跌停限制差异与退市风险。该过滤对**两条通道（主线多头 + 人气热度）统一生效**——人气前50中的创业板/科创板/ST 票同样剔除。

## 4. 扫描路径（标准执行序）

```
通道A（主线多头）:
for 每个板块码 in [8个主线码]:
    tool_ranking(metric=CompScore, universe=板块码, within_strategy=ma_long, order=desc, limit=50)
汇总 8 次结果 -> 去重 -> 通道A候选池
通道B（人气热度，固定必调，不受 ma_long 限制）:
    data_hot(kind=stock, limit=50) -> 解析代码+人气排名 -> 通道B候选池
通道A ∪ 通道B -> 按代码去重合并（保留人气排名与来源通道）
-> 主板非ST过滤 -> 最终候选（典型 15–40 只，热度通道显著扩池）
对每只最终候选:
    并行 data_quote / data_technical(ma,kdj,macd,rsi) / data_kline(day,qfq,limit=120)
    -> 按 scoring.md 六维精算购买指数
-> 纯文本汇总表（含来源通道/人气排名列 + 「热门但不买」名单）+ 90+ 稀缺根因说明
```

## 5. metric 取值说明

- 默认用 `CompScore`（综合评分）作为排行指标；若不确定可用 `tool_list_ranking_metrics` 列出股票类可用指标再选。
- `within_strategy` 与 `within_label` / `within_event` 互斥，扫描只用 `within_strategy=ma_long`。
- `date` 默认今天；复盘历史日可传 `YYYY-MM-DD`。
