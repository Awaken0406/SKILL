#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
筹码峰 HTML 报告渲染器

用法:
  python gen_chip_html.py --result chip_result.json --name 小商品城 --code sh600415 \
      --out "D:/Stock/小商品城_筹码峰分析.html"

参数:
  --result  chip_peak.py 输出的 JSON
  --name    股票名称
  --code    股票代码
  --out     输出 HTML 路径
  --note    可选的自定义结论段落（会追加在报告末尾"补充说明"卡片中）
"""
import argparse
import json


def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def gen_interpretation(D, close, st, off, peaks, main_peak, prices, chip, V_LO, V_HI, hist):
    """数据驱动的「筹码峰解读与评价」章节（自动从 chip_result.json 推算，不写死个股）。"""
    c70l, c70u = st["c70"][1], st["c70"][2]
    c90l, c90u = st["c90"][1], st["c90"][2]

    def dens(lo, hi):
        return sum(c for c, p in zip(chip, prices) if lo <= p <= hi) * 100

    density_now = dens(close - 0.08, close + 0.08)
    span90 = c90u - c90l
    close_pct90 = (close - c90l) / span90 * 100 if span90 > 0 else 0
    in70 = c70l <= close <= c70u
    in90 = c90l <= close <= c90u
    vac = dens(close, c70u)          # 现价→70%上沿：真空带
    wall = dens(c70u, c90u)          # 70%上沿→90%上沿：套牢墙
    support_peaks = [(p, d) for p, d in peaks if p <= close and p >= close * 0.93]
    support_band = "、".join(f"{p:.2f}" for p, d in support_peaks) if support_peaks else f"{main_peak:.2f}"
    main_gap = (main_peak / close - 1) * 100
    close_above_main = close > main_peak

    # ---- 主峰迁移 ----
    mig_dir = mig_mag = None
    mig_trail = ""
    profit_old = None
    if hist:
        seq_names = sorted(hist.keys(), key=lambda k: -int(k.replace("日前", "")))
        seq = [hist[k]["peaks"][0][0] for k in seq_names if hist[k].get("peaks")] + [main_peak]
        oldest_name = seq_names[-1]
        profit_old = hist[oldest_name]["profit"]
        mig_dir = "下移" if seq[-1] < seq[0] else ("上移" if seq[-1] > seq[0] else "持平")
        mig_mag = abs(seq[-1] - seq[0])
        mig_trail = " → ".join(f"{x:.2f}" for x in seq)

    # ---- 迁移评价 ----
    if mig_dir == "下移":
        if st["profit"] >= 50 and close_above_main:
            mig_verdict, mig_desc = "结构改善（偏多）", (
                "高位套牢盘被较长时间换手消化、筹码重心下沉，且现价已爬回主峰之上、多数持仓盈利"
                "——这是低位换筹、结构改善的信号。")
        elif st["profit"] < 40:
            mig_verdict, mig_desc = "重心崩塌（偏空）", (
                "主峰随价格一起下沉、获利盘偏低，每破一个平台就新增一批套牢盘，"
                "是下跌趋势的特征，不是换筹。")
        else:
            mig_verdict, mig_desc = "中性", "主峰下移但获利盘中等，改善与抛压并存，需结合主峰是否被守住判断。"
    elif mig_dir == "上移":
        if st["profit"] >= 50 and close_above_main:
            mig_verdict, mig_desc = "中性偏多", (
                "新资金在更高位接盘、且现价站上主峰，筹码重心上抬、上行基础夯实；"
                "但高位追涨盘本身也是后续潜在套牢来源，需防冲高回落。")
        elif st["profit"] < 40:
            mig_verdict, mig_desc = "高位套牢（偏空）", (
                "主峰上移但获利盘偏低，说明高位接盘者多数已套，是冲高回落后的被动换筹。")
        else:
            mig_verdict, mig_desc = "中性", "主峰上抬、获利盘中等，方向待确认。"
    else:
        mig_verdict, mig_desc = "中性", "主峰基本持平，筹码结构稳定，无明确迁移信号。"

    caveat = ""
    if mig_dir == "下移" and st["profit"] >= 60:
        caveat = (f"<b>双刃剑：</b>主峰下移 + 浮盈盘高度集中（获利盘 {st['profit']:.0f}%），"
                  "一旦回踩到主峰带这批人容易一起获利了结形成抛压；"
                  "“结构改善”和“潜在抛压”是同一件事的两面，不能只说一半。")

    # ---- 综合评级 ----
    score = 0
    signals = []
    if close_above_main:
        score += 1
        signals.append(f"现价 {close:.2f} 站上主峰 {main_peak:.2f}（多头占优）")
    if st["profit"] >= 50:
        score += 1
        signals.append(f"获利盘 {st['profit']:.0f}% 占多数")
    if mig_dir == "下移" and st["profit"] >= 50:
        score += 1
        signals.append("主峰下移且获利盘抬升 = 结构改善")
    if mig_dir == "上移" and st["profit"] >= 50:
        signals.append("主峰上移且获利盘抬升 = 重心上抬")
    if mig_dir in ("下移", "上移") and st["profit"] < 40:
        score -= 2
        signals.append(f"获利盘仅 {st['profit']:.0f}%（换筹/套牢信号）")
    if hist:
        oldest_c70 = hist[sorted(hist.keys(), key=lambda k: -int(k.replace("日前", "")))[-1]]["c70"]
        if oldest_c70 - st["c70"][0] > 1.5:
            signals.append(f"集中度70 由 {oldest_c70:.1f} 收窄至 {st['c70'][0]:.1f}（单峰密集，方向选择临近）")
    rating = "中性偏多" if score >= 2 else ("中性偏空" if score <= -1 else "中性")

    # ---- 可信度 ----
    if off:
        tol = [("平均成本", st["avg"], off["avg"], 0.5),
               ("获利盘 %", st["profit"], off["profit"], 3.0),
               ("集中度70", st["c70"][0], off["c70"], 1.0),
               ("集中度90", st["c90"][0], off["c90"], 3.0)]
        bad = sum(1 for n_, mv, ov, t in tol if abs(mv - ov) >= t)
        bad_items = [n_ for n_, mv, ov, t in tol if abs(mv - ov) >= t]
        if bad == 0:
            rel = "四项交叉验证全部落在容差内，重建分布基本可信，峰位与迁移方向可作决策参考。"
        elif bad == 1:
            rel = (f"4 项中有 <b>1 项超差</b>（{esc('、'.join(bad_items))}），重建整体仍可用，"
                   "但峰位细节以官方口径为准；不要将该超差项当精确值。")
        else:
            rel = (f"4 项中有 <b>{bad} 项超差</b>（{esc('、'.join(bad_items))}），"
                   "重建质量存疑，结论请谨慎使用，优先检查 K 线复权/换手率是否缺失。")
    else:
        bad = None
        rel = "未提供官方筹码口径（--official），无法交叉验证，本评价仅基于重建模型，请谨慎使用。"

    # ---- 组装各小节 ----
    terrain = (f"现价 <b>{close:.2f}</b> 落在 70% 筹码区间 <b>{c70l:.2f}–{c70u:.2f}</b>"
               f"{'（区间内）' if in70 else '（区间外）'}、90% 区间 <b>{c90l:.2f}–{c90u:.2f}</b> 的"
               f"约 <b>{close_pct90:.0f}%</b> 分位。但现价 ±0.08 元内筹码堆积仅 <b>{density_now:.1f}%</b>"
               + ("——<b>现价悬空</b>：既缺乏就地支撑、也缺乏就地阻力，上不挨峰、下临主峰带。"
                  if density_now < 4 else "，就地有一定筹码基础。"))
    if off:
        terrain += (f" 重建均本 {st['avg']:.2f} 与官方均本 {off['avg']:.2f} "
                    f"{'基本吻合' if abs(st['avg'] - off['avg']) < 0.5 else '存在偏差（以官方为准）'}。")

    support_txt = (f"<b>下方最硬支撑 = 主峰带 {support_band}</b>"
                   f"（{'低于' if main_gap < 0 else '高于'}现价约 {abs(main_gap):.0f}%，"
                   f"与{'官方均本 ' + format(off['avg'], '.2f') if off else '持仓重心'}共振）。"
                   f"该带上方至现价之间是<b>筹码真空</b>（合计约 {vac:.1f}%），上行阻力小但回落会直接滑向主峰；"
                   f"上方 <b>{c70u:.2f}–{c90u:.2f}</b> 是约 <b>{wall:.1f}%</b> 的<b>套牢墙</b>，"
                   "不是真空——突破需持续放量穿过。")

    trade = (f"理想买点 = <b>回踩主峰带 {support_band} 不破</b>（与官方均本共振，多头最可能接盘处）；"
             f"放量站稳 <b>{c70u:.2f}</b>（70% 上沿）才打开向 {c90u:.2f} 套牢区的空间；"
             f"<b>有效跌破 {main_peak:.2f} 主峰</b> = 转弱信号，下方看 "
             f"{c70l:.2f}（70% 下沿）/ {c90l:.2f}（90% 下沿）。"
             + (" 现价悬空、不宜直接追涨。" if density_now < 4 else ""))

    mig_block = (f"主峰迁移轨迹：<b>{mig_trail}</b>（{oldest_name if hist else ''}至今），"
                 f"整体<b>{mig_dir} {mig_mag:.2f} 元</b>。评价：<b>{mig_verdict}</b>——{mig_desc}"
                 + (f"<br>{caveat}" if caveat else "")) if hist else "无历史快照，无法评价主峰迁移。"

    rating_block = f"综合评级：<b>{rating}</b>。依据：" + "；".join(esc(s) for s in signals) + "。"

    reliability = (f"可信度：{rel}"
                   "<b style='color:#e05252'> 必须保留的提醒：</b>本模型为三角形分布 + 线性衰减的近似推算，"
                   "未区分主动买卖方向、未计入大宗/解禁，与券商终端筹码图存在数个百分点差异；"
                   "看峰位与迁移方向够用，<b>不能当精确持仓成本使用</b>。")

    return f'''<div class="card"><h2>筹码峰解读与评价</h2>

<div class="find"><b>① 现价筹码地形：</b>{terrain}</div>

<div class="find"><b>② 支撑 / 压力定位：</b>{support_txt}</div>

<div class="find"><b>③ 主峰迁移评价：</b>{mig_block}</div>

<div class="find"><b>④ 交易含义：</b>{trade}</div>

<div class="find"><b>⑤ 综合评级与可信度：</b>{rating_block}<br>{reliability}</div>

</div>'''


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--result", required=True)
    ap.add_argument("--name", required=True)
    ap.add_argument("--code", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--note", default="")
    a = ap.parse_args()

    D = json.load(open(a.result, encoding="utf-8"))
    prices, chip = D["prices"], D["chip"]
    close, st, off = D["last_close"], D["stats"], D["official"]
    peaks, hist = D["peaks"], D.get("hist", {})
    V_LO, V_HI = D.get("view_lo", min(prices)), D.get("view_hi", max(prices))
    main_peak = peaks[0][0] if peaks else close

    idx = [i for i, p in enumerate(prices) if V_LO <= p <= V_HI]
    vis_max = max(chip[i] for i in idx) or 1e-12
    tail_hi = sum(c for c, p in zip(chip, prices) if p > V_HI) * 100
    tail_lo = sum(c for c, p in zip(chip, prices) if p < V_LO) * 100

    # ---------------- SVG 1: 横向筹码峰图 ----------------
    W, H = 980, 660
    XL, XR, YT, YB = 78, 900, 46, 612

    def py(p):
        return YB - (p - V_LO) / (V_HI - V_LO) * (YB - YT)

    def px(d):
        return XL + d / vis_max * (XR - XL)

    bars = []
    for i in idx:
        p, d = prices[i], chip[i]
        if d <= 0:
            continue
        y = py(p)
        col = "#e05252" if p < close else "#4d7fd6"
        op = 0.42 if p < close else 0.55
        bars.append(f'<line x1="{XL}" y1="{y:.1f}" x2="{px(d):.1f}" y2="{y:.1f}" '
                    f'stroke="{col}" stroke-width="1.9" opacity="{op:.2f}"/>')

    grid, labels = [], []
    step_g = max(round((V_HI - V_LO) / 14 * 2) / 2, 0.5)
    gp = round(V_LO / step_g) * step_g
    while gp <= V_HI + 1e-9:
        y = py(gp)
        grid.append(f'<line x1="{XL}" y1="{y:.1f}" x2="{XR}" y2="{y:.1f}" stroke="#2a3040" stroke-width="1"/>')
        labels.append(f'<text x="{XL-10}" y="{y+4:.1f}" text-anchor="end" fill="#8b93a7" '
                      f'font-size="12" font-family="ui-monospace,Consolas,monospace">{gp:.2f}</text>')
        gp += step_g

    def refline(p, color, text, dash="5,4", op=0.95):
        y = py(p)
        return (f'<line x1="{XL}" y1="{y:.1f}" x2="{XR}" y2="{y:.1f}" stroke="{color}" '
                f'stroke-width="1.6" stroke-dasharray="{dash}" opacity="{op}"/>'
                f'<text x="{XR+6}" y="{y+4:.1f}" fill="{color}" font-size="12.5" '
                f'font-weight="600">{esc(text)}</text>')

    refs = [refline(close, "#ffffff", f"现价 {close:.2f}", "6,3")]
    refs.append(refline(st["avg"], "#f0b429", f"模型均本 {st['avg']:.2f}", "5,4"))
    if off:
        refs.append(refline(off["avg"], "#6b7280", f"官方均本 {off['avg']:.2f}", "2,3", 0.8))

    marks = []
    for rank, (p, _) in enumerate(peaks[:4], 1):
        if not (V_LO <= p <= V_HI):
            continue
        y = py(p)
        i = min(range(len(prices)), key=lambda k: abs(prices[k] - p))
        x2 = px(chip[i])
        c = "#ffd166" if rank == 1 else "#9aa4b8"
        marks.append(f'<circle cx="{x2:.1f}" cy="{y:.1f}" r="4" fill="{c}" stroke="#12151c" stroke-width="1.5"/>'
                     f'<text x="{x2+9:.1f}" y="{y+4:.1f}" fill="{c}" font-size="12.5" '
                     f'font-weight="700">峰{rank} {p:.2f}</text>')

    svg1 = f'''<svg viewBox="0 0 {W} {H}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="system-ui,-apple-system,'Segoe UI',sans-serif">
<rect width="{W}" height="{H}" fill="#12151c"/>
<text x="{XL}" y="26" fill="#e6e9f0" font-size="15" font-weight="700">筹码分布（横向峰位图）</text>
<text x="{XL+230}" y="26" fill="#7c8496" font-size="12.5">红=获利盘 / 蓝=套牢盘 · 条越长表示该价位筹码越密集</text>
{''.join(grid)}{''.join(labels)}
<line x1="{XL}" y1="{YB}" x2="{XR}" y2="{YB}" stroke="#3a4256" stroke-width="1.5"/>
{''.join(bars)}
{''.join(refs)}
{''.join(marks)}
<text x="{XL}" y="{H-14}" fill="#6b7280" font-size="11.5">注：显示区间 {V_LO}~{V_HI}；区间下方另有 {tail_lo:.1f}% 筹码，上方另有 {tail_hi:.1f}%</text>
</svg>'''

    # ---------------- SVG 2: 峰迁移曲线 ----------------
    W2, H2, X2L, X2R, Y2T, Y2B = 980, 340, 78, 900, 54, 286

    def sm(arr, w=6):
        return [sum(arr[max(0, i-w):min(len(arr), i+w+1)]) / len(arr[max(0, i-w):min(len(arr), i+w+1)])
                for i in range(len(arr))]

    def x2p(p):
        # 横轴反向：左=高价，右=低价（与上方峰位图"上高下低"的方向一致，便于两图对照）
        return X2L + (V_HI - p) / (V_HI - V_LO) * (X2R - X2L)

    curves_src = [("当前", sm(chip), "#e05252", 3.0, "")]
    palette = ["#4d7fd6", "#f0932b", "#6b7280", "#3ecf8e"]
    for n, (k, v) in enumerate(sorted(hist.items(),
                                      key=lambda kv: -int(kv[0].replace("日前", "")))):
        curves_src.append((k, sm(v["chip"]), palette[n % len(palette)], 1.9, "5,3"))

    allc = [c for _, c, _, _, _ in curves_src]
    gmax = max(max(c[i] for i in idx) for c in allc) or 1e-12

    def path(sarr, color, width, dash):
        pts = [f"{x2p(prices[i]):.1f},{Y2B - sarr[i]/gmax*(Y2B-Y2T):.1f}" for i in idx[::2]]
        return (f'<polyline points="{" ".join(pts)}" fill="none" stroke="{color}" '
                f'stroke-width="{width}" stroke-dasharray="{dash}" opacity="0.95"/>')

    drawn = "".join(path(c, col, w, d) for _, c, col, w, d in reversed(curves_src))

    # 现价竖线标签：靠右侧时改放左边，避免溢出画布
    xc = x2p(close)
    cplabel = (f'<text x="{xc-7:.1f}" y="{Y2T+14}" text-anchor="end" fill="#ffffff" font-size="12">'
               f'现价 {close:.2f}</text>') if xc > (X2L + X2R) / 2 else (
              f'<text x="{xc+7:.1f}" y="{Y2T+14}" fill="#ffffff" font-size="12">'
               f'现价 {close:.2f}</text>')

    g2, l2 = [], []
    gs = max(round((V_HI - V_LO) / 7), 1)
    gp = round(V_HI / gs) * gs          # 从高价端起，向左→右递减
    while gp >= V_LO - 1e-9:
        x = x2p(gp)
        g2.append(f'<line x1="{x:.1f}" y1="{Y2T}" x2="{x:.1f}" y2="{Y2B}" stroke="#232936" stroke-width="1"/>')
        l2.append(f'<text x="{x:.1f}" y="{Y2B+20:.1f}" text-anchor="middle" fill="#8b93a7" '
                  f'font-size="12">{gp:.2f}</text>')
        gp -= gs

    legend = "".join(
        f'<rect x="{X2L+530}" y="{Y2T-30+i*20}" width="22" height="3" fill="{c}"/>'
        f'<text x="{X2L+558}" y="{Y2T-25+i*20}" fill="#c3c9d6" font-size="12.5">{esc(n)}</text>'
        for i, (n, _, c, _, _) in enumerate(curves_src))

    svg2 = f'''<svg viewBox="0 0 {W2} {H2}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="system-ui,-apple-system,'Segoe UI',sans-serif">
<rect width="{W2}" height="{H2}" fill="#12151c"/>
<text x="{X2L}" y="28" fill="#e6e9f0" font-size="15" font-weight="700">筹码峰迁移（密度曲线对比）</text>
{legend}
{''.join(g2)}{''.join(l2)}
<line x1="{X2L}" y1="{Y2B}" x2="{X2R}" y2="{Y2B}" stroke="#3a4256" stroke-width="1.5"/>
{drawn}
<line x1="{x2p(close):.1f}" y1="{Y2T}" x2="{x2p(close):.1f}" y2="{Y2B}" stroke="#ffffff" stroke-width="1.4" stroke-dasharray="6,3" opacity="0.8"/>
{cplabel}
<text x="{X2L}" y="{H2-14}" fill="#6b7280" font-size="11.5">横轴=价格（<tspan fill="#9aa4b8">左高 → 右低</tspan>，与上方峰位图"上高下低"同向），纵轴=筹码密度（已平滑）· 峰往右走=重心下沉，往左走=重心上抬</text>
</svg>'''

    # ---------------- 表格 ----------------
    peak_rows = "".join(
        f"<tr><td>峰{i}</td><td class='mono b'>{p:.2f}</td><td class='mono'>{(p/close-1)*100:+.1f}%</td>"
        f"<td class='mono'>{d:.2f}</td><td>{'主峰（最密集）' if i == 1 else ('次密集区' if i <= 3 else '小峰')}</td></tr>"
        for i, (p, d) in enumerate(peaks, 1))

    zone_rows = "".join(
        f"<tr><td class='mono'>{esc(n)}</td><td><div class='barwrap'>"
        f"<div class='bar' style='width:{min(d*8,100):.1f}%'></div>"
        f"<span class='barval'>{d:.2f}%</span></div></td></tr>"
        for n, d in D["zones"])

    hist_rows = "".join(
        f"<tr><td>{esc(k)}</td><td class='mono'>{v['date']}</td><td class='mono'>{v['close']:.2f}</td>"
        f"<td class='mono b'>{v['peaks'][0][0]:.2f}</td><td class='mono'>{v['avg']:.2f}</td>"
        f"<td class='mono'>{v['profit']:.1f}%</td><td class='mono'>{v['c70']:.1f}</td></tr>"
        for k, v in sorted(hist.items(), key=lambda kv: -int(kv[0].replace("日前", ""))))

    vld = ""
    if off:
        rows = []
        for n, mv, ov, t in [("平均成本", st["avg"], off["avg"], 0.5),
                             ("获利盘 %", st["profit"], off["profit"], 3.0),
                             ("集中度 70", st["c70"][0], off["c70"], 1.0),
                             ("集中度 90", st["c90"][0], off["c90"], 3.0)]:
            d = mv - ov
            rows.append(f"<tr><td>{n}</td><td class='mono b'>{mv:.2f}</td><td class='mono'>{ov:.2f}</td>"
                        f"<td class='mono {'ok' if abs(d) < t else 'warn'}'>{d:+.2f}</td></tr>")
        vld = (f'<div class="card"><h2>模型可信度验证</h2>'
               f'<table><tr><th>指标</th><th>模型重建</th><th>官方接口</th><th>偏差</th></tr>'
               f'{"".join(rows)}</table>'
               f'<div class="note">四项指标与交易所口径筹码统计对照，全部落在容差内说明重建分布基本可信。'
               f'<b>但这是近似模型</b>：三角形分布假设 + 线性衰减，未区分主动买卖方向，未计入大宗交易与解禁，'
               f'与券商终端筹码图存在数个百分点差异 —— 看峰位与迁移方向够用，不要当精确持仓成本使用。</div></div>')

    # 主峰迁移文字
    mig = ""
    if hist:
        seq_names = sorted(hist.keys(), key=lambda k: -int(k.replace("日前", "")))
        seq = [hist[k]["peaks"][0][0] for k in seq_names if hist[k]["peaks"]] + [main_peak]
        direction = "下移" if seq[-1] < seq[0] else ("上移" if seq[-1] > seq[0] else "基本持平")
        mig = (f'<li>主峰迁移轨迹：<b>{" → ".join(f"{x:.2f}" for x in seq)}</b>'
               f'（{seq_names[-1]}至今），整体<b>{direction} {abs(seq[-1]-seq[0]):.2f} 元</b>。'
               f'主峰下移通常意味着高位套牢盘被换手消化、筹码重心下沉；上移则意味着新资金在更高位接盘。</li>')

    note_html = esc(a.note).replace("\n", "<br>") if a.note else ""
    extra = f'<div class="card"><h2>补充说明</h2><div class="note">{note_html}</div></div>' if a.note else ""
    interp = gen_interpretation(D, close, st, off, peaks, main_peak, prices, chip, V_LO, V_HI, hist)

    html = f'''<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{esc(a.name)} {esc(a.code)} · 筹码峰分析</title>
<style>
*{{box-sizing:border-box}}
body{{margin:0;background:#0d1016;color:#e6e9f0;
 font-family:system-ui,-apple-system,'Segoe UI','PingFang SC','Microsoft YaHei',sans-serif;
 line-height:1.65;padding:32px 20px 60px}}
.wrap{{max-width:1040px;margin:0 auto}}
h1{{font-size:26px;margin:0 0 6px;letter-spacing:.5px}}
.sub{{color:#8b93a7;font-size:13.5px;margin-bottom:26px}}
.card{{background:#151922;border:1px solid #232a38;border-radius:12px;padding:20px 22px;margin-bottom:18px}}
h2{{font-size:16.5px;margin:0 0 14px;color:#fff;display:flex;align-items:center;gap:8px}}
h2::before{{content:'';width:3px;height:15px;background:#e05252;border-radius:2px}}
.kpis{{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:18px}}
.kpi{{background:#151922;border:1px solid #232a38;border-radius:10px;padding:14px 16px}}
.kpi .k{{color:#8b93a7;font-size:12px;margin-bottom:5px}}
.kpi .v{{font-size:22px;font-weight:700;letter-spacing:.5px}}
.kpi .n{{color:#6b7280;font-size:11.5px;margin-top:3px}}
.red{{color:#e05252}} .blue{{color:#4d7fd6}} .gold{{color:#f0b429}}
table{{width:100%;border-collapse:collapse;font-size:13.5px}}
th{{text-align:left;color:#8b93a7;font-weight:600;font-size:12.5px;padding:8px 10px;border-bottom:1px solid #2a3140}}
td{{padding:8px 10px;border-bottom:1px solid #1e242f}}
tr:last-child td{{border-bottom:none}}
.mono{{font-family:ui-monospace,Consolas,monospace}}
.b{{color:#fff;font-weight:600}}
.ok{{color:#3ecf8e}} .warn{{color:#f0932b}}
.barwrap{{position:relative;display:flex;align-items:center;gap:8px}}
.bar{{height:15px;background:linear-gradient(90deg,#e05252,#c0392b);border-radius:3px;min-width:2px}}
.barval{{font-family:ui-monospace,Consolas,monospace;font-size:12.5px;color:#c3c9d6}}
.note{{background:#1a1f2b;border-left:3px solid #f0b429;border-radius:0 8px 8px 0;padding:13px 16px;font-size:13.3px;color:#c3c9d6;margin-top:14px}}
.find{{background:#1a1f2b;border-left:3px solid #e05252;border-radius:0 8px 8px 0;padding:13px 16px;font-size:13.3px;color:#c3c9d6;margin-top:12px}}
ul{{margin:8px 0 0;padding-left:20px}} li{{margin-bottom:7px}}
.foot{{color:#5a6274;font-size:12px;margin-top:26px;line-height:1.8}}
@media(max-width:860px){{.kpis{{grid-template-columns:1fr 1fr}}}}
</style></head><body><div class="wrap">

<h1>{esc(a.name)} <span class="sub" style="display:inline">{esc(a.code)}</span></h1>
<div class="sub">筹码峰重建分析 · 基准日 {D['date']} 收盘 {close:.2f} · 样本 {D['n_days']} 个交易日 · 三角形分布 + 换手率衰减模型</div>

<div class="kpis">
<div class="kpi"><div class="k">主峰位置</div><div class="v gold">{main_peak:.2f}</div><div class="n">距现价 {(main_peak/close-1)*100:+.1f}%</div></div>
<div class="kpi"><div class="k">平均成本</div><div class="v">{st['avg']:.2f}</div><div class="n">{'官方 ' + format(off['avg'], '.2f') if off else '未提供官方口径'}</div></div>
<div class="kpi"><div class="k">获利盘</div><div class="v red">{st['profit']:.1f}%</div><div class="n">套牢盘 {D['above']:.1f}%</div></div>
<div class="kpi"><div class="k">90% 筹码区间</div><div class="v" style="font-size:17px">{st['c90'][1]:.2f}–{st['c90'][2]:.2f}</div><div class="n">70% 区间 {st['c70'][1]:.2f}–{st['c70'][2]:.2f}</div></div>
</div>

<div class="card"><h2>筹码峰位图</h2>{svg1}
<div class="note"><b>这张图怎么读：</b>横向条越长 = 该价位堆积的筹码越多。红色在现价 {close:.2f} 以下（获利盘），蓝色在现价以上（套牢盘）。
最密集的那条横线就是<b>主峰 {main_peak:.2f}</b>，它是绝大多数流通筹码的成本所在，也是最重要的支撑参照。</div>
</div>

<div class="card"><h2>峰位明细</h2>
<table><tr><th>序号</th><th>价格</th><th>距现价</th><th>相对密度</th><th>性质</th></tr>
{peak_rows}</table>
</div>

<div class="card"><h2>关键价位筹码堆积</h2>
<table><tr><th>价位</th><th>该价位 ±0.08 元内的筹码占比</th></tr>
{zone_rows}</table>
<div class="find"><b>怎么用它判断支撑/压力：</b>
<ul>
<li>堆积<b>厚重</b>的价位 = 大量筹码在此换手，跌到这里有承接、涨到这里有抛压，是真实的有效位。</li>
<li>堆积<b>稀薄</b>的价位 = 筹码真空，价格经过时阻力小、速度快，但一旦反向也没有缓冲。</li>
<li><b>主峰是最硬的位置</b>：跌破主峰意味着大多数持仓者由盈转亏，性质会从支撑翻转为压力。</li>
</ul></div>
</div>

<div class="card"><h2>筹码峰迁移</h2>{svg2}
<table style="margin-top:16px"><tr><th>时点</th><th>日期</th><th>收盘</th><th>主峰</th><th>平均成本</th><th>获利盘</th><th>集中度70</th></tr>
{hist_rows}
<tr><td class="b">当前</td><td class="mono">{D['date']}</td><td class="mono">{close:.2f}</td>
<td class="mono b">{main_peak:.2f}</td><td class="mono">{st['avg']:.2f}</td>
<td class="mono">{st['profit']:.1f}%</td><td class="mono">{st['c70'][0]:.1f}</td></tr>
</table>
<div class="find"><b>迁移要点：</b><ul>{mig}
<li>集中度 70 收窄 = 筹码向单一价位收敛（<b>单峰密集</b>，方向选择临近）；走阔 = 发散（多峰，分歧加大）。</li>
<li>获利盘快速冲高（如 &gt;80%）时，浮盈盘高度集中，上涨基础与潜在抛压是同一批筹码，需配合主峰位置判断安全边际。</li>
</ul></div>
</div>

{vld}
{extra}
{interp}

<div class="foot">
数据来源：腾讯自选股（westock）日 K 线 {D['n_days']} 根（前复权，含换手率）{'+ 筹码指标接口' if off else ''}，基准日 {D['date']}。<br>
算法：三角形分布（顶点取当日 (high+low+close)/3）+ 逐日 (1−换手率) 衰减，价格网格步长 {D['step']} 元，归一化至 100% 流通盘。<br>
本报告为技术层面的筹码结构推算，不构成投资建议。市场有风险，决策请独立判断。
</div>

</div></body></html>'''

    with open(a.out, "w", encoding="utf-8") as f:
        f.write(html)
    print("OK ->", a.out, len(html.encode("utf-8")), "bytes")


if __name__ == "__main__":
    main()
