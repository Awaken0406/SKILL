#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
种子脚本：把本次(2026-08-25)已 WebSearch 到的行业 PE 落进 industry_pe 缓存表，
并建立 code→industry 映射(stock_industry)。以后扫描优先查这张表，不再重复搜索。

数据来源：D:/News/score_input.json 中每只标的的 pe_benchmark 与 theme.pe_src。
"""
import json
import os
import sqlite3
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pe_cache

NEWS = os.path.dirname(os.path.abspath(__file__))

# code -> 规范行业名(与 industry_pe 的 industry 键一致)
CODE_INDUSTRY = {
    "sh600598": "种植业", "sh601869": "通信设备", "sh601898": "煤炭",
    "sh601975": "航运港口", "sh603112": "汽车零部件", "sz000017": "重组综合",
    "sz002033": "旅游景区", "sz002041": "种植业", "sz002215": "农药",
    "sz003010": "化妆品电商", "sh600508": "煤炭", "sh601088": "煤炭",
    "sh601886": "建筑装饰", "sh603268": "船舶重组", "sh603519": "白色家电",
    "sz002017": "通信设备", "sz002412": "中药", "sz002491": "通信设备",
    "sz002746": "肉鸡养殖", "sz002901": "医疗器械",
}

# 规范行业 -> (pe, source, is_estimate)  取自本次 WebSearch 结果
INDUSTRY_PE = {
    "种植业":     (38, "种植业(申万) 2026-07-22 38.51", False),
    "通信设备":   (50, "通信设备(中证全指通信设备指数) 2026-08 ~51-53", False),
    "煤炭":       (18, "煤炭(剔除异常值) 开源证券 2026-08-14 18.25", False),
    "航运港口":   (27, "航运港口(概念板) 2026-08-25 26.85", False),
    "汽车零部件": (27, "汽车零部件(申万) 2026-03-26 26.76", False),
    "重组综合":   (50, "重组/综合 估算(高PE重组壳,无统一行业PE)", True),
    "旅游景区":   (30, "旅游/景区 2026E ~29.8", False),
    "农药":       (37, "农药(申万) 2026-07-31 36.95", False),
    "化妆品电商": (35, "化妆品/电商 估算(消费PE,无统一口径)", True),
    "建筑装饰":   (15, "建筑装饰 估算(低PE ~10-15)", True),
    "船舶重组":   (30, "船舶/重组 估算(恒力重工借壳,参考船舶制造)", True),
    "白色家电":   (24, "白色家电(概念板) 2026-08-25 23.54", False),
    "中药":       (24, "中药(申万中药Ⅱ) 2026 23.x", False),
    "肉鸡养殖":   (20, "肉鸡养殖(申万) 2026-07-09 20.91", False),
    "医疗器械":   (35, "医疗器械(申万整体) 2026 32-35", False),
}


def main():
    # 1) 校验 score_input 中的 pe_benchmark 与种子一致(防止后续手工改了没同步)
    #    score_input.json 不在(如 skill 被装到别处)时跳过校验, 不阻断播种。
    fp = os.path.join(NEWS, "score_input.json")
    if os.path.exists(fp):
        with open(fp, "r", encoding="utf-8-sig") as f:
            data = json.load(f)
        mism = []
        for s in data.get("stocks", []):
            ind = CODE_INDUSTRY.get(s["code"])
            seed = INDUSTRY_PE.get(ind)
            if not ind or not seed:
                mism.append(f"{s['code']} 缺行业映射")
            elif abs((s.get("pe_benchmark") or 0) - seed[0]) > 0.01:
                mism.append(f"{s['code']} pe_benchmark={s.get('pe_benchmark')} 与种子{seed[0]}不符")
        if mism:
            print("[警告] 与 score_input 不一致:", mism)
    else:
        print(f"[提示] 未找到 {fp}, 跳过一致性校验")

    # 2) 写 industry_pe
    for ind, (pe, src, est) in INDUSTRY_PE.items():
        pe_cache.set_pe(ind, pe, src, is_estimate=est)

    # 3) 写 stock_industry
    for code, ind in CODE_INDUSTRY.items():
        pe_cache.set_industry(code, ind)

    print(f"[种子完成] industry_pe {len(INDUSTRY_PE)} 个行业, stock_industry {len(CODE_INDUSTRY)} 只标的")
    print("\n行业 PE 缓存表(industry_pe):")
    for ind, pe, src, upd, est in pe_cache.all_industries():
        print(f"  {ind:<10} pe={pe:<5} {'估算' if est else '实查'}  {upd}  {src}")


if __name__ == "__main__":
    main()
