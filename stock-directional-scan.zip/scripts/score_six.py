#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
购买指数六维评分（保守口径）——纯评分脚本，不拉数据。

定位：配合 westock-mcp 使用。每天 data_quote / data_technical / data_kline 拉回的
JSON 原样贴进输入文件，本脚本按《购买指数六维体系（保守口径）》算五个数值维度，
题材分(10)留人工判断（输入里可带 theme.score，缺省 6）。

用法:
    python score_six.py --input score_input.json
    python score_six.py --input score_input.json --out result.md --rsi-window 6
    python score_six.py --input score_input.json --history score_history.jsonl   # 把评分快照追加落库(供回测)

单股场景（stock-support-buypoint）：输入 JSON 顶层可加 "pe_benchmark": <行业PE中枢>，
无候选池中位数可用时以它为估值基准；缺省时单股自身PE即中位数（比值=1 → 中枢档7分）。

回测落库（--history）：每次运行把每只标的的评分快照(日期/代码/名称/总分/评级/六维分项)追加入
JSONL。backtest.py 读取该文件 + westock 后续K线，算 T+5/10/20 分组收益/胜率/相对基准，验证体系预测力。

输入 JSON 结构（MCP 返回原样粘贴，kline 正序倒序均可）:
{
  "stocks": [
    {
      "code": "sh601088",
      "name": "中国神华",
      "quote":  { ...data_quote 返回的原对象... },
      "tech":   { ...data_technical 返回的原对象(ma/kdj/macd/rsi[/boll])... },
      "kline":  [ ...data_kline 的 nodes 数组(至少65根, 建议120根)... ],
      "theme":  {"score": 6, "note": "煤炭保供+高股息"}   # 可选
    }
  ]
}

评分细则来源: stock-directional-scan/references/scoring.md
规则文本未细化处的确定性插值，全部集中在本文件顶部 CONFIG 区，可调可查。
"""
import argparse
import json
import os
import sys
from datetime import datetime
from statistics import median

# ============================================================
# CONFIG：规则歧义点的确定性实现（改动前先读注释）
# ============================================================
RSI_WINDOW = "RSI_6"      # 规则未指明 RSI 窗口；默认 RSI_6（短线敏感，保守），可用 --rsi-window 改 RSI_12
STOP_PCT = 0.985          # 止损 = 支撑(MA20) 下方 1.5%（规则"支撑下方1-2%"取中值）
TARGET_LOOKBACK = 60      # 第一目标 = 近 60 个交易日最高价（规则"即时阻力/前高"）
MA60_SLOPE_DAYS = 5       # MA60 上行 = 今值 > 5 个交易日前的 MA60 值
THEME_DEFAULT = 6         # 题材缺省分（"有题材无事件"档）
VAL_POOL_RATIO = True     # 估值用候选池 PE 中位数作"行业中枢"代理（无行业PE接口时的替代）

# 【规则文本修正①】scoring.md 原文 dist=(支撑−现价)/现价 且 "dist<0 → 已跌破"，
# 两者互相矛盾（支撑在现价下方时 dist 恒为负）。按档位语义修正为:
#   dist = (现价 − 支撑) / 现价   → 现价高于支撑为正（距支撑的距离），
#   dist < 0 表示现价已跌破支撑。
# 档位（|dist|）：≤2% → 20；2–5% → 14；5–8% → 8；>8% → 3
# 跌破(dist<0)插值: >−1% → 3；−1~−3% → 1；≤−3% → 0
POS_BREAK_BANDS = [(-0.01, 3), (-0.03, 1), (None, 0)]

# 【规则文本修正②】"跌破MA5位置分降一档"：20→14→8→3，已至 3 不再降；
# 若同时已跌破支撑（dist<0），直接取 0（最保守）。

# 反转日击穿修正（四条件全部满足才触发）扣分: 基础5 + 跌幅≥5%再扣3 + 换手创20日新高再扣2，封底0
BREAK_BASE, BREAK_DEEP, BREAK_VOL = 5, 3, 2

# 趋势档（保守口径①的确定性插值）:
#   价>MA60 且 MA60上行 且 价>MA20        → 25  干净多头
#   价>MA60 且 MA60上行 但 价≤MA20        → 18  多头但短线走弱
#   价>MA60 且 MA60走平/下行              → 15  反弹/震荡
#   价≤MA60 且 价>MA20                    → 12  反弹/震荡(弱)
#   价≤MA60 且 价≤MA20(未破MA120与MA250)  → 8
#   价<MA120 且 价<MA250                  → 3   空头
TREND_TABLE = "见上注释"

# 动能（基础10, 封顶20, 保底0）:
#   J<20  → +6，仅当 现价≥MA20 且 量比≥1.0（保守口径③: 缩量/资金弱不加）
#   20≤J≤50 → +3；50<J≤90 → 0；J>90 → −6
#   MACD(12,26,9) 自算自K线（2026-08-25 增强, 修正"只看单点红柱"退化）:
#     金叉(DIF上穿DEA) 或 红柱放大(柱今>昨) → +4；死叉(DIF下穿DEA) 或 绿柱放大(柱今<昨<0) → −4
#     否则按柱正负给 ±2（红柱收缩/绿柱收缩）; 缺K线回退用接口MACD单点: >0→+4, <0→−4
#   RSI 30–60 → +3; >80 → −4; <30 → +2
MOM_J_BONUS_VOL_RATIO = 1.0
MACD_SELF_USE = True      # 用K线自算MACD(12,26,9)做金叉/放大判断
MACD_FAST, MACD_SLOW, MACD_SIGNAL = 12, 26, 9

# 盈亏比（规则字面: 在核心买点处计算, 与现价无关）:
#   entry = MA20; stop = MA20*(1-1.5%); target = 近60日最高
#   R:R≥3 → 15; 2–3 → 11; 1.5–2 → 7; <1.5 → 3; 目标≤买点(无法定阻力) → 3; 缺K线 → 0
#   同时输出"现价口径R:R"仅供对照, 不参与评分。
#
# 【④ 追高修正（2026-08-25 新增）】买点口径R:R会奖励"现价已飞离买点"的票(位置分3但盈亏比15),
#   与"现在值不值得买"的定位冲突。本修正用现价口径风险兜底:
#   现价距买点(MA20)>8% 且 现价口径R:R<1.0 → 总分扣 CHASE_PENALTY(默认4), 明细标注"已远离买点,现价追高风险高"
CHASE_PENALTY = 4
CHASE_DIST = 0.08          # 现价距买点阈值
CHASE_RR_NOW = 1.0         # 现价口径R:R阈值

# 估值（PE_TTM vs 候选池中位数 med, 无行业PE接口, 池中位数作代理）:
#   PE≤0(亏损) → 0; ≤0.7*med → 10; ≤1.0*med → 7; ≤1.5*med → 4; >1.5*med → 0
#   且 chg_10d>40% 且 >1.5*med → 0（透支条款已含）

RATING = [(80, "强烈建议买入"), (65, "建议买入"), (50, "轻仓试探/等回踩"), (35, "观望"), (0, "不建议买入")]


def rating_of(total):
    for floor, name in RATING:
        if total >= floor:
            return name
    return RATING[-1][1]


# ============================================================
# 数据读取（MCP 原生结构适配）
# ============================================================
class Stock:
    def __init__(self, raw):
        self.code = raw.get("code", "")
        self.name = raw.get("name", self.code)
        q = raw.get("quote", {}) or {}
        t = raw.get("tech", {}) or {}
        ma = t.get("ma", {}) or {}
        self.px = q.get("price") or t.get("closePrice")
        self.high, self.low = q.get("high"), q.get("low")
        self.prev_close = q.get("prev_close")
        self.turnover = q.get("turnover_rate")
        self.vol_ratio = q.get("volume_ratio")
        self.pe = q.get("pe_ratio")
        self.chg_10d = q.get("chg_10d")
        self.ma = {k: ma.get(k) for k in ("MA_5", "MA_10", "MA_20", "MA_60", "MA_120", "MA_250")}
        boll_mid = (t.get("boll") or {}).get("BOLL_MID")
        self.boll_mid = boll_mid
        self.j = (t.get("kdj") or {}).get("KDJ_J")
        self.macd = (t.get("macd") or {}).get("MACD")
        rsi = t.get("rsi") or {}
        self.rsi = rsi.get(RSI_WINDOW)
        self.theme = raw.get("theme") or {}
        self.notes = []
        kl = raw.get("kline") or []
        nodes = []
        if isinstance(kl, list):
            nodes = [n for n in kl if isinstance(n, dict) and "date" in n]
            if kl and not nodes:
                self.notes.append("kline字段非节点数组, 按缺K线处理")
        elif kl:
            self.notes.append("kline字段非数组, 按缺K线处理")
        nodes.sort(key=lambda n: n["date"])
        self.kline = nodes
        self.closes = [float(n["last"]) for n in nodes if n.get("last") is not None]
        if nodes and len(self.closes) < len(nodes):
            self.notes.append(f"{len(nodes)-len(self.closes)}根K线缺last字段")

    @property
    def support(self):
        """最近有效支撑: 默认 MA20/布林中轨(两者取低者更保守)。"""
        cands = [v for v in (self.ma.get("MA_20"), self.boll_mid) if v]
        return min(cands) if cands else None

    def ma60_slope_up(self):
        """MA60 上行: 今值 > MA60_SLOPE_DAYS 日前的值(自算, 不依赖接口历史)。"""
        n = 60 + MA60_SLOPE_DAYS
        if len(self.closes) < n:
            self.notes.append(f"K线不足{n}根, MA60斜率不可算")
            return None
        today = sum(self.closes[-60:]) / 60
        ago = sum(self.closes[-n:-MA60_SLOPE_DAYS]) / 60
        # 与接口 MA_60 交叉校验
        api = self.ma.get("MA_60")
        if api and abs(today - api) / api > 0.01:
            self.notes.append(f"自算MA60({today:.2f})与接口({api:.2f})偏差>1%")
        return today > ago

    def hh(self, days=TARGET_LOOKBACK):
        """近 days 日最高价(含当日)。"""
        if not self.kline:
            return None
        return max(float(n["high"]) for n in self.kline[-days:])

    def macd_state(self):
        """用K线自算 MACD(12,26,9)，返回 dict(金叉/死叉/红柱放大/绿柱放大/柱正负)。

        确定性实现（EMA 用平滑系数 2/(N+1)，与主流行情软件一致）：
          dif = EMA12 - EMA26；dea = EMA9(dif)；柱 = 2*(dif-dea)（A股口径乘以2）
        返回 None 表示 K线不足无法自算（由调用方回退到接口单点）。
        """
        c = self.closes
        n_req = MACD_SLOW + MACD_SIGNAL + 2
        if len(c) < n_req:
            return None
        ema_f, ema_s, ema_d = [c[0]] * 3
        dif_prev = None
        difs = []
        for i in range(1, len(c)):
            ema_f = ema_f + 2 / (MACD_FAST + 1) * (c[i] - ema_f)
            ema_s = ema_s + 2 / (MACD_SLOW + 1) * (c[i] - ema_s)
            dif = ema_f - ema_s
            difs.append(dif)
        # dea = EMA9(dif)
        dea = difs[0]
        deas = [dea]
        for dif in difs[1:]:
            dea = dea + 2 / (MACD_SIGNAL + 1) * (dif - dea)
            deas.append(dea)
        hist = [2 * (d - e) for d, e in zip(difs, deas)]  # 柱
        if len(hist) < 2:
            return None
        h0, h1 = hist[-1], hist[-2]
        dif0, dif1 = difs[-1], difs[-2]
        dea0, dea1 = deas[-1], deas[-2]
        cross_up = dif1 <= dea1 and dif0 > dea0      # 金叉
        cross_dn = dif1 >= dea1 and dif0 < dea0      # 死叉
        bar_grow = h0 > h1                            # 红柱放大或绿柱收缩
        green_grow = h0 < h1 and h0 < 0 and h1 < 0    # 绿柱放大(更负)
        return {"cross_up": cross_up, "cross_dn": cross_dn,
                "bar_grow": bar_grow, "green_grow": green_grow,
                "bar_pos": h0 > 0}


# ============================================================
# 六维评分
# ============================================================
def score_trend(s):
    px = s.px
    ma60_up = s.ma60_slope_up()
    m60, m20, m120, m250 = (s.ma.get(k) for k in ("MA_60", "MA_20", "MA_120", "MA_250"))
    if m250 and m120 and px < m120 and px < m250:
        return 3, "空头(价<MA120且<MA250)"
    if m60 and px > m60:
        if ma60_up is True:
            if m20 and px > m20:
                return 25, "干净多头(价>上行MA60且价>MA20)"
            return 18, "多头但短线走弱(价>上行MA60, 价≤MA20)"
        return 15, "反弹/震荡(价>MA60但MA60未上行)"
    if m20 and px > m20:
        return 12, "反弹/震荡弱(价≤MA60, 价>MA20)"
    return 8, "价≤MA60且≤MA20(未全破长均线)"


def score_position(s):
    sup = s.support
    if sup is None or s.px is None:
        return 0, "缺MA20/布林中轨"
    dist = (s.px - sup) / s.px
    # 基础档
    if dist < 0:  # 已跌破支撑
        for bound, sc in POS_BREAK_BANDS:
            if bound is None or dist > bound:
                base, why = sc, f"已跌破支撑{dist:.1%}"
                break
    else:
        ad = abs(dist)
        base, why = (20, "贴支撑≤2%") if ad <= 0.02 else \
                    (14, "距支撑2-5%") if ad <= 0.05 else \
                    (8,  "距支撑5-8%") if ad <= 0.08 else (3, "距支撑>8%")
    # 跌破MA5降一档
    ma5 = s.ma.get("MA_5")
    below_ma5 = ma5 is not None and s.px < ma5
    if below_ma5 and dist >= 0:
        base = {20: 14, 14: 8, 8: 3, 3: 3}[base]
        why += "; 跌破MA5降一档"
    elif below_ma5 and dist < 0:
        base = 0
        why += "; 跌破MA5且已破支撑, 取0"
    # 反转日击穿修正
    pen = reversal_break_penalty(s)
    if pen:
        why += f"; 反转日击穿扣{pen}"
    return max(0, base - pen), f"{why}(支撑{sup:.2f}, dist={dist:+.1%})"


def reversal_break_penalty(s):
    """四条件: 跌幅≥3%收阴 / 换手>10%或创20日高 / 收盘贴最低≤1.02 / 收盘破MA5且盘中击穿MA20或MA60或布林中轨。"""
    if s.prev_close is None or s.px is None:
        return 0
    chg = (s.px - s.prev_close) / s.prev_close
    cond_a = chg <= -0.03
    if not cond_a:
        return 0
    if s.turnover is not None:
        hi20 = None
        if s.kline:
            hist = [float(n["exchange"]) for n in s.kline[-21:-1] if n.get("exchange") is not None]
            hi20 = max(hist) if hist else None
        cond_b = s.turnover > 10 or (hi20 is not None and s.turnover > hi20)
    else:
        cond_b = False
    cond_c = s.low and s.px / s.low <= 1.02
    ma5 = s.ma.get("MA_5")
    intr = [m for m in (s.ma.get("MA_20"), s.ma.get("MA_60"), s.boll_mid) if m]
    cond_d = ma5 is not None and s.px < ma5 and any(s.low < m for m in intr)
    if not (cond_a and cond_b and cond_c and cond_d):
        return 0
    pen = BREAK_BASE + (BREAK_DEEP if chg <= -0.05 else 0) + (BREAK_VOL if cond_b else 0)
    return pen


def score_momentum(s):
    v = 10
    if s.j is not None:
        if s.j < 20:
            ok = (s.ma.get("MA_20") is None or s.px >= s.ma["MA_20"]) and \
                 (s.vol_ratio is None or s.vol_ratio >= MOM_J_BONUS_VOL_RATIO)
            if ok:
                v += 6  # 超卖+站稳MA20+量能未缩
        elif s.j <= 50:
            v += 3
        elif s.j > 90:
            v -= 6
    # MACD 动能（2026-08-25 增强: 优先K线自算金叉/放大）
    if MACD_SELF_USE:
        st = s.macd_state()
        if st is None:
            # 回退: 接口单点
            if s.macd is not None:
                v += 4 if s.macd > 0 else -4
        else:
            if st["cross_up"] or st["bar_grow"]:
                v += 4
            elif st["cross_dn"] or st["green_grow"]:
                v -= 4
            else:
                v += 2 if st["bar_pos"] else -2
    elif s.macd is not None:
        v += 4 if s.macd > 0 else -4
    if s.rsi is not None:
        if 30 <= s.rsi <= 60:
            v += 3
        elif s.rsi > 80:
            v -= 4
        elif s.rsi < 30:
            v += 2
    return max(0, min(20, v)), ""


def score_rr(s):
    """买点口径 R:R（规则字面），附现价口径参考。返回 (分, 现价口径R:R或None, 说明)。"""
    sup = s.support
    if sup is None or not s.kline:
        return 0, None, "缺K线/支撑, 盈亏比给0(宁低勿高)"
    entry, stop = sup, sup * STOP_PCT
    target = s.hh(TARGET_LOOKBACK)
    if target is None or target <= entry:
        return 3, None, f"近{TARGET_LOOKBACK}日无法定阻力(target≤买点), 给3"
    rr = (target - entry) / (entry - stop)
    sc = 15 if rr >= 3 else 11 if rr >= 2 else 7 if rr >= 1.5 else 3
    why = f"买点{entry:.2f} 止损{stop:.2f} 目标{target:.2f} 买点R:R={rr:.1f}"
    rr_now = None
    if s.px > stop:
        rr_now = (target - s.px) / (s.px - stop)
        why += f" 现价口径R:R={rr_now:.1f}"
    return sc, rr_now, why


def chase_penalty(s, rr_now):
    """【④ 追高修正】现价距买点(MA20)>8% 且 现价口径R:R<1.0 → 扣分，标注追高风险。

    返回 (扣分, 是否触发)。"""
    sup = s.support
    if sup is None or s.px is None:
        return 0, False
    dist = (s.px - sup) / s.px
    if rr_now is not None and dist > CHASE_DIST and rr_now < CHASE_RR_NOW:
        return CHASE_PENALTY, True
    return 0, False


def score_valuation(s, pool_med):
    if not VAL_POOL_RATIO or pool_med is None:
        return 7, "无池中位参照, 给中枢档7"
    if s.pe is None or s.pe <= 0:
        return 0, "亏损/无PE"
    r = s.pe / pool_med
    sc = 10 if r <= 0.7 else 7 if r <= 1.0 else 4 if r <= 1.5 else 0
    if sc == 0 and (s.chg_10d is not None and s.chg_10d > 40):
        return 0, f"PE为池中位{r:.2f}倍且10日涨{s.chg_10d:.0f}%→透支0分"
    return sc, f"PE{s.pe:.1f}=池中位({pool_med:.1f})的{r:.2f}倍"


def consistency_check(s, dims):
    """scoring.md 交付前三查。返回警告列表。"""
    w = []
    px, m60, ma5 = s.px, s.ma.get("MA_60"), s.ma.get("MA_5")
    if m60 and px < m60 and dims["trend"][0] >= 15:
        w.append("价<MA60但趋势分≥15")
    if ma5 and px < ma5 and dims["pos"][0] >= 14:
        w.append("跌破MA5但位置分≥14")
    if s.j is not None and s.j < 20 and (s.vol_ratio or 1) < 1 and dims["mom"][0] >= 14:
        w.append("J超卖且量缩但动能分≥14")
    return w


# ============================================================
# 主流程
# ============================================================
def append_history(history_path, rows, now=None):
    """把本次评分的快照追加到 JSONL（每行一条, 供 backtest.py 回测）。

    快照含: 日期/代码/名称/总分/评级/六维分项/是否追高修正/现价/现价口径R:R。
    失败不中断主流程（回测落库是辅助能力）。"""
    if not history_path:
        return
    now = now or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(history_path, "a", encoding="utf-8") as f:
            for r in rows:
                d = r["dims"]
                rec = {
                    "ts": now,
                    "date": r.get("score_date", ""),
                    "code": r["s"].code,
                    "name": r["s"].name,
                    "total": r["total"],
                    "rating": rating_of(r["total"]),
                    "six": [d["trend"][0], d["pos"][0], d["mom"][0], d["rr"][0], d["theme"][0], d["val"][0]],
                    "chased": r["chased"],
                    "px": r["s"].px,
                    "rr_now": r["rr_now"],
                }
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        print(f"[历史落库] 追加 {len(rows)} 条 → {history_path}", file=sys.stderr)
    except Exception as e:
        print(f"[历史落库失败, 不影响本次评分] {e}", file=sys.stderr)


def run(path, out_path, history_path=None, score_date=""):
    with open(path, "r", encoding="utf-8-sig") as f:
        data = json.load(f)
    stocks = [Stock(r) for r in data.get("stocks", [])]
    # 估值基准优先级: 顶层 pe_benchmark(单股场景显式指定) > 候选池PE中位数 > None
    pool_med = data.get("pe_benchmark") or median([s.pe for s in stocks if s.pe and s.pe > 0]) or None

    rows = []
    for s in stocks:
        trend = score_trend(s)
        pos = score_position(s)
        mom = score_momentum(s)
        rr_sc, rr_now, rr_why = score_rr(s)
        theme_sc = int(s.theme.get("score", THEME_DEFAULT))
        val = score_valuation(s, pool_med)
        dims = {
            "trend": trend, "pos": pos, "mom": mom,
            "rr": (rr_sc, rr_why),
            "theme": (theme_sc, s.theme.get("note", "默认:有题材无事件")),
            "val": val,
        }
        chase, chased = chase_penalty(s, rr_now)
        total = sum(v[0] for v in dims.values()) - chase
        warns = consistency_check(s, dims)
        rows.append({"s": s, "dims": dims, "total": total, "warns": warns,
                     "chase": chase, "chased": chased, "rr_now": rr_now,
                     "score_date": score_date})

    rows.sort(key=lambda r: -r["total"])

    lines = []
    lines.append("## 六维评分结果（保守口径·脚本计算）\n")
    lines.append(f"评分维度: 趋势25/位置20/动能20/盈亏比15/题材10/估值10 | RSI窗口={RSI_WINDOW} | "
                 f"估值基准=候选池PE中位数({pool_med:.1f}，代理行业中枢) | "
                 f"追高修正: 现价距买点>{CHASE_DIST:.0%}且现价R:R<{CHASE_RR_NOW:.1f}扣{CHASE_PENALTY}分\n")
    lines.append("| 名称 | 代码 | 总分 | 评级 | 趋势 | 位置 | 动能 | 盈亏比 | 题材 | 估值 | 支撑 | 止损 | 第一目标 |")
    lines.append("|---|---|---|---|---|---|---|---|---|---|---|---|---|")
    for r in rows:
        s, d = r["s"], r["dims"]
        sup = s.support
        stop = f"{sup * STOP_PCT:.2f}" if sup else "-"
        tgt = f"{s.hh():.2f}" if s.kline else "-"
        ch = " ⚠️追高" if r["chased"] else ""
        lines.append(
            f"| {s.name} | {s.code} | **{r['total']}**{ch} | {rating_of(r['total'])} | "
            f"{d['trend'][0]} | {d['pos'][0]} | {d['mom'][0]} | {d['rr'][0]} | "
            f"{d['theme'][0]} | {d['val'][0]} | "
            f"{sup:.2f} | {stop} | {tgt} |"
        )
    lines.append("\n### 逐只明细\n")
    for r in rows:
        s, d = r["s"], r["dims"]
        lines.append(f"**{s.name}({s.code}) = {r['total']}分 {rating_of(r['total'])}**（现价 {s.px}）")
        for k, label in (("trend", "趋势"), ("pos", "位置"), ("mom", "动能"), ("rr", "盈亏比"), ("theme", "题材"), ("val", "估值")):
            sc, why = d[k]
            if why:
                lines.append(f"- {label} {sc}: {why}")
        if r["chased"]:
            lines.append(f"- ⚠️ **追高修正扣{r['chase']}分**: 现价距买点>8%且现价口径R:R<1.0, 已远离买点, 现价追高风险高")
        if s.notes:
            lines.append(f"- 数据告警: {'; '.join(s.notes)}")
        if r["warns"]:
            lines.append(f"- ⚠️ 一致性校验未过: {'; '.join(r['warns'])}（需人工复核）")
        lines.append("")

    report = "\n".join(lines)
    print(report)
    if out_path:
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(report + "\n")
        print(f"\n[已写入] {out_path}", file=sys.stderr)
    append_history(history_path, rows)


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="输入JSON路径")
    ap.add_argument("--out", help="输出Markdown路径(可选)")
    ap.add_argument("--rsi-window", default="RSI_6", choices=["RSI_2", "RSI_6", "RSI_12", "RSI_24"])
    ap.add_argument("--history", help="历史快照JSONL路径(回测落库, 可选)")
    ap.add_argument("--score-date", default="", help="评分交易日 YYYY-MM-DD, 写入快照date字段(建议填K线最后交易日)")
    args = ap.parse_args()
    RSI_WINDOW = args.rsi_window
    run(args.input, args.out, history_path=args.history, score_date=args.score_date)
