#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
筹码峰重建引擎 —— 三角形分布 + 换手率逐日衰减模型

用法:
  python chip_peak.py --kline kline_sh600415.json \
      --official "12.27,84.08,10.24,21.78" --out chip_result.json

参数:
  --kline      K线JSON。支持 westock data_kline 原始返回 {"ok":true,"data":{"nodes":[...]}}
               也支持直接的 nodes 数组。必需字段: date/high/low/last(或close)/exchange(换手率%)
  --official   官方筹码指标 "平均成本,获利盘%,集中度70,集中度90"，来自 westock data_chip。
               可选，但强烈建议提供 —— 用于交叉验证重建质量（这是本方法可信度的唯一客观依据）
  --out        输出 JSON 路径（默认 chip_result.json）
  --days       使用最近 N 个交易日（默认 250）
  --step       价格网格步长（元，默认 0.02）
  --lags       峰迁移对比的历史快照间隔（交易日，默认 "10,20,60"）

输出 JSON 字段:
  last_close / date / n_days / chip(list) / prices(list) / stats / official / peaks /
  below / above / zones / hist / view_lo / view_hi

算法说明见 ../references/method.md
"""
import argparse
import json
import math


def load_bars(path):
    with open(path, encoding="utf-8") as f:
        raw = json.load(f)
    if isinstance(raw, list):
        nodes = raw
    elif isinstance(raw, dict):
        nodes = raw.get("data", {}).get("nodes") if "data" in raw else raw.get("nodes", [])
        if nodes is None:
            raise SystemExit("无法从 K 线文件中定位 nodes 数组")
    else:
        raise SystemExit("K 线文件格式不支持")
    bars = []
    for n in nodes:
        d = n.get("date")
        hi = float(n.get("high"))
        lo = float(n.get("low"))
        cl = float(n.get("last", n.get("close")))
        ex = float(n.get("exchange", 0) or 0) / 100.0   # 换手率百分比 -> 比例
        bars.append({"date": d, "high": hi, "low": lo, "close": cl, "turn": ex})
    bars.sort(key=lambda b: b["date"])
    return bars


def tri_cdf(p, low, peak, high):
    """三角形分布的累积分布函数（总积分为 1）。"""
    p = min(max(p, low), high)
    if high <= low:
        return 0.0
    if peak <= low or peak >= high:
        return (p - low) / (high - low)
    if p <= peak:
        return (p - low) ** 2 / ((high - low) * (peak - low))
    return 1 - (high - p) ** 2 / ((high - low) * (high - peak))


class ChipModel:
    def __init__(self, bars, step=0.02):
        self.bars = bars
        self.step = step
        self.p_lo = math.floor(min(b["low"] for b in bars) / step) * step
        self.p_hi = math.ceil(max(b["high"] for b in bars) / step) * step
        self.nb = int(round((self.p_hi - self.p_lo) / step)) + 1
        self.prices = [self.p_lo + i * step for i in range(self.nb)]

    def build(self, upto=0):
        """重建筹码分布。upto=N 表示回溯至倒数第 N+1 个交易日收盘后的状态。"""
        seq = self.bars if upto <= 0 else self.bars[:len(self.bars) - upto]
        chip = [0.0] * self.nb
        for r in seq:
            t = r["turn"]
            lo, hi, cl = r["low"], r["high"], r["close"]
            chip = [c * (1 - t) for c in chip]           # 历史筹码按换手率衰减
            peak = (hi + lo + cl) / 3.0                  # 三角形顶点 = 当日均价
            if hi <= lo:                                 # 一字板退化处理
                idx = min(self.nb - 1, max(0, int(round((lo - self.p_lo) / self.step))))
                chip[idx] += t
                continue
            i0 = max(0, int(math.floor((lo - self.p_lo) / self.step)))
            i1 = min(self.nb - 1, int(math.ceil((hi - self.p_lo) / self.step)))
            for i in range(i0, i1 + 1):
                a = self.p_lo + i * self.step - self.step / 2
                b = a + self.step
                chip[i] += t * (tri_cdf(b, lo, peak, hi) - tri_cdf(a, lo, peak, hi))
        tot = sum(chip)
        if tot > 0:
            chip = [c / tot for c in chip]
        return chip

    def stats(self, chip, close):
        tot = sum(chip)
        if tot <= 0:
            return None
        avg = sum(c * p for c, p in zip(chip, self.prices)) / tot
        profit = sum(c for c, p in zip(chip, self.prices) if p < close) / tot * 100

        def conc(ratio):
            target = tot * ratio
            best, s, j = None, 0.0, 0
            for i in range(self.nb):
                while j < self.nb and s < target:
                    s += chip[j]
                    j += 1
                if s >= target:
                    lo_p, hi_p = self.prices[i], self.prices[j - 1]
                    w = (hi_p - lo_p) / (hi_p + lo_p) * 100 if (hi_p + lo_p) > 0 else 0
                    if best is None or w < best[0]:
                        best = (w, lo_p, hi_p)
                s -= chip[i]
            return best

        return {"avg": avg, "profit": profit, "c70": conc(0.70), "c90": conc(0.90)}

    def smooth(self, chip, w=4):
        out = [0.0] * len(chip)
        for i in range(len(chip)):
            a, b = max(0, i - w), min(len(chip), i + w + 1)
            out[i] = sum(chip[a:b]) / (b - a)
        return out

    def peaks(self, chip, min_ratio=0.12, min_gap=8, topn=5):
        s = self.smooth(chip, 4)
        mx = max(s) or 1e-12
        cand = [(s[i], i) for i in range(1, self.nb - 1)
                if s[i] >= s[i - 1] and s[i] >= s[i + 1] and s[i] >= mx * min_ratio]
        cand.sort(reverse=True)
        picked = []
        for v, i in cand:
            if all(abs(i - j) >= min_gap for _, j in picked):
                picked.append((v, i))
            if len(picked) >= topn:
                break
        return [(self.prices[i], v * 100) for v, i in picked]

    def view_range(self, chip, lo_q=0.005, hi_q=0.975, pad=0.03):
        """自动确定绘图显示区间：按筹码累积分位截取，避免长尾空白。"""
        tot = sum(chip) or 1e-12
        acc, lo_p, hi_p = 0.0, self.prices[0], self.prices[-1]
        for c, p in zip(chip, self.prices):
            acc += c / tot
            if acc >= lo_q and lo_p == self.prices[0]:
                lo_p = p
            if acc >= hi_q:
                hi_p = p
                break
        span = max(hi_p - lo_p, 1e-6)
        return round(max(lo_p - span * pad, self.prices[0]), 2), round(min(hi_p + span * pad, self.prices[-1]), 2)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kline", required=True)
    ap.add_argument("--official", default="")
    ap.add_argument("--out", default="chip_result.json")
    ap.add_argument("--days", type=int, default=250)
    ap.add_argument("--step", type=float, default=0.02)
    ap.add_argument("--lags", default="10,20,60")
    a = ap.parse_args()

    bars = load_bars(a.kline)[-a.days:]
    m = ChipModel(bars, a.step)
    last_close = bars[-1]["close"]
    cur = m.build()
    st = m.stats(cur, last_close)
    peaks = m.peaks(cur)

    official = None
    if a.official:
        p = [float(x) for x in a.official.split(",")]
        official = {"avg": p[0], "profit": p[1], "c70": p[2], "c90": p[3]}

    # 峰迁移快照
    hist = {}
    for lag in [int(x) for x in a.lags.split(",") if x.strip()]:
        if len(bars) - lag <= 30:
            continue
        c = m.build(upto=lag)
        b = bars[len(bars) - 1 - lag]
        hs = m.stats(c, b["close"])
        hist[f"{lag}日前"] = {"date": b["date"], "close": b["close"], "chip": c,
                              "avg": hs["avg"], "profit": hs["profit"],
                              "c70": hs["c70"][0], "peaks": m.peaks(c)}

    below = sum(c for c, p in zip(cur, m.prices) if p < last_close) * 100

    # 关键价位堆积：主峰/次峰/现价/90%上下沿
    def dens(lo, hi):
        return sum(c for c, p in zip(cur, m.prices) if lo <= p <= hi) * 100

    zones = []
    for rank, (p, _) in enumerate(peaks[:3], 1):
        zones.append((f"峰{rank} {p:.2f}", dens(p - 0.08, p + 0.08)))
    zones.append((f"{last_close:.2f} (现价)", dens(last_close - 0.08, last_close + 0.08)))
    if official:
        zones.append((f"{official['avg']:.2f} (官方均本)", dens(official["avg"] - 0.08, official["avg"] + 0.08)))

    v_lo, v_hi = m.view_range(cur)

    out = {
        "date": bars[-1]["date"], "last_close": last_close, "n_days": len(bars),
        "p_lo": m.p_lo, "p_hi": m.p_hi, "step": m.step, "nb": m.nb,
        "prices": m.prices, "chip": cur,
        "stats": st, "official": official, "peaks": peaks,
        "below": below, "above": 100 - below, "zones": zones,
        "view_lo": v_lo, "view_hi": v_hi,
        "hist": hist,
    }
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False)

    # ---- 控制台摘要 ----
    print("=" * 62)
    print(f"基准日 {bars[-1]['date']}  收盘 {last_close:.2f}  样本 {len(bars)} 日")
    print(f"价格网格 {m.p_lo:.2f}~{m.p_hi:.2f}  步长 {m.step}  ({m.nb} 箱)")
    print("=" * 62)
    if official:
        print(f"{'指标':<12}{'模型值':>11}{'官方值':>11}{'偏差':>11}{'判定':>9}")
        print("-" * 62)
        tol = [("平均成本", st["avg"], official["avg"], 0.5),
               ("获利盘 %", st["profit"], official["profit"], 3.0),
               ("集中度 70", st["c70"][0], official["c70"], 1.0),
               ("集中度 90", st["c90"][0], official["c90"], 3.0)]
        for n, mv, ov, t in tol:
            d = mv - ov
            print(f"{n:<12}{mv:>11.2f}{ov:>11.2f}{d:>+11.2f}{'  OK' if abs(d) < t else '  偏差大':>9}")
        print("=" * 62)
        bad = sum(1 for n, mv, ov, t in tol if abs(mv - ov) >= t)
        if bad:
            print(f"!! {bad}/4 项超出容差，重建结果不可靠，检查 K 线是否复权/换手率缺失")
    else:
        print(f"平均成本 {st['avg']:.2f}   获利盘 {st['profit']:.2f}%   "
              f"集中度70 {st['c70'][0]:.2f}   集中度90 {st['c90'][0]:.2f}")
        print("=" * 62)
        print("!! 未提供 --official，无法交叉验证，结论请谨慎使用")
    print(f"获利盘 {below:.2f}%   套牢盘 {100-below:.2f}%")
    print(f"70% 筹码区间 {st['c70'][1]:.2f} ~ {st['c70'][2]:.2f}")
    print(f"90% 筹码区间 {st['c90'][1]:.2f} ~ {st['c90'][2]:.2f}")
    print("-" * 62)
    print("筹码峰（按密度排序）:")
    for i, (p, d) in enumerate(peaks, 1):
        print(f"  峰{i}: {p:>7.2f}   相对密度 {d:>5.2f}   距现价 {(p/last_close-1)*100:>+6.1f}%")
    print("-" * 62)
    print("关键价位筹码堆积 (±0.08 元):")
    for n, d in zones:
        print(f"  {n:<20} {d:>6.2f}%")
    if hist:
        print("-" * 62)
        for k, v in hist.items():
            pk = v["peaks"][0][0] if v["peaks"] else float("nan")
            print(f"{k:<8}({v['date']}) 收盘 {v['close']:>6.2f}  主峰 {pk:>6.2f}  "
                  f"均本 {v['avg']:>6.2f}  获利盘 {v['profit']:>5.1f}%  集中度70 {v['c70']:.1f}")
    print("=" * 62)
    print(f"主峰迁移方向: ", end="")
    if hist:
        seq_names = sorted(hist.keys(), key=lambda k: -int(k.replace("日前", "")))
        seq = [hist[k]["peaks"][0][0] for k in seq_names if hist[k]["peaks"]]
        seq.append(peaks[0][0])
        print(" -> ".join(f"{x:.2f}" for x in seq))
    else:
        print("无历史快照")


if __name__ == "__main__":
    main()
