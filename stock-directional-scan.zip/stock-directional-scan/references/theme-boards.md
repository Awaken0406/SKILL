# 板块码参考与扫描参数

本文件给出「定向扫描」的输入：策略名 + 主板/非ST 过滤规则 + 参考板块码表。**全板块模式（默认）下通道A 不限板块**，下表板块码仅作题材归类参考或按需定向板块时使用。

## 1. 参考板块 universe 码（非强制，仅按需定向用）

| 板块 | universe 码 |
|------|-------------|
| 半导体 | pt01801081 |
| 光学光电子 | pt01801084 |
| 通信设备 | pt01801102 |
| 人形机器人 | pt02GN2238 |
| 元件 | pt01801083 |
| 存储器 | pt02GN2124 |
| 汽车零部件 | pt01801093 |
| 通用设备 | pt01801156 |

> **默认不依赖此表**：通道A 用 `tool_ranking(within_strategy=ma_long)` 全市场扫描，覆盖所有板块。仅在用户明确要"只看某板块"时，用 `data_sector(mode=constituent)` 拉该板块成分做交集，或临时给 `universe`。

## 2. 策略名与固定通道

- 干净多头策略：`ma_long`（与 `tool_ranking` 的 `within_strategy` 参数对应）
- 涨停策略：`today_first_limitup`（当日首板）/ `today_continue_limitup`（连板，按需）
- 先用 `tool_list_strategies` 确认可用且非付费 unavailable；若改名以接口返回为准。

**人气热度双榜 + 当日涨停固定通道**（每次扫描必调）：

```
data_hot(kind=stock, limit=50)   # 通道B1: 场内个股人气热度榜
data_hot(kind=wechat, limit=50)  # 通道B2: 微信端讨论热度榜
tool_ranking(metric=CompScore, within_strategy=today_first_limitup, order=desc, limit=100)  # 通道C: 当日首板涨停池
```

- **为什么双榜**：`data_hot` 后端单榜硬顶 50 只（2026-09-01 实测 limit=100 仍只返回 50）。双榜并集 ≈70-80 只、约 1/3 重叠，是接口能力内最接近"人气前100"的覆盖；wechat 榜常带来只在其上的权重热门票（工业富联/沪电股份/新易盛/中科曙光等）。
- **为什么 today_first_limitup（首板）**：涨停池另有 `today_continue_limitup`（连板）可选；默认首板为主——连板股追高执行风险极大（评分会被执行风险否决自动压档），只在用户明确要"打板/连板"场景时加拉连板池。
- **通道B/C 均不受干净多头(ma_long)条件限制**：热度股/涨停股无论趋势/形态一律入池，交由六维评分与否决规则去劣汰（涨停会触发执行风险否决→评级压到轻仓试探，属正确行为）。
- **去重与排名标注**：两榜同榜股按代码去重，排名标 `股榜#N/微榜#M`；排序用两榜中更靠前的名次；涨停股标 `来源=涨停`，多通道重叠标组合（如 `涨停+多头`）。
- 与通道A（全市场多头）按代码去重合并。
- 港股（hk 开头）、北交所（bj 开头）与 ETF（stock_type=ETF）剔除；`kind=stock`/`wechat` 为个股榜，`board` 为板块热度、`news` 为新闻热度，均不要混用。

## 3. 主板 / 非ST 过滤规则

`tool_ranking(universe=板块码, within_strategy=ma_long)` 返回的是该板块内命中策略的全部股票，需二次过滤：

**保留（主板非ST）**：
- 沪市主板：`sh60xxxx`（60 开头）
- 深市主板：`sz000xxx` / `sz001xxx` / `sz002xxx` / `sz003xxx`

**剔除**：
- 科创板：`sh688xxx`
- 创业板：`sz300xxx` / `sz301xxx`
- 北交所：`bjxxxxxx`
- ST / *ST：名称或代码含 ST 标记

> 目的：只保留主板、非 ST 的标的，规避涨跌停限制差异与退市风险。该过滤对**三条通道（全市场多头 + 人气热度双榜 + 当日涨停）统一生效**——热度榜/涨停池中的创业板/科创板/北交所/ST/港股/ETF 同样剔除。

## 4. 扫描路径（标准执行序）

```
通道A（全市场多头）:
    tool_ranking(metric=CompScore, within_strategy=ma_long, order=desc, limit=400)
    -> 全市场干净多头排行（覆盖所有板块）-> 通道A候选池
通道B（人气热度双榜，固定必调，不受 ma_long 限制）:
    data_hot(kind=stock, limit=50) + data_hot(kind=wechat, limit=50)
    -> 双榜并集去重(≈70-80只) -> 解析代码+双榜排名 -> 通道B候选池
通道C（当日涨停，固定必调，不受 ma_long 限制）:
    tool_ranking(metric=CompScore, within_strategy=today_first_limitup, order=desc, limit=100)
    -> 解析代码 -> 通道C候选池（盘中跑=当日实时，收盘后=全天，周末=最近交易日）
通道A ∪ 通道B ∪ 通道C -> 按代码去重合并（保留双榜人气排名/涨停标记与来源通道）
-> 剔除 hk/bj/ETF -> 主板非ST过滤 -> 最终候选（典型 40-90 只；超出精算预算时按 名次+涨停优先+估值有锚 截取，尽量覆盖多板块）
对每只最终候选:
    并行 data_quote / data_technical(ma,kdj,macd,rsi) / data_kline(day,qfq,limit=120)
    -> 按 scoring.md 六维精算购买指数
-> 纯文本汇总表（含来源通道/双榜人气排名列 + 「热门但不买」名单 + 「涨停观察池」）+ 90+ 稀缺根因说明
```

## 5. metric 取值说明

- 默认用 `CompScore`（综合评分）作为排行指标；若不确定可用 `tool_list_ranking_metrics` 列出股票类可用指标再选。
- `within_strategy` 与 `within_label` / `within_event` 互斥，扫描只用 `within_strategy=ma_long`。
- `date` 默认今天；复盘历史日可传 `YYYY-MM-DD`。
