# -*- coding: utf-8 -*-
"""
把 analyze_index.py 的统计结果 + 人工研判配置渲染成 HTML 研报。

用法:
    python gen_report.py --kline kline.json --stats stats.json --config config.json [--out xxx.html]

说明:
  - 模板用 __XXX__ 占位符 + replace 替换，规避 % 格式化与 CSS/JS 字面 % 的冲突。
  - 渲染后自动抽取内联 <script> 做 node --check 语法校验，不通过则报错退出。
"""
import argparse, json, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_TPL = os.path.join(HERE, "..", "assets", "report-template.html")


# ---------------- 通用渲染助手 ----------------
def esc_num(v):
    """按正负号给数字单元格上色（A股：红涨绿跌）。"""
    s = str(v).strip()
    if s.startswith("+"):
        return '<span class="up">%s</span>' % s
    if s.startswith("-"):
        return '<span class="dn">%s</span>' % s
    return s


def kpi_html(items):
    out = []
    for it in items or []:
        out.append('<div class="kpi"><div class="lb">%s</div>'
                   '<div class="vl %s">%s</div><div class="ex">%s</div></div>'
                   % (it.get("lb", ""), it.get("cls", ""), it.get("vl", ""), it.get("ex", "")))
    return "".join(out)


def table_html(head, rows, num_cols=None):
    """num_cols: 需要右对齐+按正负着色的列索引集合。"""
    num_cols = num_cols or set()
    h = "".join('<th class="%s">%s</th>' % ("num" if i in num_cols else "", c)
                for i, c in enumerate(head))
    body = []
    for r in rows:
        tds = []
        for i, c in enumerate(r):
            cls = "num" if i in num_cols else ""
            val = esc_num(c) if i in num_cols else c
            tds.append('<td class="%s">%s</td>' % (cls, val))
        body.append("<tr>%s</tr>" % "".join(tds))
    return ('<table><thead><tr>%s</tr></thead><tbody>%s</tbody></table>'
            % (h, "".join(body)))


def badges_html(items):
    out = []
    for txt, kind in items or []:
        out.append('<span class="badge b-%s">%s</span>' % (kind, txt))
    return "".join(out)


def sector_strength_html(res):
    """板块强度模块：近 5 / 10 交易日的最强、最弱 TOP N（涨幅 + 资金流双维度）。"""
    if not res:
        return ""
    out = []
    for win in ("5", "10"):
        w = (res.get("windows") or {}).get(win)
        if not w or not w.get("top"):
            continue
        ff = w.get("flow_field", "")
        flow_label = "5 日主力净流入" if ff == "flow5" else "20 日主力净流入（近似）"
        head = ["板块", "%s 日涨幅" % win, "%s（亿元）" % flow_label, "强度"]

        def mkrows(items):
            return [[r["name"], "%+.2f%%" % r["chg"],
                     "%+.2f" % r["flow"], "%.1f" % r["strength"]] for r in items]

        out.append('<div style="margin-top:14px;font-weight:600">'
                   '近 %s 个交易日 · 最强 TOP%d</div>' % (win, len(w["top"])))
        out.append(table_html(head, mkrows(w["top"]), {1, 2, 3}))
        out.append('<div style="margin-top:14px;font-weight:600">'
                   '近 %s 个交易日 · 最弱 TOP%d</div>' % (win, len(w["bottom"])))
        out.append(table_html(head, mkrows(w["bottom"]), {1, 2, 3}))
    return "".join(out)


def futures_html(res):
    """股指期货席位持仓：中信席位 + 机构（前 20 会员合计）今日净开多 / 净开空。"""
    if not res:
        return ""
    meta = res.get("meta", {})
    SEP = '<div style="font-weight:600;margin:16px 0 8px">%s</div>'
    head = ["品种", "主力合约", "多单", "空单", "净持仓", "多单增减", "空单增减", "净变动"]
    num_cols = {2, 3, 4, 5, 6, 7}

    def sign(x):
        return "%+d" % x

    def rows_of(by_product, mains, key):
        rows = []
        for p, r in by_product.items():
            o = r[key]
            rows.append(["%s %s" % (p, r.get("cn", "")), mains.get(p, "-"),
                         "{:,}".format(o["long"]), "{:,}".format(o["short"]),
                         "{:,}".format(o["net"]), sign(o["d_long"]),
                         sign(o["d_short"]), sign(o["d_net"])])
        return rows

    def total_row(o, label):
        return [label, "—", "{:,}".format(o["long"]), "{:,}".format(o["short"]),
                "{:,}".format(o["net"]), sign(o["d_long"]), sign(o["d_short"]),
                sign(o["d_net"])]

    out = []
    mains = meta.get("main_contract", {})

    # --- 判定摘要 ---
    vd = res.get("verdict", {})
    for label, k in (("中信期货席位", "seat_main"), ("中信期货席位（全合约）", "seat_all"),
                     ("机构整体（前 20 会员）", "inst_main"),
                     ("机构整体（前 20 会员·全合约）", "inst_all")):
        v = vd.get(k)
        if not v:
            continue
        cls = {"up": "up", "dn": "dn"}.get(v.get("cls"), "")
        out.append('<div style="display:flex;justify-content:space-between;gap:12px;'
                   'padding:6px 0;border-bottom:1px dashed #eef0f2;font-size:13.5px">'
                   '<span style="color:#4b5563">%s</span><span class="%s">%s</span></div>'
                   % (label, cls, v["text"]))

    seat = res.get("seat", {})
    inst = res.get("institutions", {})
    out.append(SEP % "中信期货席位（%s）· 主力合约" % seat.get("name", "中信期货"))
    out.append(table_html(head, rows_of(seat.get("by_product", {}), mains, "main")
                          + [total_row(seat["total_main"], "四品种合计")], num_cols))

    out.append(SEP % "机构整体（各品种已披露前 20 会员合计）· 主力合约")
    out.append(table_html(head, rows_of(inst.get("by_product", {}), mains, "main")
                          + [total_row(inst["total_main"], "四品种合计")], num_cols))

    movers = res.get("top_movers") or []
    if movers:
        out.append(SEP % "当日净变动最大的席位 TOP%d（全合约口径）" % len(movers))
        out.append(table_html(["席位", "多单", "空单", "净持仓", "多单增减", "空单增减", "净变动"],
                              [[m["name"], "{:,}".format(m["long"]), "{:,}".format(m["short"]),
                                "{:,}".format(m["net"]), sign(m["d_long"]),
                                sign(m["d_short"]), sign(m["d_net"])] for m in movers],
                              {1, 2, 3, 4, 5, 6}))

    out.append('<div class="note">口径：中金所每日会员成交持仓排名（经纪业务"代客"，不含自营）；'
               '主力合约＝当日成交量最大的合约，全合约＝该品种全部挂牌合约合计；'
               '增减＝较上一交易日变动手数。仅披露各品种成交/持买/持卖前 20 名会员，非全市场总量。'
               '数据日：%s。</div>' % meta.get("date", ""))
    return "".join(out)


def paras_html(items):
    if isinstance(items, str):
        return items
    return "".join(items or [])


# ---------------- 数据准备 ----------------
def load_nodes(path):
    d = json.load(open(path, "r", encoding="utf-8"))
    if isinstance(d, list):
        nodes = d
    elif isinstance(d, dict) and "nodes" in d:
        nodes = d["nodes"]
    elif isinstance(d, dict) and "data" in d:
        nodes = d["data"]["nodes"] if isinstance(d["data"], dict) else d["data"]
    else:
        raise ValueError("无法识别的 K 线格式")
    nodes = sorted(nodes, key=lambda x: x["date"])

    def g(n, *ks):
        for k in ks:
            if k in n and n[k] is not None:
                return float(n[k])
        return 0.0
    return nodes, g


def ma_series(close, n, i):
    if i + 1 < n:
        return None
    return sum(close[i - n + 1:i + 1]) / n


# ---------------- 主流程 ----------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kline", required=True)
    ap.add_argument("--stats", required=True)
    ap.add_argument("--config", required=True)
    ap.add_argument("--out", default=None)
    ap.add_argument("--template", default=DEFAULT_TPL)
    ap.add_argument("--no-check", action="store_true", help="跳过 node 语法校验")
    ap.add_argument("--sectors", default=None,
                    help="板块强度 JSON（sector_strength.py 输出，可选；不传则板块强度模块留空）")
    ap.add_argument("--futures", default=None,
                    help="股指期货席位持仓 JSON（futures_position.py 输出，可选；"
                         "不传则该整节不渲染）")
    args = ap.parse_args()

    cfg = json.load(open(args.config, "r", encoding="utf-8"))
    _st = cfg.get("stats") or {}   # 2.1 已从模板移除，config 可不带该字段
    stats = json.load(open(args.stats, "r", encoding="utf-8"))
    nodes, g = load_nodes(args.kline)

    close = [g(n, "last", "close") for n in nodes]
    N = len(close)
    recent = nodes[-30:]
    W = int(cfg.get("ma_window") or stats.get("meta", {}).get("ma_window") or 60)
    dates = [n["date"][5:] for n in recent]
    ohlc = [[round(g(n, "open"), 2), round(g(n, "last", "close"), 2),
             round(g(n, "low"), 2), round(g(n, "high"), 2)] for n in recent]
    ma20 = [round(ma_series(close, 20, N - len(recent) + k), 2) for k in range(len(recent))]
    maline = [round(ma_series(close, W, N - len(recent) + k), 2) for k in range(len(recent))]

    C = float(stats["meta"]["close"])

    # --- 板块强度（可选模块，来自 sector_strength.py） ---
    sec_res = None
    if args.sectors:
        try:
            sec_res = json.load(open(args.sectors, "r", encoding="utf-8"))
        except Exception as e:
            print("[warn] 板块强度读取失败，模块留空:", e)
            sec_res = None
    # --- 股指期货席位持仓（可选模块，来自 futures_position.py） ---
    fut_res = None
    if args.futures:
        try:
            fut_res = json.load(open(args.futures, "r", encoding="utf-8"))
        except Exception as e:
            print("[warn] 期指席位持仓读取失败，模块留空:", e)
            fut_res = None
    futures_block = ""
    if fut_res:
        note = cfg.get("futures", {}).get("note") or fut_res.get("hint", "")
        futures_block = ('<h3>1.7 股指期货席位持仓：中信与机构今日净开多 / 净开空</h3>'
                         '<div class="card">%s</div>'
                         '<div class="card" style="margin-top:14px">%s</div>'
                         % (futures_html(fut_res), note))

    sector_note = ""
    if sec_res:
        sector_note = ("共 %d 个申万一级板块参与排名；%s"
                       % (sec_res.get("n_sectors", 0), sec_res.get("note", "")))

    # --- 板块图 ---
    sec_up = cfg.get("sectors", {}).get("up", [])
    sec_dn = cfg.get("sectors", {}).get("dn", [])
    sec_names = [s[0] for s in sec_dn[::-1]] + [s[0] for s in sec_up[::-1]]
    sec_vals = [s[1] for s in sec_dn[::-1]] + [s[1] for s in sec_up[::-1]]

    # --- 情景表与图 ---
    scen = cfg.get("scen", [])
    scen_rows, scen_labels, scen_vals, scen_data = [], [], [], []
    PAL_UP = "#c0392b"
    PAL_DN = "#128a55"
    for name, pt, prob in scen:
        chg = (pt / C - 1) * 100
        cls = "up" if chg > 0.02 else ("dn" if chg < -0.02 else "flat")
        scen_rows.append([name, "%d" % pt, "%+.2f%%" % chg, "%d%%" % prob])
        scen_labels.append(name)
        scen_vals.append(prob)
        if chg > 0.4:
            col = PAL_UP
        elif chg > 0.02:
            col = "#e08b8b"
        elif chg < -0.4:
            col = PAL_DN
        elif chg < -0.02:
            col = "#5cb85c"
        else:
            col = "#9ca3af"
        scen_data.append({"value": prob, "itemStyle": {"color": col}})

    # --- 点位阶梯 ---
    lad = []
    for px, tag, kind, desc in cfg.get("ladder", []):
        tcls = {"r": "t-r", "g": "t-g", "n": "t-n"}.get(kind, "t-n")
        rcls = {"r": "r-r", "g": "r-g", "n": "r-n"}.get(kind, "r-n")
        lad.append('<div class="rung %s"><span class="px">%s</span>'
                   '<span class="tg %s">%s</span><span class="ds">%s</span></div>'
                   % (rcls, px, tcls, tag, desc))

    tpl = open(args.template, "r", encoding="utf-8").read()

    html = (tpl
            .replace("__TITLE__", cfg["title"])
            .replace("__SUBTITLE__", cfg.get("subtitle", ""))
            .replace("__TLDR__", paras_html(cfg.get("tldr")))
            .replace("__BADGES__", badges_html(cfg.get("badges")))
            .replace("__KPI__", kpi_html(cfg.get("kpi")))
            .replace("__INTRADAY__", paras_html(cfg.get("intraday")))
            .replace("__INDICES__", table_html(cfg["indices"]["head"], cfg["indices"]["rows"],
                                               {1, 2, 3, 4, 5}))
            .replace("__SECTORS__", table_html(cfg["sectors"].get("head", ["方向", "代表板块", "资金特征"]),
                                               cfg["sectors"].get("rows", [])))
            .replace("__SECTORSTRENGTH__", sector_strength_html(sec_res))
            .replace("__SECTORSTRENGTH_NOTE__", sector_note)
            .replace("__BREADTH_KPI__", kpi_html(cfg.get("breadth", {}).get("kpi")))
            .replace("__BREADTH_NOTE__", paras_html(cfg.get("breadth", {}).get("note")))
            .replace("__TECH__", table_html(cfg["tech"]["ma"]["head"], cfg["tech"]["ma"]["rows"], {1, 2})
                     + table_html(cfg["tech"]["ind"]["head"], cfg["tech"]["ind"]["rows"]))
            .replace("__TECH_NOTE__", cfg.get("tech", {}).get("note", ""))
            .replace("__CAPITAL_KPI__", kpi_html(cfg.get("capital", {}).get("kpi")))
            .replace("__CAPITAL_NOTE__", paras_html(cfg.get("capital", {}).get("note")))
            .replace("__FUTURES_BLOCK__", futures_block)
            .replace("__STATS__", (table_html(_st.get("head", []), _st.get("rows", []), {1, 2, 3, 4})
                                   + '<div class="note">%s</div>' % _st.get("note", ""))
                     if _st else "")
            .replace("__VOLTABLE__", "".join("<tr><td>%s</td><td class=\"num\">%s</td></tr>" % (a, b)
                                             for a, b in cfg.get("vol", {}).get("rows", [])))
            .replace("__VOLNOTE__", cfg.get("vol", {}).get("note", ""))
            .replace("__SCENTABLE__", table_html(["情景", "收盘参考位", "相对现价", "概率"],
                                                 scen_rows, {1, 2, 3})
                     + paras_html(cfg.get("scen_note")))
            .replace("__LADDER__", "".join(lad))
            .replace("__EVENTS__", table_html(cfg["events"]["head"], cfg["events"]["rows"])
                     + '<div class="note">%s</div>' % cfg.get("events", {}).get("note", ""))
            .replace("__DECISIONS__", table_html(cfg["decisions"]["head"], cfg["decisions"]["rows"]))
            .replace("__RISKS__", "".join("<li>%s</li>" % r for r in cfg.get("risks", [])))
            .replace("__SOURCES__", "".join('<span class="pill">%s</span>' % s
                                            for s in cfg.get("sources", [])))
            .replace("__SEC_N__", json.dumps(sec_names, ensure_ascii=False))
            .replace("__SEC_V__", json.dumps(sec_vals))
            .replace("__DATES__", json.dumps(dates, ensure_ascii=False))
            .replace("__OHLC__", json.dumps(ohlc))
            .replace("__MA20__", json.dumps(ma20))
            .replace("__MALINE__", json.dumps(maline))
            .replace("__SCEN_L__", json.dumps(scen_labels, ensure_ascii=False))
            .replace("__SCEN_V__", json.dumps(scen_data)))

    out = args.out or cfg.get("out") or "index_forecast.html"
    with open(out, "w", encoding="utf-8") as f:
        f.write(html)
    print("WROTE %s (%d bytes)" % (out, os.path.getsize(out)))

    # --- 自检 ---
    left = re.findall(r"__[A-Z0-9_]+__", html)
    if left:
        print("!! 残留占位符:", set(left))
    else:
        print("占位符自检: 全部替换 OK")
    print("div 开=%d 闭=%d" % (html.count("<div"), html.count("</div>")))

    if not args.no_check:
        m = re.search(r"<script>\s*\n(.*?)\n</script>", html, re.DOTALL)
        if not m:
            print("!! 未找到内联 script，跳过校验")
            return
        import tempfile
        tmp = os.path.join(tempfile.gettempdir(), "_idxfc_check.js")
        with open(tmp, "w", encoding="utf-8") as tf:
            tf.write(m.group(1))
        try:
            r = subprocess.run(["node", "--check", tmp], capture_output=True, text=True, shell=True)
        except FileNotFoundError:
            print("!! 未找到 node，跳过 JS 校验（请确认 node 在 PATH 中）")
            return
        try:
            os.remove(tmp)   # 沙箱可能拦截删除，失败不影响交付
        except Exception:
            pass
        if r.returncode == 0:
            print("JS 语法校验: OK")
        else:
            print("!! JS 语法错误:\n%s\n%s" % (r.stdout, r.stderr))
            sys.exit(1)


if __name__ == "__main__":
    main()
