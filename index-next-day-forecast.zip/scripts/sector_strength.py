#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""板块强度排名（申万一级，5 / 10 交易日窗口）

强度 = 涨幅 + 资金流入，两个维度各自转为「排名分位」后取平均，避免极端值主导。

数据来源约定（由调用方先落盘成 JSON）：
  1) sw1 清单      data_sector(mode=list, scope=industry_list_sw1)          -> {code, name}
  2) 细分行业排行  data_sector(mode=ranking, kind=industry, type=changePct) -> rows[].mainNetInflow5d/20d
  3) 各板块日 K 线 data_kline(code=ptXXXXXXXX, period=day, limit>=11)       -> 用于算 5/10 日涨幅

关键机制：申万一级与细分行业代码存在「前缀关系」——
  一级 电子 pt01801080  ->  半导体 pt01801081 / 元件 pt01801083 / 消费电子 pt01801085 ...
即 细分行业代码 = 一级代码去掉末尾的 0 后再接序号。
因此按前缀把细分行业的资金流求和，即得到该一级板块的资金流。

用法：
  python sector_strength.py --input sectors_raw.json --out sectors.json [--top 5]
"""
import argparse, json, io, sys


def yi(wan):
    """接口资金单位为万元，转亿元字符串。"""
    try:
        return wan / 10000.0
    except Exception:
        return 0.0


def pct_rank(values):
    """返回每个元素在该序列中的分位（0~100，越大越强），并列取平均名次。"""
    n = len(values)
    if n == 0:
        return []
    order = sorted(range(n), key=lambda i: values[i])
    ranks = [0.0] * n
    i = 0
    while i < n:
        j = i
        while j + 1 < n and values[order[j + 1]] == values[order[i]]:
            j += 1
        avg_rank = (i + j) / 2.0          # 并列取平均
        for k in range(i, j + 1):
            ranks[order[k]] = avg_rank
        i = j + 1
    # 转分位 0~100
    if n > 1:
        return [r * 100.0 / (n - 1) for r in ranks]
    return [100.0] * n


def chg(closes, win):
    """近 win 个交易日涨幅(%)。closes 升序，最后一根为最新。"""
    if len(closes) < win + 1:
        return None
    base = closes[-(win + 1)]
    if not base:
        return None
    return (closes[-1] / base - 1.0) * 100.0


def build(raw, top_n=5):
    sw1 = raw.get("sw1") or []
    rows = raw.get("ranking_rows") or []
    klines = raw.get("klines") or {}

    # 1) 按前缀聚合资金流：一级 -> 5日/20日 主力净流入（万元）
    flow5, flow20 = {}, {}
    for r in rows:
        code = str(r.get("code", ""))
        for sw in sw1:
            s = str(sw.get("code", ""))
            if len(s) < 2 or len(code) < 2:
                continue
            prefix = s[:-1]
            if code.startswith(prefix) and code != s:
                f5 = r.get("mainNetInflow5d")
                f20 = r.get("mainNetInflow20d")
                if f5 is not None:
                    flow5[s] = flow5.get(s, 0.0) + float(f5)
                if f20 is not None:
                    flow20[s] = flow20.get(s, 0.0) + float(f20)
                break

    # 2) 逐板块算涨幅
    recs = []
    for sw in sw1:
        s, name = str(sw.get("code", "")), sw.get("name", "")
        nodes = klines.get(s) or []
        nodes = sorted(nodes, key=lambda x: str(x.get("date", "")))
        closes = [float(n.get("last")) for n in nodes if n.get("last") is not None]
        if len(closes) < 6:
            continue                      # K 线不足，跳过（5 日窗口都算不了）
        c5 = chg(closes, 5)
        c10 = chg(closes, 10)
        recs.append({
            "code": s, "name": name,
            "chg5": c5, "chg10": c10,
            "flow5": yi(flow5.get(s, 0.0)),
            "flow20": yi(flow20.get(s, 0.0)),
            "bars": len(closes),
        })

    out = {"asof": raw.get("asof", ""), "windows": {}, "n_sectors": len(recs)}

    # 3) 两个窗口分别排名
    #    10 日窗口的资金流：接口无 10 日口径，用 20 日近似（已在 note 标注）
    for win, ckey, fkey in ((5, "chg5", "flow5"), (10, "chg10", "flow20")):
        sub = [r for r in recs if r.get(ckey) is not None]
        if not sub:
            out["windows"][str(win)] = {"top": [], "bottom": [], "note": "K 线不足，无法计算"}
            continue
        rc = pct_rank([r[ckey] for r in sub])
        rf = pct_rank([r[fkey] for r in sub])
        for i, r in enumerate(sub):
            r["rank_chg"] = rc[i]
            r["rank_flow"] = rf[i]
            r["strength"] = (rc[i] + rf[i]) / 2.0
        sub.sort(key=lambda r: -r["strength"])
        fmt = lambda r: {
            "name": r["name"], "code": r["code"],
            "chg": round(r[ckey], 2), "flow": round(r[fkey], 2),
            "strength": round(r["strength"], 1),
            "rank_chg": round(r["rank_chg"], 1), "rank_flow": round(r["rank_flow"], 1),
        }
        out["windows"][str(win)] = {
            "top": [fmt(r) for r in sub[:top_n]],
            "bottom": [fmt(r) for r in reversed(sub[-top_n:])],
            "flow_field": fkey,
        }

    note = (
        "强度 = 涨幅排名分位与资金流排名分位的平均（各占 50%），分位并列取平均名次；"
        "资金单位为亿元（接口原始单位为万元）。"
        "10 日窗口的资金流因接口未提供 10 日口径，采用 20 日主力净流入近似，解读时请注意窗口不完全一致。"
    )
    if len(recs) < top_n * 2:
        note += ("　⚠ 有效板块数仅 %d 个（少于 TOP%d 的两倍），最强与最弱名单会出现重叠，"
                 "建议纳入完整的 31 个申万一级板块。" % (len(recs), top_n))
    out["note"] = note
    out["flow_unit"] = "亿元"
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="板块数据包 JSON")
    ap.add_argument("--out", help="输出 JSON（可选，默认打印）")
    ap.add_argument("--top", type=int, default=5, help="前 N 名，默认 5")
    a = ap.parse_args()

    raw = json.load(io.open(a.input, encoding="utf-8"))
    res = build(raw, a.top)

    # 人类可读输出
    print("板块强度排名（申万一级，共 %d 个有效板块）　数据截至 %s" % (res["n_sectors"], res["asof"]))
    for win in ("5", "10"):
        w = res["windows"].get(win) or {}
        if not w.get("top"):
            continue
        ff = w.get("flow_field", "")
        label = "5 日主力净流入" if ff == "flow5" else "20 日主力净流入(近似10日)"
        print("\n===== 近 %s 个交易日 =====" % win)
        print("  【最强 TOP%d】" % len(w["top"]))
        print("    %-12s %10s %16s %8s" % ("板块", "%s日涨幅" % win, label, "强度"))
        for r in w["top"]:
            print("    %-12s %+9.2f%% %15.2f亿 %7.1f" % (r["name"], r["chg"], r["flow"], r["strength"]))
        print("  【最弱 TOP%d】" % len(w["bottom"]))
        print("    %-12s %10s %16s %8s" % ("板块", "%s日涨幅" % win, label, "强度"))
        for r in w["bottom"]:
            print("    %-12s %+9.2f%% %15.2f亿 %7.1f" % (r["name"], r["chg"], r["flow"], r["strength"]))
    print("\n注：%s" % res["note"])

    if a.out:
        json.dump(res, io.open(a.out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print("\n[已写入] %s" % a.out)


if __name__ == "__main__":
    main()
