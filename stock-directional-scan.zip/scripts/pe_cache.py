#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
行业 PE 缓存接口。

设计目的：原流程每只标的都要 WebSearch 抓"行业PE基准"，20 只 × 搜索很慢。
本模块把"行业→PE基准"落进 SQLite，扫描时先查表；只有表里没有的行业才去
WebSearch，抓到后 set_pe 回写，下次直接命中。

表(默认 D:/News/scan.db，与 score_six/backtest 共用)：
  industry_pe(行业 PK, pe, source, updated_at, is_estimate)
  stock_industry(code PK, industry)
"""
import os
import sqlite3
import datetime

# 库路径解析：自动化统一库固定在 D:/News/scan.db（所有脚本共享）。
# 若脚本被安装在无 D:/News 的别处，则落到脚本同目录，保证可移植。
def _db_path():
    news = "D:/News"
    if os.path.isdir(news):
        return os.path.join(news, "scan.db")
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "scan.db")


def _conn():
    return sqlite3.connect(_db_path())


def get_pe(industry):
    """查行业 PE。命中返回 dict, 否则 None。"""
    conn = _conn(); cur = conn.cursor()
    cur.execute("SELECT pe, source, updated_at, is_estimate FROM industry_pe WHERE industry=?",
                (industry,))
    r = cur.fetchone(); conn.close()
    if not r:
        return None
    return {"pe": r[0], "source": r[1], "updated_at": r[2], "is_estimate": bool(r[3])}


def set_pe(industry, pe, source="", is_estimate=False):
    """回写/更新行业 PE。WebSearch 抓到后调用。"""
    now = datetime.datetime.now().strftime("%Y-%m-%d")
    conn = _conn(); cur = conn.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS industry_pe(
        industry TEXT PRIMARY KEY, pe REAL, source TEXT,
        updated_at TEXT, is_estimate INTEGER)""")
    cur.execute("INSERT OR REPLACE INTO industry_pe(industry, pe, source, updated_at, is_estimate)"
                " VALUES(?,?,?,?,?)", (industry, pe, source, now, 1 if is_estimate else 0))
    conn.commit(); conn.close()


def get_industry(code):
    conn = _conn(); cur = conn.cursor()
    cur.execute("SELECT industry FROM stock_industry WHERE code=?", (code,))
    r = cur.fetchone(); conn.close()
    return r[0] if r else None


def set_industry(code, industry):
    conn = _conn(); cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS stock_industry(code TEXT PRIMARY KEY, industry TEXT)")
    cur.execute("INSERT OR REPLACE INTO stock_industry(code, industry) VALUES(?,?)", (code, industry))
    conn.commit(); conn.close()


def all_industries():
    conn = _conn(); cur = conn.cursor()
    cur.execute("SELECT industry, pe, source, updated_at, is_estimate FROM industry_pe ORDER BY industry")
    rows = cur.fetchall(); conn.close()
    return rows


if __name__ == "__main__":
    for ind, pe, src, upd, est in all_industries():
        print(f"{ind:<10} pe={pe:<5} {'估算' if est else '实查'}  {upd}  {src}")
