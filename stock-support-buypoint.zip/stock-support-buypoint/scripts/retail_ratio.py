#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
retail_ratio.py — 股票散户比例/筹码结构三层口径查询工具 v1.0 (2026-08-28)

用法:
    python retail_ratio.py 000636            # 深市
    python retail_ratio.py 600519            # 沪市
    python retail_ratio.py sz000636          # 带前缀也可
    python retail_ratio.py 000636 --json     # JSON 输出(供管线集成)

三层口径(均实测可用):
  L1 持股口径(季频锚点): 散户比例 ≈ 100% - 机构合计
      = 100% - (十大流通股东机构占比 + 十大外机构持仓明细聚合 - 重复)
      + 北向(季度, westock 已验证)单列
  L2 户数趋势(月/季频): 股东户数/户均持股/户均市值 + 环比 → 散户化预警
  L3 行为口径(日频): 小单净流入占比(20日) + 融资余额占流通市值比 + 两融净买入趋势

数据源(全部实测 2026-08-28):
  东财 datacenter-web RPT_HOLDERNUM_DET / RPT_F10_EH_FREEHOLDERS /
       RPT_MAIN_ORGHOLDDETAIL / RPTA_WEB_RZRQ_GGMX
  东财 push2his 资金流日K(需 Referer+重试)
  北向: 2024-08 后无个股日度明细, 季度持仓用 westock data_north_holding(或手动注明)

注意: 散户比例为估算口径(机构合计反推), 非官方披露;
      机构持仓明细为季报快照, 快照间变动无法捕捉(漏斗误差)。
"""
import argparse
import json
import sys
import time
import urllib.parse
import urllib.request

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
      "Referer": "https://data.eastmoney.com/"}
DC = "https://datacenter-web.eastmoney.com/api/data/v1/get"


def _get(url, retries=5, timeout=25):
    last = None
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers=UA)
            return json.loads(urllib.request.urlopen(req, timeout=timeout).read().decode())
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(2)
    raise RuntimeError(f"请求失败(重试{retries}次): {last}")


def _dc(report, flt, cols="ALL", size=100, page=1, sort_cols=""):
    sc = f"&sortColumns={sort_cols}&sortTypes=-1" if sort_cols else ""
    url = (f"{DC}?reportName={report}&columns={urllib.parse.quote(cols)}"
           f"&filter={urllib.parse.quote(flt)}&pageSize={size}&pageNumber={page}"
           f"{sc}&source=WEB&client=WEB")
    d = _get(url)
    return (d.get("result") or {}).get("data") or []


def norm_code(raw):
    """归一化到 (纯6位代码, 带前缀代码, 东财secid市场号 0=深 1=沪)"""
    s = raw.strip().lower()
    for p in ("sh", "sz", "bj"):
        if s.startswith(p):
            num = s[2:]
            mkt = 1 if p == "sh" else (0 if p == "sz" else 0)
            return num, ("sh" if p == "sh" else "sz") + num, mkt
    if len(s) == 6 and s.isdigit():
        mkt = 1 if s.startswith(("6", "9", "5")) else 0
        pre = "sh" if mkt == 1 else "sz"
        return s, pre + s, mkt
    raise ValueError(f"无法识别代码: {raw}")


# ---------------- L1: 持股口径 ----------------

def top10_freeholders(num, mkt):
    rows = _dc("RPT_F10_EH_FREEHOLDERS", f'(SECUCODE="{num}.{"SZ" if mkt==0 else "SH"}")',
               cols="ALL", size=500)
    if not rows:  # 北交所/异常时兜底
        return []
    latest = max(r["END_DATE"] for r in rows)[:10]
    out = []
    for r in rows:
        if r["END_DATE"][:10] != latest:
            continue
        out.append({
            "name": r.get("HOLDER_NAME", ""),
            "pct": float(r.get("FREE_HOLDNUM_RATIO") or 0),
            "is_org": str(r.get("IS_HOLDORG") or "0") == "1",
            "type": r.get("HOLDER_TYPE") or "",
        })
    return sorted(out, key=lambda x: -x["pct"]), latest


def org_hold_detail(num, mkt, date10, ah_mode=False):
    """十大之外的机构持仓聚合(基金/社保/保险/QFII等), 按 HOLDER_CODE 去重。

    ⚠ 口径坑(2026-08-28 长飞实测): 本接口 FREESHARES_RATIO 的分母是【公司总股本】,
    而十大流通接口分母是【A股流通盘】。纯A股票两者相同; A+H 股票总股本≈2倍A股流通,
    明细占比被放大约2倍(华信 44.26% vs 十大流通口径 21.72%)。
    → ah_mode=True 时只聚合 F9_ORGTYPE_NAME=基金 的记录(基金披露按A股流通口径,
      且战配/一般法人在A+H下口径失真最严重), 并按名称与十大内去重。
    """
    rows = _dc("RPT_MAIN_ORGHOLDDETAIL", f'(SECUCODE="{num}.{"SZ" if mkt==0 else "SH"}")',
               cols="ALL", size=500)
    by_date = {}
    for r in rows:
        d = (r.get("REPORT_DATE") or "")[:10]
        if not d:
            continue
        by_date.setdefault(d, []).append(r)
    if not by_date:
        return None, None
    latest = max(by_date)
    holders = {}
    for r in by_date[latest]:
        org_type = r.get("F9_ORGTYPE_NAME") or ""
        if ah_mode and org_type != "基金":
            continue  # A+H: 只信基金口径, 一般法人/QFII等总股本占比失真
        name = r.get("HOLDER_NAME") or ""
        code = r.get("HOLDER_CODE") or r.get("FUND_CODE") or name
        pct = float(r.get("FREESHARES_RATIO") or 0)
        if code and pct > 0:
            holders[code] = max(holders.get(code, 0), pct)  # 同主体取最大, 防重复行
    return sum(holders.values()), latest


HK_PROXY_MARK = "香港中央结算(代理人)"  # H股整体托管口径, 非A股机构持股


def l1_holding(num, mkt):
    t10 = top10_freeholders(num, mkt)
    if isinstance(t10, tuple):
        holders, t10_date = t10
    else:
        holders, t10_date = t10, None
    # A+H 识别: 十大中出现"香港中央结算(代理人)"即 H 股托管, 需剔除出机构口径
    hk_proxy_pct = sum(h["pct"] for h in holders if HK_PROXY_MARK in h["name"])
    is_ah = hk_proxy_pct > 0
    # 有效股东 = 剔除 H 股托管后的 A 股口径(个人/机构判定不变)
    eff_holders = [h for h in holders if HK_PROXY_MARK not in h["name"]]
    t10_org = sum(h["pct"] for h in eff_holders if h["is_org"])
    t10_all = sum(h["pct"] for h in eff_holders)
    org_extra = None
    oe_date = None
    try:
        org_extra, oe_date = org_hold_detail(num, mkt, t10_date or "", ah_mode=is_ah)
    except Exception as e:  # noqa: BLE001
        print(f"[warn] 机构持仓明细失败: {e}", file=sys.stderr)
    # 十大外机构 = 明细聚合 - 十大内机构(可能低估: 明细未覆盖的股东类型)
    # A+H 时明细聚合仅含基金(A股流通口径), 与剔除H股托管后的十大同基
    extra = (org_extra - t10_org) if (org_extra is not None and org_extra > t10_org) else 0.0
    inst_total = t10_org + extra
    retail = 100.0 - inst_total
    note = f"估算=100%-机构合计; 明细聚合日 {oe_date}; 十大流通口径 {t10_date}"
    if is_ah:
        note = (f"A+H结构: 已剔除香港中央结算(代理人){hk_proxy_pct:.2f}%(H股整体托管, "
                f"非A股机构); 以下为A股流通盘口径。{note}")
    return {
        "date": t10_date,
        "is_ah": is_ah,
        "hk_proxy_pct": round(hk_proxy_pct, 2),
        "top10_all": round(t10_all, 2),
        "top10_org": round(t10_org, 2),
        "top10_retail_list": round(t10_all - t10_org, 2),
        "org_extra_beyond_top10": round(extra, 2),
        "org_total_est": round(inst_total, 2),
        "retail_ratio_est": round(retail, 2),
        "note": note,
        "top10": holders,
    }


# ---------------- L2: 户数趋势 ----------------

def holder_num_history(num, size=8):
    rows = _dc("RPT_HOLDERNUM_DET", f'(SECURITY_CODE="{num}")',
               cols="ALL", size=size)
    rows = sorted(rows, key=lambda r: r["END_DATE"], reverse=True)
    hist = []
    for r in rows:
        hist.append({
            "end_date": r["END_DATE"][:10],
            "notice_date": (r.get("HOLD_NOTICE_DATE") or "")[:10],
            "holders": r.get("HOLDER_NUM"),
            "chg_pct": round(float(r.get("HOLDER_NUM_RATIO") or 0), 2),
            "avg_shares": r.get("AVG_HOLD_NUM"),
            "avg_mcap_wan": round(float(r.get("AVG_MARKET_CAP") or 0) / 1e4, 1) if r.get("AVG_MARKET_CAP") else None,
            "interval_chg_pct": round(float(r.get("INTERVAL_CHRATE") or 0), 2) if r.get("INTERVAL_CHRATE") is not None else None,
        })
    return hist


def retail_alert(hist):
    """散户化/集中度预警规则"""
    if len(hist) < 2:
        return {"level": "数据不足", "detail": "户数历史不足2期"}
    cur = hist[0]
    alerts = []
    if cur["chg_pct"] is not None and cur["chg_pct"] >= 30:
        alerts.append(f"最新期户数环比+{cur['chg_pct']:.0f}%(≥+30%阈值)")
    if len(hist) >= 2 and hist[0]["avg_shares"] and hist[1]["avg_shares"]:
        drop = (hist[0]["avg_shares"] - hist[1]["avg_shares"]) / hist[1]["avg_shares"] * 100
        if drop <= -20:
            alerts.append(f"户均持股环比{drop:.0f}%(≤-20%阈值)")
    if (len(hist) >= 3 and hist[0]["chg_pct"] is not None and hist[1]["chg_pct"] is not None
            and hist[0]["chg_pct"] > 0 and hist[1]["chg_pct"] > 0):
        alerts.append("户数连续两期上升")
    if alerts:
        return {"level": "散户化预警", "detail": "; ".join(alerts)}
    down2 = (len(hist) >= 3 and (hist[0]["chg_pct"] or 0) < 0 and (hist[1]["chg_pct"] or 0) < 0)
    if down2:
        return {"level": "集中度改善", "detail": "户数连续两期下降, 筹码趋于集中"}
    return {"level": "中性", "detail": "未触发预警规则"}


# ---------------- L3: 行为口径 ----------------

def fund_flow_20d(num, mkt, days=20, flow_file=None):
    """优先东财日度资金流; 失败时降级读 westock data_fund_flow 落盘 JSON(--flow-file)。"""
    secid = f"{mkt}.{num}"
    url = (f"https://push2his.eastmoney.com/api/qt/stock/fflow/daykline/get?lmt={days}"
           f"&klt=101&secid={secid}&fields1=f1,f2,f3,f7"
           f"&fields2=f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61,f62,f63,f64,f65")
    try:
        d = _get(url, retries=3)
        kl = (d.get("data") or {}).get("klines") or []
        rows = []
        for r in kl:
            f = r.split(",")
            if len(f) < 12:
                continue
            # f0=日期 f1=主力净额 f2=小单净额 f3=中单 f4=大单 f5=超大单
            # f6=主力净占比 f7=小单净占比 ... f11=收盘价 (实测2026-08-28)
            rows.append({
                "date": f[0], "main_net": float(f[1]), "small_net": float(f[2]),
                "main_pct": float(f[6]), "small_pct": float(f[7]), "close": float(f[11]),
            })
        if rows:
            return rows, "东方财富push2his"
    except Exception:  # noqa: BLE001
        pass
    # 降级: westock data_fund_flow 落盘 JSON(结构 {data:{data:[...]}} 或 {data:[...]})
    if flow_file:
        d = json.load(open(flow_file, encoding="utf-8"))
        items = d.get("data") or []
        if isinstance(items, dict):
            items = items.get("data") or []
        rows = []
        for r in items:
            sn = None
            try:  # SmallNetFlow 优先; 无则用 散户卖出-买入 近似
                if r.get("SmallNetFlow") is not None:
                    sn = float(r["SmallNetFlow"])
                elif r.get("RetailInFlow") is not None and r.get("RetailOutFlow") is not None:
                    sn = float(r["RetailInFlow"]) - float(r["RetailOutFlow"])
            except Exception:  # noqa: BLE001
                sn = None
            rows.append({
                "date": (r.get("EndDate") or r.get("date") or "")[:10],
                "main_net": float(r.get("MainNetFlow") or 0),
                "small_net": sn or 0,
                "main_pct": None, "small_pct": None,
                "close": float(r.get("ClosePrice") or 0),
            })
        rows = [r for r in rows if r["date"]]
        rows.sort(key=lambda r: r["date"])
        if rows:
            return rows[-days:], "westock data_fund_flow(降级)"
    return [], "无"


def margin(num, size=5, margin_file=None, prefixed=""):
    """两融明细: 优先 westock data_fund_margin 落盘JSON(--margin-file), 失败降级东财。

    westock 字段: FinanceValue=融资余额 FinanceBuyValue=融资买入 FinanceRefundValue=融资偿还
                 净买入 = FinanceBuyValue - FinanceRefundValue (与东财RZJME口径一致, 2026-08-28实测分毫不差)
    东财字段:    RZYE=融资余额 RZYEZB=融资余额/流通市值% RZJME=融资净买入
    注意: westock 无"占流通市值%"字段, 需结合流通市值计算或省略该列。
    """
    if margin_file:
        try:
            d = json.load(open(margin_file, encoding="utf-8"))
            items = d.get("data") or {}
            if isinstance(items, dict):
                items = (items.get(num) or items.get(prefixed)
                         or items.get("data") or [])
            rows = []
            for r in items:
                fb = float(r.get("FinanceBuyValue") or 0)
                fr = float(r.get("FinanceRefundValue") or 0)
                rows.append({
                    "date": (r.get("date") or "")[:10],
                    "rz_ye_yi": round(float(r.get("FinanceValue") or 0) / 1e8, 2),
                    "rz占比%": None,  # westock 无此字段
                    "rz_jme_yi": round((fb - fr) / 1e8, 2),
                })
            rows = [r for r in rows if r["date"]]
            rows.sort(key=lambda r: r["date"], reverse=True)
            if rows:
                return rows[:size], "westock data_fund_margin"
        except Exception:  # noqa: BLE001
            pass
    # 东财兜底
    rows = _dc("RPTA_WEB_RZRQ_GGMX", f'(scode="{num}")', cols="ALL", size=size,
               sort_cols="DATE")
    rows = sorted(rows, key=lambda r: r["DATE"], reverse=True)
    out = []
    for r in rows:
        out.append({
            "date": r["DATE"][:10],
            "rz_ye_yi": round(float(r["RZYE"] or 0) / 1e8, 2),          # 融资余额(亿)
            "rz占比%": round(float(r["RZYEZB"] or 0), 2),                  # 融资余额/流通市值
            "rz_jme_yi": round(float(r["RZJME"] or 0) / 1e8, 2),          # 融资净买入(亿)
        })
    return out, "东方财富RPTA_WEB_RZRQ_GGMX(兜底)"


# ---------------- main ----------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("code")
    ap.add_argument("--json", action="store_true", help="JSON 输出")
    ap.add_argument("--days", type=int, default=20)
    ap.add_argument("--flow-file", default=None,
                    help="资金流降级/优先源: westock data_fund_flow 落盘JSON路径")
    ap.add_argument("--margin-file", default=None,
                    help="两融优先源: westock data_fund_margin 落盘JSON路径(失败降级东财)")
    a = ap.parse_args()
    num, prefixed, mkt = norm_code(a.code)
    days = a.days

    if a.json:
        flows, flow_src = fund_flow_20d(num, mkt, days, a.flow_file)
        mg, mg_src = margin(num, margin_file=a.margin_file, prefixed=prefixed)
        data = {
            "code": prefixed, "query_time": time.strftime("%Y-%m-%d %H:%M:%S"),
            "L1_holding": l1_holding(num, mkt),
            "L2_holder_num": holder_num_history(num),
            "L2_alert": None,
            "L3_flow_20d": flows, "L3_flow_source": flow_src,
            "L3_margin": mg, "L3_margin_source": mg_src,
            "sources": "东方财富数据中心(实测2026-08-28); 北向季度见 westock data_north_holding",
        }
        hist = data["L2_holder_num"]
        data["L2_alert"] = retail_alert(hist)
        # 20日小单/主力累计
        if data["L3_flow_20d"]:
            small = sum(r["small_net"] for r in data["L3_flow_20d"]) / 1e8
            mainn = sum(r["main_net"] for r in data["L3_flow_20d"]) / 1e8
            data["L3_summary"] = {"small_net_20d_yi": round(small, 2), "main_net_20d_yi": round(mainn, 2)}
        print(json.dumps(data, ensure_ascii=False, indent=1))
        return

    # ---- 人类可读输出 ----
    print(f"=== {prefixed} 散户比例/筹码结构三层口径 ===")
    print(f"查询时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")

    # L1
    try:
        l1 = l1_holding(num, mkt)
        print("[L1 持股口径·季频] 十大流通股东截止", l1["date"])
        if l1.get("is_ah"):
            print(f"  ⚠ A+H结构: 已剔除香港中央结算(代理人) {l1['hk_proxy_pct']}%(H股整体托管), 以下为A股流通盘口径")
        print(f"  前十大合计 {l1['top10_all']}% | 其中机构 {l1['top10_org']}% | 十大内个人 {l1['top10_retail_list']}%")
        print(f"  十大外机构(持仓明细聚合-重叠) ≈ +{l1['org_extra_beyond_top10']}%")
        print(f"  → 机构合计 ≈ {l1['org_total_est']}% , 散户比例估算 ≈ {l1['retail_ratio_est']}%")
        print(f"  ({l1['note']})")
        if l1["top10"]:
            print("  前五大流通股东:")
            for h in l1["top10"][:5]:
                print(f"    {h['name'][:28]:<30} {h['pct']:>6.2f}%  {'机构' if h['is_org'] else '个人'} {h['type']}")
    except Exception as e:  # noqa: BLE001
        print(f"[L1 失败] {e}")

    # L2
    print()
    try:
        hist = holder_num_history(num)
        print(f"[L2 户数趋势] 共{len(hist)}期(含月度披露期)")
        print(f"  {'截止日':<12}{'户数':>10}{'环比%':>8}{'户均股':>10}{'户均市值(万)':>12}{'披露日':>12}")
        for h in hist[:8]:
            print(f"  {h['end_date']:<12}{h['holders']:>10,}{h['chg_pct']:>8.1f}"
                  f"{(h['avg_shares'] or 0):>10,.0f}{(h['avg_mcap_wan'] or 0):>12.1f}{h['notice_date']:>12}")
        al = retail_alert(hist)
        print(f"  ⚠ 预警: {al['level']} — {al['detail']}")
    except Exception as e:  # noqa: BLE001
        print(f"[L2 失败] {e}")

    # L3
    print()
    try:
        flows, flow_src = fund_flow_20d(num, mkt, days, a.flow_file)
        if flows:
            small = sum(r["small_net"] for r in flows) / 1e8
            mainn = sum(r["main_net"] for r in flows) / 1e8
            last = flows[-1]
            print(f"[L3 行为口径·日频] 近{len(flows)}日 (来源: {flow_src})")
            print(f"  小单(散户)累计净流入 {small:+.2f} 亿 | 主力累计净流入 {mainn:+.2f} 亿")
            print(f"  最新({last['date']}): 小单 {last['small_net']/1e8:+.2f} 亿, 主力 {last['main_net']/1e8:+.2f} 亿, 收盘 {last['close']}")
        else:
            print(f"[L3 行为口径·日频] 无数据 (来源: {flow_src})")
    except Exception as e:  # noqa: BLE001
        print(f"[L3 失败] {e}")
    try:
        mg, mg_src = margin(num, margin_file=a.margin_file, prefixed=prefixed)
        if mg:
            pct_str = f" (占流通市值 {mg[0]['rz占比%']}%)" if mg[0]["rz占比%"] is not None else ""
            print(f"[L3 两融·日频] 最新{mg[0]['date']} (来源: {mg_src}): 融资余额 {mg[0]['rz_ye_yi']:.1f} 亿{pct_str}, 当日融资净买入 {mg[0]['rz_jme_yi']:+.2f} 亿")
            if len(mg) >= 5:
                seq = [m["rz_jme_yi"] for m in mg[:5]][::-1]
                print(f"          近5日融资净买入序列(旧→新): {['%+.2f' % x for x in seq]}")
    except Exception as e:  # noqa: BLE001
        print(f"[L3 两融失败] {e}")
    print("\n[北向·季频] 个股日度明细 2024-08 起停发; 季度持仓用 westock data_north_holding(风华 2026Q2=3.07%)")
    print("口径说明: 散户比例=100%-机构合计(估算); 户数/户均为披露口径; 行为口径为成交推断。非官方披露。")


if __name__ == "__main__":
    main()
