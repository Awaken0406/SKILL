#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
支撑位 / 阻力位 / 止损 / 分仓 计算引擎（2026-08-29 新增）。

背景：此前报告的"四层支撑位"除均线外（如密集成交区）全靠 LLM 依据散文方法论手工推断，
同一只票两次运行可能给出不同结果。本脚本把支撑/阻力位彻底计算化，做到可复现。

用法:
    python levels.py --input score_input.json                 # 打印全部标的
    python levels.py --input score_input.json --code sh600183 # 只看一只
    python levels.py --input score_input.json --json          # 输出 JSON(供报告生成器消费)

输入 JSON 与 score_six.py 完全同构（可共用同一个 score_input.json）:
{
  "stocks": [
    {
      "code": "sh600183", "name": "生益科技",
      "quote": { ...data_quote 原对象... },
      "tech":  { ...data_technical 原对象(ma/boll)... },
      "kline": [ ...data_kline 的 nodes 数组(建议>=120根)... ]
    }
  ],
  "risk_budget": 0.03     // 可选, 单笔最大亏损占总资金比例, 默认 3%
}

计算方法（全部可复现，无随机、无 LLM 推断）:
  1. 均线  MA5/10/20/30/60/120/250  —— 价下为支撑、价上为阻力
  2. 布林  上轨(阻) / 中轨 / 下轨(撑)
  3. 摆动高低点 fractal(L=R=SWING_LR) —— 近 SWING_LOOKBACK 根的局部极值
  4. 成交量分布 volume profile —— 近 VP_LOOKBACK 根按典型价分箱，取高量节点(HVN)
  5. 跳空缺口 gap —— 向上缺口下沿(撑) / 向下缺口上沿(阻)
  6. 整数关口 round number —— 按价格量级自适应步长
  7. 区间高低点 —— 近 RANGE_LOOKBACK 根的最高/最低
  然后把所有候选按 CLUSTER_TOL 聚类成"共振区"（依据合并、强度累加），
  取现价下方最近的 4 个作支撑、上方最近的 4 个作阻力；不足 4 个时用 ATR 外推补齐。

止损:  stop = min(核心支撑×(1-STOP_PCT_FLOOR), 核心支撑 − ATR_MULT×ATR14)
       即同时满足"支撑下方1-2%"与"≥2倍ATR"，取更宽(更低)的那个 —— 避免高波动股被日内噪声打掉。
分仓:  仓位上限 = 风险预算 ÷ 止损幅度(百分比)，再按核心底仓/加仓①/加仓②拆分。
       这是风险预算反推，不是固定 30/20/20 模板。
"""
import argparse
import json
import sys

# ============================================================
# CONFIG —— 全部可调，改动前先读注释
# ============================================================
# 【2026-08-29】ATR / 摆动点 / 支撑阻力 / 止损 / R:R 档位一律从 ta_core 取，
#   与 score_six.py 共用同一实现（单一真值源）。此前两边各写一套，实测思源电气出现
#   "评分用支撑 138.10→止损 128.67" 而 "报告展示支撑 143.16→止损 133.73" 的自相矛盾。
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ta_core as TA

ATR_WINDOW = TA.ATR_WINDOW
STOP_PCT_FLOOR = TA.STOP_PCT_FLOOR
ATR_MULT = TA.ATR_MULT
STOP_MAX_ATR_FROM_PX = TA.STOP_MAX_ATR_FROM_PX
RESIST_MIN_ATR = TA.RESIST_MIN_ATR
NO_RESIST_ATR_MULT = TA.NO_RESIST_ATR_MULT
TARGET_ATR_MULT = TA.NO_RESIST_ATR_MULT
SWING_LR = TA.SWING_LR
SWING_LOOKBACK = TA.SWING_LOOKBACK
VP_LOOKBACK = TA.VP_LOOKBACK
VP_BINS = TA.VP_BINS
VP_HVN_FACTOR = TA.VP_HVN_FACTOR
GAP_LOOKBACK = TA.GAP_LOOKBACK
RANGE_LOOKBACK = TA.RANGE_LOOKBACK
CLUSTER_TOL = TA.CLUSTER_TOL
RR_BANDS = TA.RR_BANDS
RISK_BUDGET = 0.03         # 单笔最大亏损占总资金比例
MAX_TOTAL_POS = 1.00       # 单票总仓位上限（1.0=满仓，保守者可改 0.6）
TRANCHES = (0.40, 0.30, 0.30)   # 核心底仓 / 加仓① / 加仓② 占计划仓位比例

# 各依据的强度权重（聚类时累加；越大表示越可能形成实质支撑/阻力）
W_MA = {"MA_250": 5.0, "MA_120": 4.5, "MA_60": 4.0, "MA_30": 3.0,
        "MA_20": 3.5, "MA_10": 2.0, "MA_5": 1.5}
W_BOLL = {"BOLL_UPPER": 2.5, "BOLL_MID": 3.0, "BOLL_LOWER": 2.5}
W_SWING = 3.0              # 摆动高点/低点
W_HVN = 4.0                # 成交密集区(高量节点)
W_GAP = 3.0                # 跳空缺口沿
W_ROUND = 1.5              # 整数关口
W_RANGE = 3.5              # 区间高点/低点

# A 股涨跌停幅度（按板块）
LIMIT_PCT_DEFAULT = 0.10   # 主板
LIMIT_PCT_GROWTH = 0.20    # 创业板(300/301) / 科创板(688)
LIMIT_PCT_ST = 0.05        # ST


# ============================================================
# 基础计算
# ============================================================
def _f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def true_ranges(bars):
    trs = []
    for i in range(1, len(bars)):
        h, l = bars[i]["high"], bars[i]["low"]
        pc = bars[i - 1]["last"]
        trs.append(max(h - l, abs(h - pc), abs(l - pc)))
    return trs


def atr(bars, window=ATR_WINDOW):
    """ATR = 最近 window 根真实波幅的简单均值（确定性，非 Wilder 递推）。"""
    trs = true_ranges(bars)
    if len(trs) < window:
        return (sum(trs) / len(trs)) if trs else None
    return sum(trs[-window:]) / window


def atr_wilder(bars, window=ATR_WINDOW, start=0):
    """Wilder 平滑 ATR（与主流软件一致）。start 之前的 K 线用于预热。"""
    bars = bars[:start + 1] if start else bars
    trs = true_ranges(bars)
    if len(trs) < window:
        return (sum(trs) / len(trs)) if trs else None
    a = sum(trs[:window]) / window
    for tr in trs[window:]:
        a = (a * (window - 1) + tr) / window
    return a


def swing_pivots(bars, lr=SWING_LR):
    """返回 (highs, lows)：局部最高/最低点的价格列表。

    第 i 根为摆动高点 iff high[i] 是 [i-lr, i+lr] 内最大值。"""
    highs, lows = [], []
    n = len(bars)
    for i in range(lr, n - lr):
        h = bars[i]["high"]
        l = bars[i]["low"]
        if all(h >= bars[j]["high"] for j in range(i - lr, i + lr + 1) if j != i):
            highs.append(h)
        if all(l <= bars[j]["low"] for j in range(i - lr, i + lr + 1) if j != i):
            lows.append(l)
    return highs, lows


def volume_profile_nodes(bars, nbins=VP_BINS, factor=VP_HVN_FACTOR):
    """成交量分布高量节点(HVN)。按典型价 (H+L+C)/3 分箱，取局部峰且高于均值×factor 的箱。

    返回 [(价格, 该箱成交量占总量比例), ...] 按成交量降序。"""
    if not bars:
        return []
    lo = min(b["low"] for b in bars)
    hi = max(b["high"] for b in bars)
    if hi <= lo:
        return []
    size = (hi - lo) / nbins
    bins = [0.0] * nbins
    total = 0.0
    # 成交量缺失时（如只存了换手率）用换手率作代理 —— 与成交量成正比，分布形状一致
    use_turnover = all(not float(b.get("volume") or 0) for b in bars)
    for b in bars:
        tp = (b["high"] + b["low"] + b["last"]) / 3.0
        k = int((tp - lo) / size)
        k = max(0, min(nbins - 1, k))
        v = float(b.get("exchange") or 0) if use_turnover else float(b.get("volume") or 0)
        bins[k] += v
        total += v
    if total <= 0:
        return []
    mean = total / nbins
    nodes = []
    for k in range(nbins):
        if bins[k] < mean * factor:
            continue
        left = bins[k - 1] if k > 0 else 0
        right = bins[k + 1] if k < nbins - 1 else 0
        if bins[k] < left or bins[k] < right:   # 必须是局部峰
            continue
        nodes.append((lo + (k + 0.5) * size, bins[k] / total))
    nodes.sort(key=lambda x: -x[1])
    return nodes


def gaps(bars, lookback=GAP_LOOKBACK):
    """跳空缺口。返回 [(价格, '向上缺口下沿'/'向下缺口上沿'), ...]。"""
    out = []
    seq = bars[-lookback:] if len(bars) > lookback else bars
    for i in range(1, len(seq)):
        prev_h, prev_l = seq[i - 1]["high"], seq[i - 1]["low"]
        h, l = seq[i]["high"], seq[i]["low"]
        if l > prev_h:
            out.append((prev_h, "向上跳空缺口下沿"))
        elif h < prev_l:
            out.append((prev_l, "向下跳空缺口上沿"))
    return out


def round_step(px):
    """按价格量级自适应整数关口步长。"""
    if px >= 100:
        return 10.0
    if px >= 50:
        return 5.0
    if px >= 20:
        return 2.0
    if px >= 10:
        return 1.0
    return 0.5


def round_levels(px, k=2):
    """现价上下各 k 个整数关口。"""
    step = round_step(px)
    out = []
    for i in range(1, k + 1):
        out.append((int(px / step) * step + i * step, "整数关口"))
        below = int(px / step) * step - (i - 1) * step
        if below < px:
            out.append((below, "整数关口"))
    return [(p, t) for p, t in out if p > 0]


# ============================================================
# 候选收集 + 聚类
# ============================================================
def collect_candidates(px, ma, boll, bars):
    """收集全部支撑/阻力候选，返回 [(price, weight, basis), ...]。"""
    cands = []

    def add(p, w, basis):
        if p is None:
            return
        cands.append((float(p), float(w), basis))

    # 1) 均线
    for k, w in W_MA.items():
        v = ma.get(k)
        add(v, w, k)
    # 2) 布林
    for k, w in W_BOLL.items():
        v = boll.get(k)
        add(v, w, {"BOLL_UPPER": "布林上轨", "BOLL_MID": "布林中轨",
                   "BOLL_LOWER": "布林下轨"}[k])
    if not bars:
        return cands
    # 3) 摆动高低点
    hs, ls = swing_pivots(bars[-SWING_LOOKBACK:])
    for h in set(hs):
        add(h, W_SWING, "摆动高点")
    for l in set(ls):
        add(l, W_SWING, "摆动低点")
    # 4) 成交密集区
    for p, share in volume_profile_nodes(bars[-VP_LOOKBACK:]):
        add(p, W_HVN * min(1.0, share * 20), f"成交密集区(占量{share:.1%})")
    # 5) 跳空缺口
    for p, t in gaps(bars):
        add(p, W_GAP, t)
    # 6) 整数关口
    for p, t in round_levels(px):
        add(p, W_ROUND, t)
    # 7) 区间高低点
    rng = bars[-RANGE_LOOKBACK:]
    add(max(b["high"] for b in rng), W_RANGE, f"近{RANGE_LOOKBACK}日最高")
    add(min(b["low"] for b in rng), W_RANGE, f"近{RANGE_LOOKBACK}日最低")
    return cands


def cluster(cands, px, tol=CLUSTER_TOL):
    """把容差内的候选合并为共振区。返回 [{price, weight, bases}, ...] 按价格升序。"""
    items = sorted(cands, key=lambda c: c[0])
    out = []
    for p, w, b in items:
        if out and abs(p - out[-1]["price"]) / px <= tol:
            cur = out[-1]
            # 加权平均更新中心价（权重大者主导）
            tot = cur["weight"] + w
            cur["price"] = (cur["price"] * cur["weight"] + p * w) / tot
            cur["weight"] = tot
            if b not in cur["bases"]:
                cur["bases"].append(b)
        else:
            out.append({"price": p, "weight": w, "bases": [b]})
    return out


def strength_label(w):
    if w >= 6:
        return "强", "tag-red"
    if w >= 3:
        return "中", "tag-orange"
    return "弱", "tag-blue"


def fill_with_atr(levels, px, a, need, side):
    """候选不足时用 ATR 外推补齐。side: 'support' | 'resist'。"""
    out = list(levels)
    if a is None or a <= 0:
        return out
    k = 1
    while len(out) < need:
        step = a * (1.5 * k)
        p = px - step if side == "support" else px + step
        if p <= 0:
            break
        out.append({"price": p, "weight": 1.0,
                    "bases": [f"ATR外推({k}×1.5ATR)"]})
        k += 1
    return out


# ============================================================
# 止损 / 分仓 / 执行风险
# ============================================================
def stop_of(support_px, a, px=None):
    """止损 = min(支撑×(1−1.5%), 支撑 − ATR_MULT×ATR)，取更宽(更低)者；
    再对"距现价 > STOP_MAX_ATR_FROM_PX×ATR"收紧为跟踪止损（与 score_six.stop_level 同口径）。"""
    if support_px is None:
        return None, ""
    floor = support_px * (1 - STOP_PCT_FLOOR)
    stop, why = floor, f"支撑{support_px:.2f} 下方 {STOP_PCT_FLOOR:.1%} = {floor:.2f}"
    if a:
        atr_stop = support_px - ATR_MULT * a
        if atr_stop < floor:
            stop, why = atr_stop, (f"支撑{support_px:.2f} − {ATR_MULT:g}×ATR({a:.2f}) "
                                   f"= {atr_stop:.2f}（宽于支撑下方{STOP_PCT_FLOOR:.1%}的{floor:.2f}，取宽者）")
        if px:
            cap = px - STOP_MAX_ATR_FROM_PX * a
            if stop < cap and cap < support_px:
                stop = cap
                why += (f" → 距现价>{STOP_MAX_ATR_FROM_PX:g}×ATR，"
                        f"收紧为跟踪止损 {stop:.2f}")
    return stop, why


def position_plan(entry, stop, budget=RISK_BUDGET):
    """风险预算反推仓位：总仓位上限 = 风险预算 ÷ 止损幅度。"""
    if not entry or not stop or entry <= stop:
        return None
    stop_pct = (entry - stop) / entry
    if stop_pct <= 0:
        return None
    total = min(budget / stop_pct, MAX_TOTAL_POS)
    tr = [total * t for t in TRANCHES]
    return {"entry": entry, "stop": stop, "stop_pct": stop_pct,
            "total_pos": total, "tranches": tr, "budget": budget}


def limit_pct_of(code, name=""):
    """按板块返回涨跌停幅度。"""
    c = (code or "")[2:] if (code or "").startswith(("sh", "sz", "bj")) else (code or "")
    if "ST" in (name or "").upper():
        return LIMIT_PCT_ST
    if c.startswith(("300", "301", "688", "689")):
        return LIMIT_PCT_GROWTH
    return LIMIT_PCT_DEFAULT


def execution_risk(code, name, bars, quote):
    """A 股特有执行风险：跌停 / 一字板 / 停牌 —— 止损当日可能无法成交。"""
    warns = []
    if len(bars) < 2:
        return warns
    last, prev = bars[-1], bars[-2]
    pc = _f(quote.get("prev_close")) or prev["last"]
    cl = last["last"]
    if not pc or not cl:
        return warns
    chg = (cl - pc) / pc
    lim = limit_pct_of(code, name)
    if chg <= -(lim - 0.005):
        warns.append(f"当日跌停（{chg:.2%}），**跌停封板下止损指令当日无法成交**，"
                     "只能次日处理，实际止损位可能显著劣于计划位")
    if chg >= (lim - 0.005):
        warns.append(f"当日涨停（{chg:.2%}），追高买入可能无法成交")
    if last["high"] == last["low"]:
        warns.append("当日一字板（最高=最低），全天无有效成交区间，无法按计划价位进出")
    # 停牌：最后一根K线日期与次新的间隔（粗略：K线根数不足或最后日期过早由调用方判断）
    return warns


# ============================================================
# 主流程
# ============================================================
def analyze(stock_raw, budget=RISK_BUDGET):
    q = stock_raw.get("quote", {}) or {}
    t = stock_raw.get("tech", {}) or {}
    ma = {k: _f(v) for k, v in (t.get("ma", {}) or {}).items()}
    boll_raw = t.get("boll", {}) or {}
    boll = {"BOLL_UPPER": _f(boll_raw.get("BOLL_UPPER")),
            "BOLL_MID": _f(boll_raw.get("BOLL_MID")),
            "BOLL_LOWER": _f(boll_raw.get("BOLL_LOWER"))}

    nodes = [n for n in (stock_raw.get("kline") or []) if isinstance(n, dict) and "date" in n]
    nodes.sort(key=lambda n: n["date"])
    # 【2026-08-29 容错】输入 JSON 常缺 open（行情接口未返回或组装时漏掉）。
    #   缺 open 时回退为"前一根收盘"，首根回退为自身收盘 —— 保证 ATR/摆动点/缺口
    #   不至于因为一个可选字段缺失而整体失效（此前会静默得到 bars=[] → ATR=None）。
    bars = []
    prev_close = None
    for n in nodes:
        h, l, c = _f(n.get("high")), _f(n.get("low")), _f(n.get("last"))
        if None in (h, l, c):
            continue
        o = _f(n.get("open"))
        if o is None:
            o = prev_close if prev_close is not None else c
            o_missing = True
        else:
            o_missing = False
        bars.append({"date": n["date"], "open": o, "high": h, "low": l, "last": c,
                     "volume": _f(n.get("volume")) or 0.0,
                     "exchange": _f(n.get("exchange")) or 0.0,
                     "open_imputed": o_missing})
        prev_close = c
    imputed = sum(1 for b in bars if b["open_imputed"])

    px = _f(q.get("price")) or (bars[-1]["last"] if bars else None)
    code, name = stock_raw.get("code", ""), stock_raw.get("name", "")
    if px is None:
        return {"code": code, "name": name, "error": "缺现价与K线"}

    a = atr_wilder(bars) if len(bars) >= ATR_WINDOW else atr(bars)
    atr_pct = (a / px) if (a and px) else None

    cands = collect_candidates(px, ma, boll, bars)
    zones = cluster(cands, px)

    supports = [z for z in zones if z["price"] < px]
    resists = [z for z in zones if z["price"] > px]
    supports = sorted(supports, key=lambda z: -z["price"])[:4]
    resists = sorted(resists, key=lambda z: z["price"])[:4]
    supports = fill_with_atr(supports, px, a, 4, "support")
    resists = fill_with_atr(resists, px, a, 4, "resist")

    core_sup = supports[0]["price"] if supports else None
    stop, stop_why = stop_of(core_sup, a, px)
    plan_pullback = position_plan(core_sup, stop, budget) if (core_sup and stop) else None
    plan_now = position_plan(px, stop, budget) if (px and stop and px > stop) else None

    # 最近实质阻力（供 score_six / 报告复用）
    # 【2026-08-29】与 score_six.nearest_resistance 同口径：须在现价上方 ≥RESIST_MIN_ATR×ATR，
    #   否则该阻力在 ATR 尺度上属噪声级障碍、视为可突破，改用 ATR 外推。
    thr = px + RESIST_MIN_ATR * a if a else px * 1.01
    far = [z for z in resists if z["price"] >= thr]
    if far:
        resist_now = far[0]["price"]
        resist_basis = far[0]["bases"]
    elif a:
        resist_now = px + TARGET_ATR_MULT * a
        resist_basis = [f"无≥{RESIST_MIN_ATR:g}×ATR的实质阻力（最近障碍在{RESIST_MIN_ATR:g}×ATR内，"
                        f"视为可突破），ATR外推({TARGET_ATR_MULT:g}×ATR)"]
    else:
        resist_now, resist_basis = None, ["无阻力且缺ATR"]

    return {
        "code": code, "name": name, "px": px,
        "atr": a, "atr_pct": atr_pct,
        "bars_used": len(bars),
        "open_imputed": imputed,   # 缺 open 而用前收替代的根数（>0 时缺口判定不可靠）
        "supports": [dict(z, strength=strength_label(z["weight"])[0],
                          strength_class=strength_label(z["weight"])[1]) for z in supports],
        "resistances": [dict(z, strength=strength_label(z["weight"])[0],
                             strength_class=strength_label(z["weight"])[1]) for z in resists],
        "core_support": core_sup,
        "nearest_resistance": resist_now,
        "nearest_resistance_basis": resist_basis,
        "stop": stop, "stop_why": stop_why,
        "plan_pullback": plan_pullback,
        "plan_now": plan_now,
        "exec_risk": execution_risk(code, name, bars, q),
    }


def fmt_md(r):
    L = []
    L.append(f"## {r['name']}({r['code']}) 支撑/阻力位（脚本计算）\n")
    if r.get("error"):
        return f"## {r['name']}({r['code']})：{r['error']}\n"
    L.append(f"现价 {r['px']:.2f} | ATR14={r['atr']:.2f}（{r['atr_pct']:.2%}） | "
             f"K线{r['bars_used']}根\n")
    L.append("| 层级 | 价位 | 距现价 | 依据 | 强度 |")
    L.append("|---|---|---|---|---|")
    for i, z in enumerate(r["supports"]):
        nm = ["第一支撑", "第二支撑", "第三支撑", "强支撑"][i]
        L.append(f"| {nm} | {z['price']:.2f} | {(z['price']-r['px'])/r['px']:+.1%} | "
                 f"{' + '.join(z['bases'])} | {z['strength']} |")
    L.append("")
    L.append("| 层级 | 价位 | 距现价 | 依据 | 强度 |")
    L.append("|---|---|---|---|---|")
    for i, z in enumerate(r["resistances"]):
        nm = ["即时阻力", "短线止盈", "中线止盈", "长线压力"][i]
        L.append(f"| {nm} | {z['price']:.2f} | {(z['price']-r['px'])/r['px']:+.1%} | "
                 f"{' + '.join(z['bases'])} | {z['strength']} |")
    L.append("")
    L.append(f"**止损**：{r['stop']:.2f} —— {r['stop_why']}")
    for tag, p in (("回踩买点", r["plan_pullback"]), ("现价买入", r["plan_now"])):
        if p:
            L.append(f"- {tag} 入场{p['entry']:.2f} → 止损幅度 {p['stop_pct']:.1%}，"
                     f"风险预算{p['budget']:.0%} 反推**总仓位上限 {p['total_pos']:.0%}**"
                     f"（核心底仓 {p['tranches'][0]:.0%} / 加仓① {p['tranches'][1]:.0%} / "
                     f"加仓② {p['tranches'][2]:.0%}）")
    if r["exec_risk"]:
        L.append("- ⚠️ **执行风险**：" + "；".join(r["exec_risk"]))
    return "\n".join(L) + "\n"


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="与 score_six.py 同构的输入JSON")
    ap.add_argument("--code", help="只输出指定代码")
    ap.add_argument("--json", action="store_true", help="输出JSON")
    ap.add_argument("--out", help="输出文件路径(可选)")
    ap.add_argument("--risk-budget", type=float, default=RISK_BUDGET, help="单笔风险预算(默认0.03)")
    args = ap.parse_args()

    with open(args.input, "r", encoding="utf-8-sig") as f:
        data = json.load(f)
    budget = data.get("risk_budget", args.risk_budget)
    results = [analyze(s, budget) for s in data.get("stocks", [])]
    if args.code:
        results = [r for r in results if r.get("code") == args.code]

    if args.json:
        out = json.dumps(results, ensure_ascii=False, indent=2)
    else:
        out = "\n".join(fmt_md(r) for r in results)
    print(out)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(out + "\n")
        print(f"\n[已写入] {args.out}", file=sys.stderr)


if __name__ == "__main__":
    main()
