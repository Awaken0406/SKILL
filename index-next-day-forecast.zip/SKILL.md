---
name: index-next-day-forecast
description: 大盘指数（上证/深成/创业板/沪深300/科创50等宽基）当日复盘与下一交易日走势、点位概率推演。当用户问"今天大盘怎么样""明天会怎么走""下个交易日走势""点位预测""明天支撑压力在哪""大盘复盘"时触发。用波动率+形态回测+周期效应+均线缠斗+技术位聚类五锚交叉给出区间与概率，产出 HTML 研报。
agent_created: true
---

# 大盘指数复盘与次日推演

> 本技能只做**宽基指数**的复盘与次日推演。个股支撑位/买入点请用 `stock-support-buypoint`。

## 前置（硬性）

金融场景总入口是 `wb-finance-skill`，**本技能使用前必须先加载它**，遵守其红线（禁编造数据、禁硬编码、来源可追溯、强制免责声明）。

加载后按它的要求匹配 reference：
- 本技能自带 `references/forecast-methodology.md`（**核心方法论，必读**）
- 大盘场景另需 `market-state`（市场状态与广度）
- 产出 HTML 前另需 `html-report-style.md`（输出格式）

## 工作流

### 第 1 步：确认标的与交易日
- 指数代码：上证 `sh000001`、深成 `sz399001`、创业板 `sz399006`、沪深300 `sh000300`、科创50 `sh000688`、中证500 `sh000905`
- **必须调 `data_trade_calendar` 确认下一交易日是哪天**，并看它是否月末 / 季末 / 节前

### 第 2 步：并行拉数据（P0 全部要）
| 数据 | 工具 | 参数要点 |
|---|---|---|
| 日 K 线 | `data_kline` | `period=day`、`limit≥500`（**少于 250 根回测不可靠**） |
| 技术指标 | `data_technical` | `group=ma,macd,kdj,rsi,boll` |
| 多指数快照 | `data_quote` | `codes=sh000001,sz399001,sz399006,sh000300,sh000688,sh000905` |
| 市场总览 | `data_market_overview` | `type=all`（广度/量能/两融/估值/风格轮动一次拿全） |
| 板块排行 | `data_sector` | `mode=ranking&kind=industry&limit≥30`（看高低切换） |
| 分时 | `data_minute` | `days≥2`（判断盘中轨迹：冲高回落 vs 单边上行） |

### 第 3 步：跑量化底稿
```bash
python scripts/analyze_index.py --kline kline.json --ma 60 --json stats.json
```
- `--kline` 直接吃 `data_kline` 的原始输出（也兼容纯数组）
- `--ma` 是关键均线窗口，A 股宽基默认 60
- 输出：均线体系、σ/ATR 区间、4 类形态回测、星期效应、月末效应、关键点位与密集区、量能对比、近期节奏、MA 缠斗序列

**把打印结果里的数字直接搬进第 4 步的 config，不要自己心算。**

### 第 4 步：补消息面 + 填 config
- 用 `data_calendar` + WebSearch / `agentic_search` 查**次日经济数据**（PMI 通常月末 09:30 发布、CPI 次月 9 日、议息会议）与重大事件（IPO 抽血、政策、业绩披露截止日）
- 复制 `scripts/config_example.json` 改成 `config.json`，按注释填入：结论段、KPI、指数对比、板块、广度、技术面、资金面、统计表、情景表、点位阶梯、事件、条件决策、风险、来源

**config 里的 HTML 片段字段可直接写内联标签**（`<b>`、`<span class="up">` 等）。数字列写 `+0.11%` / `-0.11%` 会自动红涨绿跌着色。

### 第 5 步：生成并校验
```bash
python scripts/gen_report.py --kline kline.json --stats stats.json --config config.json --out 报告.html
```
脚本自动做三项自检：残留占位符、div 配平、**内联 JS 的 `node --check`**。
任一不过会直接报错退出——**改到通过再交付**。

## config 字段速查

| 字段 | 类型 | 说明 |
|---|---|---|
| `ma_window` | int | K 线图上的关键均线窗口，默认 60 |
| `title` / `subtitle` | str | 标题与副标题（含数据时点、推演目标、数据源） |
| `out` | str | 输出路径（可被 `--out` 覆盖） |
| `tldr` | [html] | 结论先行段落数组 |
| `badges` | [[文本, r/y/g/b]] | 结论标签 |
| `kpi` | [{lb,vl,cls,ex}] | 4 个核心指标卡 |
| `intraday` | [html] | 盘中轨迹描述 |
| `indices` | {head, rows} | 指数对比表，第 1~5 列自动按正负着色 |
| `sectors` | {up, dn, head, rows} | `up`/`dn` 是 `[[板块名, 涨跌幅]]`，用于横向条形图 |
| `breadth` | {kpi, note} | 广度指标 + 解读 |
| `tech` | {ma:{head,rows}, ind:{head,rows}, note} | 均线表 + 指标表 |
| `capital` | {kpi, note} | 资金面 |
| `stats` | {head, rows, note} | 历史统计表（来自 analyze 输出） |
| `vol` | {rows, note} | 波动率区间表 |
| `scen` | [[名称, 收盘参考位, 概率%]] | 情景表，概率合计应为 100 |
| `scen_note` | html | 情景表下的综合判断（**必须给出核心区间**） |
| `ladder` | [[点位, 标签, r/g/n, 描述]] | 关键点位阶梯，从上到下按价位降序 |
| `events` | {head, rows, note} | 盘中变量表 |
| `decisions` | {head, rows} | 条件化决策三列表 |
| `risks` | [html] | 反向声音（**必写，至少 2~3 条**） |
| `sources` | [str] | 数据来源 + 时点（每个 pill 一条） |

## 输出硬性要求

1. **结论先行**：首屏 TL;DR 直接给判断、核心区间、分水岭、概率。
2. **必须给出"多空分水岭"这个数字**（通常是当前贴身的那条均线）。
3. **必须给出"最可能的情景"**，不能平铺 N 种让用户自选。
4. **必须写反向声音**，且要真实——主动找与自己结论相悖的证据。
5. A 股语境**红涨绿跌**，浅底深字研报风。
6. 末尾**完整附上免责声明**（wb-finance-skill 固定文案，不得改写缩减）。
7. 所有关键数字标注**来源 + 时点**；第三方预期值（如 PMI 预期）标注"需核实原文"。

## 避坑

完整清单见 `references/forecast-methodology.md` 第五节。最高频三个：
- **星期效应标签错配**：预测周一行情要统计"**周五**之后那一交易日"的收益，不是"weekday==0 之后"。脚本已规避，自己写时别踩。
- **样本量过小**：形态回测 n<10 只能说"方向性参考"，不能当胜率。
- **忘记查次日经济数据**：任何技术推演都可能被一个 PMI 推翻。

## 文件结构

```
index-next-day-forecast/
├── SKILL.md                          ← 本文件（流程与 config 速查）
├── references/
│   └── forecast-methodology.md       ← 五锚交叉法、数据清单、避坑清单（核心方法论）
├── assets/
│   └── report-template.html          ← 占位符版报告模板
└── scripts/
    ├── analyze_index.py              ← 量化底稿生成器
    ├── gen_report.py                 ← 报告渲染 + 三项自检
    └── config_example.json           ← config 模板（含本次上证实例）
```
