#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
评分体系历史回测（backtest）——验证"购买指数六维总分/评级是否有预测力"。

输入:
  1. 历史快照: --history D:/News/score_history.jsonl
     （由 score_six.py --history 落库生成, 每行一条: date/code/name/total/rating/six/...）
  2. 后续K线: --klines D:/News/backtest_klines.json
     格式 {"sh601088": [ {date, open, last, high, low}, ...(正序), ... ]}
     由调用方从 data_kline(单码, start=评分日前, end=今天) 组装；可多只。
     提供哪只就回测哪只（缺K线/未到期的自然跳过）。

输出:
  按评级分组与总分分桶的 T+5/T+10/T+20 交易日平均收益、胜率、相对同池基准的超额，
  及 total 与收益的 Spearman 秩相关(IC)。

用法:
  python backtest.py --history D:/News/score_history.jsonl --klines D:/News/backtest_klines.json
  python backtest.py --history D:/News/score_history.jsonl --klines k.json --horizons 5,10,20 --min-samples 3
"""
import argparse
import json
import sys
from collections import defaultdict
from datetime import datetime, timedelta
from statistics import mean

HORIZONS = [5, 10, 20]
MIN_SAMPLES = 3
RATING_ORDER = ["强烈建议买入", "建议买入", "轻仓试探/等回踩", "观望", "不建议买入"]


def parse_date(d):
    try:
        return datetime.strptime(d[:10], "%Y-%m-%d")
    except Exception:
        return None


def spearman_rho(xs, ys):
    """Spearman 秩相关（无第三方库, 朴素实现）。"""
    n = len(xs)
    if n < 3:
        return None
    def ranks(v):
        s = sorted(range(n), key=lambda i: v[i])
        r = [0.0] * n
        i = 0
        while i < n:
            j = i
            while j + 1 < n and v[s[j + 1]] == v[s[i]]:
                j += 1
            avg = (i + j) / 2.0 + 1
            for k in range(i, j + 1):
                r[s[k]] = avg
            i = j + 1
        return r
    rx, ry = ranks(list(xs)), ranks(list(ys))
    mx, my = sum(rx) / n, sum(ry) / n
    cov = sum((rx[i] - mx) * (ry[i] - my) for i in range(n))
    sxx = sum((x - mx) ** 2 for x in rx)
    syy = sum((y - my) ** 2 for y in ry)
    if sxx == 0 or syy == 0:
        return None
    return cov / (sxx ** 0.5 * syy ** 0.5)


def load_history(path):
    recs = []
    with open(path, "r", encoding="utf-8-sig") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except Exception:
                continue
            if isinstance(obj, list):      # 兼容整文件就是一个JSON数组的格式
                recs.extend(obj)
            elif isinstance(obj, dict):
                recs.append(obj)
    return recs


def load_klines(path):
    with open(path, "r", encoding="utf-8-sig") as f:
        raw = json.load(f)
    out = {}
    for code, nodes in raw.items():
        arr = [n for n in nodes if isinstance(n, dict) and "date" in n]
        arr.sort(key=lambda n: n["date"])
        closes = {}
        for n in arr:
            if n.get("last") is not None:
                closes[n["date"][:10]] = float(n["last"])
        out[code] = closes
    return out


def next_trading_dates(closes, ref_date, n):
    """从 ref_date 之后取 n 个交易日（按K线日期序列）。"""
    days = sorted(d for d in closes if d > ref_date)
    return days[:n]


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser()
    ap.add_argument("--history", required=True)
    ap.add_argument("--klines", required=True)
    ap.add_argument("--horizons", default="5,10,20")
    ap.add_argument("--min-samples", type=int, default=MIN_SAMPLES)
    args = ap.parse_args()
    horizons = [int(x) for x in args.horizons.split(",")]

    recs = load_history(args.history)
    closes = load_klines(args.klines)
    print(f"历史快照 {len(recs)} 条；可回测K线 {len(closes)} 只\n")

    # 每条: 计算各horizon收益率(需该只K线覆盖到 score_date+horizon 个交易日)
    rows = []  # (rec, {h: ret})
    for rec in recs:
        code, d0 = rec.get("code"), parse_date(rec.get("date", ""))
        if code not in closes or d0 is None:
            continue
        c = closes[code]
        ref = d0.strftime("%Y-%m-%d")
        if ref not in c:
            continue
        p0 = c[ref]
        rets = {}
        for h in horizons:
            fwd = next_trading_dates(c, ref, h)
            if len(fwd) < h:
                break  # 未到期, 该条当前horizon不可用(更大horizon更不可用)
            rets[h] = (c[fwd[-1]] - p0) / p0
        if rets:
            rows.append((rec, rets))

    if not rows:
        print("无可回测样本(评分日期未到T+5, 或K线未覆盖)。等样本积累后再跑。")
        return

    print(f"有可回测收益的样本: {len(rows)} 条（评分日 {min(r['date'] for r,_ in rows)} ~ {max(r['date'] for r,_ in rows)}）\n")

    # 基准 = 同池所有可回测样本在对应horizon的平均收益（相对基准）
    all_ret = {}
    for h in horizons:
        vals = [r[1].get(h) for r in rows if h in r[1]]
        if vals:
            all_ret[h] = mean(vals)

    print("### 按评级分组（平均收益 / 胜率 / 超额vs同池基准）\n")
    hdr = "| 评级 | 样本 | " + " | ".join(f"T+{h}均值|T+{h}胜率|超额" for h in horizons) + " |"
    print(hdr)
    print("|---|" + "---|" * (1 + 3 * len(horizons)))
    for rating in RATING_ORDER:
        grp = [r for r in rows if r[0].get("rating") == rating]
        if len(grp) < args.min_samples:
            continue
        cells = [str(len(grp))]
        for h in horizons:
            vals = [r[1].get(h) for r in grp if h in r[1]]
            if not vals:
                cells += ["-", "-", "-"]
                continue
            wins = sum(1 for v in vals if v > 0) / len(vals)
            excess = (mean(vals) - all_ret[h]) * 100 if h in all_ret else 0
            cells += [f"{mean(vals)*100:+.1f}%", f"{wins*100:.0f}%", f"{excess:+.1f}pp"]
        print("| " + rating + " | " + " | ".join(cells) + " |")

    print("\n### 按总分分桶\n")
    buckets = [(80, 100, "80-100"), (65, 79, "65-79"), (50, 64, "50-64"), (0, 49, "0-49")]
    hdr = "| 总分 | 样本 | " + " | ".join(f"T+{h}均值|T+{h}胜率" for h in horizons) + " |"
    print(hdr)
    print("|---|" + "---|" * (1 + 2 * len(horizons)))
    for lo, hi, name in buckets:
        grp = [r for r in rows if lo <= r[0].get("total", 0) <= hi]
        if len(grp) < args.min_samples:
            continue
        cells = [str(len(grp))]
        for h in horizons:
            vals = [r[1].get(h) for r in grp if h in r[1]]
            if not vals:
                cells += ["-", "-"]
                continue
            cells += [f"{mean(vals)*100:+.1f}%", f"{sum(1 for v in vals if v>0)/len(vals)*100:.0f}%"]
        print("| " + name + " | " + " | ".join(cells) + " |")

    print("\n### 预测力: total 与收益的 Spearman 秩相关(IC)\n")
    for h in horizons:
        pairs = [(r[0].get("total", 0), r[1][h]) for r in rows if h in r[1]]
        if len(pairs) < 5:
            print(f"T+{h}: 样本不足(需≥5), 跳过")
            continue
        rho = spearman_rho([p[0] for p in pairs], [p[1] for p in pairs])
        sig = "✓有预测力" if rho is not None and abs(rho) >= 0.03 else "弱/无"
        print(f"T+{h}: IC={rho:+.3f}（n={len(pairs)}）{sig}")

    print("\n注: 样本<30条时结论为描述性参考, 非统计显著；随 score_history.jsonl 累积逐步可信。")
    print("建议: 每月末跑一次, 观察高分档是否持续跑赢低分档与同池基准。")


if __name__ == "__main__":
    main()
