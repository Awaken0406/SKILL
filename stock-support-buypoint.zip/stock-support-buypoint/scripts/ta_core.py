# -*- coding: utf-8 -*-
"""ta_core —— 技术位计算内核（score_six.py 与 levels.py 的**唯一**真值源）。

为什么要单独抽出来（2026-08-29）：
    此前 score_six.py（评分）与 levels.py（报告展示）各自实现了一套"最近支撑/阻力"，
    候选集不同（score_six 缺成交密集区/整数关口/缺口），实测思源电气出现
        score_six  → 支撑 138.10（近120日最低）→ 止损 128.67 → 盈亏比 7 分
        levels.py  → 支撑 143.16（成交密集区）  → 止损 133.73 → 报告里写 133.73
    同一份报告自相矛盾。凡是"评分口径"与"展示口径"可能漂移的地方，都必须收敛到一处。

本模块只放**纯函数**（不依赖 Stock 类、不依赖任何脚本），可被两边安全 import，无循环依赖。

统一的算法口径：
    支撑/阻力候选 = 均线 ∪ 布林轨 ∪ 摆动高低点 ∪ 成交密集区(HVN) ∪ 跳空缺口沿
                    ∪ 区间高低点 ∪ 整数关口
    角色翻转       = 支撑型来源落在现价上方 → 标注"支撑转阻力"（反之"阻力转支撑"）
    最近支撑       = 现价下方候选中取**最大**者
    最近阻力       = 现价上方、且至少 RESIST_MIN_ATR×ATR 之外，取**最小**者；
                    不满足最小距离则视为"噪声级障碍、可突破"，改用 ATR 外推
    止损           = min(支撑×(1−1.5%), 支撑 − ATR_MULT×ATR14)，再对
                    "距现价 > STOP_MAX_ATR_FROM_PX×ATR" 收紧为跟踪止损
"""
import math

# ============================================================
# 常量（改这里 = 同时改评分与报告；勿在 score_six/levels 里重复定义）
# ============================================================
ATR_WINDOW = 14             # ATR 窗口（Wilder 平滑，与主流行情软件一致）
STOP_PCT_FLOOR = 0.015      # 止损至少在支撑下方 1.5%
# 【2026-08-29 参数扫描后回调】初版 2.0 在生益科技 66 日 walk-forward 上 65/66 得 3 分
#   （退化到另一端）。支撑本身通常已在现价下方约 1×ATR，再减 1×ATR ⇒ 止损约 2×ATR，
#   既落在"止损须在 2–3 ATR 之外"的经验区间，又与目标"至少 2×ATR"的量级匹配。
ATR_MULT = 1.0
STOP_MAX_ATR_FROM_PX = 3.0  # 止损距现价上限（强势趋势股用跟踪止损，不守远期支撑）
RESIST_LOOKBACK = 120       # 摆动点/区间高低点回溯根数
RESIST_BUFFER = 1.01        # 兜底：无 ATR 时，阻力须高于现价 1%
# 【2026-08-29 新增·本次修复的关键一项】目标须至少在现价上方 RESIST_MIN_ATR×ATR 之外。
#   贴身阻力（<2×ATR）在 ATR 尺度上属噪声级障碍，作为止盈目标会把 R:R 压到 0.4 量级
#   （实测中位 0.44，66 日里 65 个得 3 分）。加这一项后中位 R:R 回到 1.77。
RESIST_MIN_ATR = 2.0
# 【2026-08-29 5.0→3.0】外推目标须与"止损距现价上限 3×ATR"对称，否则分子分母不同尺度：
#   止损被压在 ≤3×ATR，目标却外推到 5×ATR，等于凭空造出 R:R≈1.7 的乐观下限。
#   取 3.0 后，无阻力时 R:R 天然收敛到 ≈1.0（分子 3×ATR / 分母约 2–3×ATR），
#   即"上方无阻力"不再自动等于"好买卖"，需要真实结构位才能拿高分。
NO_RESIST_ATR_MULT = 3.0    # 无合格阻力时，目标 = 现价 + 3×ATR（再对齐到整数关口）
# 【2026-08-29 反复试验后的结论：不要用固定 ATR 上限约束目标】
#   曾试过 RESIST_MAX_ATR=3.0（目标最远 3×ATR），结果 R:R 被压进 1.63~2.47，
#   且 66 个交易日里 0 个落入 3 分档 —— 该维度再也不会说"这笔赔率差"。
#   根因：固定上限把分子钉死在 3×ATR，而分母随"支撑距现价"变化，
#   R:R 于是退化成 3/(d/ATR+1)，等于把"位置"维度重算一遍（实测与支撑距离相关性虽只有
#   0.182，但那是因为支撑几乎总在 0.12~0.30 ATR 内，分母本身没变化空间）。
#   **R:R 必须分子分母同尺度（都以 ATR 计）才是波动率中性的**，固定上限会破坏这一点。
#   实测生益科技选中的 183.04 成交密集区（+25.7%）看似很远，但它是真实成交过的价位，
#   且 25.7% 仅 3.5×ATR，对该股 7.4% 的日波动属正常幅度，不是虚增赔率。
#   改用唯一一条护栏：目标不得超出近 RANGE_LOOKBACK 日最高（超出即属凭空想象）。
RESIST_MAX_BEYOND_RANGE = 0.0   # 允许超出区间最高的比例（0 = 不允许）

SWING_LR = 3                # 摆动点左右各看几根（fractal 半宽）
SWING_LOOKBACK = 120        # 摆动点回溯根数
VP_LOOKBACK = 120           # 成交量分布回溯根数
VP_BINS = 40                # 成交量分布分箱数
VP_HVN_FACTOR = 1.3         # HVN 阈值：箱内量 ≥ 均值×该系数 且为局部峰
GAP_LOOKBACK = 60           # 缺口回溯根数
RANGE_LOOKBACK = 120        # 区间高低点回溯根数
CLUSTER_TOL = 0.010         # 聚类容差（占现价比例）

# R:R → 分值。新门槛是按 ATR 挂钩的宽止损口径重新标定的（旧门槛针对 1.5% 窄止损）。
# ⚠️ 标定仅基于生益科技 1 只标的 66 个交易日，属【推断·待验证】，需多标的复检。
RR_BANDS = [(2.5, 15), (1.8, 11), (1.2, 7)]
RR_BANDS_OLD = [(3.0, 15), (2.0, 11), (1.5, 7)]   # 旧口径门槛（A/B 对照用，勿改）

# 依据的"原生角色"：neutral=中性 / support=支撑型 / resistance=阻力型
#   决定候选落到现价另一侧时是否要标注"支撑转阻力"或"阻力转支撑"。
NATIVE_ROLE = {
    "布林上轨": "resistance", "布林下轨": "support",
    "摆动高点": "resistance", "摆动低点": "support",
    "向上跳空缺口下沿": "support", "向下跳空缺口上沿": "resistance",
}

MA_KEYS = ("MA_5", "MA_10", "MA_20", "MA_30", "MA_60", "MA_120", "MA_250")


# ============================================================
# 基础工具
# ============================================================
def _f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def bars_from_kline(nodes):
    """把 score_six/输入JSON 的 kline 节点转成 bars。

    容错：输入常缺 open（行情接口未返回或组装时漏掉）→ 回退为前一根收盘，
    首根回退为自身收盘。缺一个可选字段不该让整个技术位计算静默失效。
    """
    bars, prev_close = [], None
    for n in (nodes or []):
        if not isinstance(n, dict) or "date" not in n:
            continue
        h, l, c = _f(n.get("high")), _f(n.get("low")), _f(n.get("last"))
        if None in (h, l, c):
            continue
        o = _f(n.get("open"))
        imputed = False
        if o is None:
            o = prev_close if prev_close is not None else c
            imputed = True
        bars.append({"date": n["date"], "open": o, "high": h, "low": l, "last": c,
                     "volume": _f(n.get("volume")) or 0.0,
                     "exchange": _f(n.get("exchange")) or 0.0,
                     "open_imputed": imputed})
        prev_close = c
    bars.sort(key=lambda b: b["date"])
    return bars


def true_ranges(bars):
    return [max(b["high"] - b["low"],
                abs(b["high"] - bars[i - 1]["last"]),
                abs(b["low"] - bars[i - 1]["last"]))
            for i, b in enumerate(bars) if i >= 1]


def atr_wilder(bars, window=ATR_WINDOW):
    """Wilder 平滑 ATR。K线不足 window 根时退化为全体简单均值。"""
    trs = true_ranges(bars)
    if not trs:
        return None
    if len(trs) < window:
        return sum(trs) / len(trs)
    a = sum(trs[:window]) / window
    for tr in trs[window:]:
        a = (a * (window - 1) + tr) / window
    return a


def swing_pivots(bars, lr=SWING_LR, lookback=SWING_LOOKBACK):
    """摆动高低点（fractal）。返回 (highs, lows) 价格列表。"""
    seq = bars[-lookback:] if len(bars) > lookback else bars
    highs, lows = [], []
    for i in range(lr, len(seq) - lr):
        h, l = seq[i]["high"], seq[i]["low"]
        if all(h >= seq[j]["high"] for j in range(i - lr, i + lr + 1) if j != i):
            highs.append(h)
        if all(l <= seq[j]["low"] for j in range(i - lr, i + lr + 1) if j != i):
            lows.append(l)
    return highs, lows


def volume_profile_nodes(bars, nbins=VP_BINS, factor=VP_HVN_FACTOR,
                         lookback=VP_LOOKBACK):
    """成交量分布高量节点(HVN)。按典型价 (H+L+C)/3 分箱，取局部峰且 ≥均值×factor 的箱。

    成交量全缺失时（如只存了换手率）用换手率作代理 —— 与成交量近似成正比，分布形状一致。
    返回 [(价格, 该箱成交量占比), ...] 按占比降序。"""
    seq = bars[-lookback:] if len(bars) > lookback else bars
    if len(seq) < 3:
        return []
    lo, hi = min(b["low"] for b in seq), max(b["high"] for b in seq)
    if hi <= lo:
        return []
    size = (hi - lo) / nbins
    bins = [0.0] * nbins
    total = 0.0
    use_turnover = all(not float(b.get("volume") or 0) for b in seq)
    for b in seq:
        tp = (b["high"] + b["low"] + b["last"]) / 3.0
        k = max(0, min(nbins - 1, int((tp - lo) / size)))
        v = float(b.get("exchange") or 0) if use_turnover else float(b.get("volume") or 0)
        bins[k] += v
        total += v
    if total <= 0:
        return []
    mean = total / nbins
    nodes = []
    for k in range(nbins):
        if bins[k] < mean * factor:
            continue
        left = bins[k - 1] if k > 0 else 0
        right = bins[k + 1] if k < nbins - 1 else 0
        if bins[k] < left or bins[k] < right:      # 必须是局部峰
            continue
        nodes.append((lo + (k + 0.5) * size, bins[k] / total))
    nodes.sort(key=lambda x: -x[1])
    return nodes


def gaps(bars, lookback=GAP_LOOKBACK):
    """跳空缺口沿。返回 [(价格, 依据), ...]。"""
    seq = bars[-lookback:] if len(bars) > lookback else bars
    out = []
    for i in range(1, len(seq)):
        prev_h, prev_l = seq[i - 1]["high"], seq[i - 1]["low"]
        h, l = seq[i]["high"], seq[i]["low"]
        if l > prev_h:
            out.append((prev_h, "向上跳空缺口下沿"))
        elif h < prev_l:
            out.append((prev_l, "向下跳空缺口上沿"))
    return out


def round_step(px):
    """按价格量级自适应整数关口步长。"""
    if px >= 100:
        return 10.0
    if px >= 50:
        return 5.0
    if px >= 20:
        return 2.0
    return 1.0


def round_levels(px, n=3):
    """现价上/下各 n 个整数关口。"""
    step = round_step(px)
    base = int(px / step) * step
    return [base + k * step for k in range(-n, n + 1) if base + k * step > 0]


# ============================================================
# 候选位（带角色翻转标注）
# ============================================================
def _role_label(basis, price, px):
    """候选落到现价另一侧时标注角色翻转，避免报告出现"摆动低点当阻力"这类费解表述。"""
    native = NATIVE_ROLE.get(basis)
    if native == "support" and price > px:
        return f"{basis}(支撑转阻力)"
    if native == "resistance" and price < px:
        return f"{basis}(阻力转支撑)"
    return basis


def all_candidates(px, ma, boll, bars, include_round=True):
    """全部候选位。返回 [(price, basis, native_role), ...]（未过滤方向）。

    include_round=False 时剔除整数关口 —— 用于选"止盈目标"。
    【2026-08-29】整数关口是心理位而非结构位，且是本函数唯一"凭空生成"的候选：
      实测生益科技(ATR≈7.4%)因 2×ATR 门槛=+14.7% 把所有结构阻力都筛掉，
      结果选中 170 这个第 3 档人造整数关口作目标，把 R:R 从真实的 1.85 虚增到 4.08。
      故：找目标时整数关口不参与竞争，只在"必须外推"时用作对齐参考。"""
    if px is None:
        return []
    c = []
    for k in MA_KEYS:
        v = _f((ma or {}).get(k))
        if v:
            c.append((v, k, "neutral"))
    # 【2026-08-29 修复】布林轨的 key 有两种写法：脚本内部用 upper/mid/lower，
    #   行情接口与 levels.py 用 BOLL_UPPER/BOLL_MID/BOLL_LOWER。此前只认前者，
    #   导致走 ta_core 的评分链路**完全拿不到布林轨候选**，而 levels.py 拿得到
    #   —— 又一次"同票双口径"。两种命名都认。
    for key, basis, native in (("upper", "布林上轨", "resistance"),
                               ("mid", "布林中轨", "neutral"),
                               ("lower", "布林下轨", "support")):
        v = _f((boll or {}).get(key))
        if v is None:
            v = _f((boll or {}).get("BOLL_" + key.upper()))
        if v:
            c.append((v, basis, native))
    if bars:
        highs, lows = swing_pivots(bars)
        for h in sorted(set(highs)):
            c.append((h, "摆动高点", "resistance"))
        for l in sorted(set(lows)):
            c.append((l, "摆动低点", "support"))
        for p, r in volume_profile_nodes(bars):
            c.append((p, f"成交密集区(占量{r:.1%})", "neutral"))
        for p, b in gaps(bars):
            c.append((p, b, NATIVE_ROLE.get(b, "neutral")))
        seq = bars[-RANGE_LOOKBACK:]
        c.append((max(b["high"] for b in seq), f"近{RANGE_LOOKBACK}日最高", "resistance"))
        c.append((min(b["low"] for b in seq), f"近{RANGE_LOOKBACK}日最低", "support"))
    if include_round:
        for p in round_levels(px):
            c.append((p, f"整数关口{p:g}", "neutral"))
    return c


def support_candidates(px, ma, boll, bars, include_round=True):
    """现价下方的候选支撑。返回 [(price, 标注后的依据)]，按价格降序。"""
    out = [(p, _role_label(b, p, px))
           for p, b, _ in all_candidates(px, ma, boll, bars, include_round)
           if p < px]
    return sorted(out, key=lambda x: -x[0])


def resistance_candidates(px, ma, boll, bars, include_round=True):
    """现价上方的候选阻力。返回 [(price, 标注后的依据)]，按价格升序。"""
    out = [(p, _role_label(b, p, px))
           for p, b, _ in all_candidates(px, ma, boll, bars, include_round)
           if p > px]
    return sorted(out, key=lambda x: x[0])


def nearest_support(px, ma, boll, bars):
    """现价下方最近的实质支撑 → (价格, 依据)。无候选返回 (None, 原因)。

    为什么不能再用 min(MA20, 布林中轨)：
      股价崩穿所有均线时（如思源电气 8/28 跌破 MA5/10/20/60/120/250），旧口径得到的
      支撑反在现价**上方**，据此算出的止损价高于现价，R:R 分母为负、完全失真。"""
    c = support_candidates(px, ma, boll, bars)
    if not c:
        return None, "现价已跌破全部候选支撑"
    return c[0]


def nearest_resistance(px, ma, boll, bars, atr=None):
    """现价上方最近、且至少 RESIST_MIN_ATR×ATR 之外的实质阻力 → (价格, 依据)。

    近在咫尺的阻力在 ATR 尺度上属噪声级障碍，视为可突破、不作为止盈目标；
    不满足最小距离时改用 ATR 外推（结果向下对齐到整数关口，避免出现 177.81 这类价位）。
    注：整数关口不参与竞争（见 all_candidates 注释），只在外推时作对齐参考。"""
    if px is None:
        return None, "缺现价"
    c = resistance_candidates(px, ma, boll, bars, include_round=False)
    thr = px + RESIST_MIN_ATR * atr if atr else px * RESIST_BUFFER
    far = [x for x in c if x[0] >= thr]
    if far and bars:
        # 唯一护栏：目标不得超出近 RANGE_LOOKBACK 日最高（超出即属凭空想象）
        ceiling = max(b["high"] for b in bars[-RANGE_LOOKBACK:]) * (1 + RESIST_MAX_BEYOND_RANGE)
        if far[0][0] <= ceiling:
            return far[0]
        return (ceiling,
                f"最近合格结构阻力 {far[0][0]:.2f}[{far[0][1]}] 超出近{RANGE_LOOKBACK}日最高"
                f"{ceiling:.2f}，按区间上沿取")
    if far:
        return far[0]
    if atr:
        raw = px + NO_RESIST_ATR_MULT * atr
        step = round_step(px)
        aligned = int(raw / step) * step          # 向下对齐，不夸大目标
        if aligned <= px:
            aligned = raw
        near = f"（最近结构阻力 {c[0][0]:.2f}[{c[0][1]}] < {RESIST_MIN_ATR:g}×ATR，视为可突破）" \
               if c else ""
        return (aligned,
                f"无≥{RESIST_MIN_ATR:g}×ATR的实质阻力{near}，"
                f"ATR外推({NO_RESIST_ATR_MULT:g}×ATR)={raw:.2f}→对齐{aligned:.2f}")
    return None, "无阻力且缺ATR"


def range_position(px, bars, lookback=RANGE_LOOKBACK):
    """现价在近 lookback 日区间中的分位 → (分位0~1, 说明)。

    用于"位置"维度的交叉校验：光看"距最近支撑多远"会被贴身支撑骗到高分
    （股价一路阴跌时最近支撑总在脚下），叠加区间分位才能识别真正的追高。"""
    if px is None or not bars:
        return None, "缺K线"
    seq = bars[-lookback:]
    hi = max(b["high"] for b in seq)
    lo = min(b["low"] for b in seq)
    if hi <= lo:
        return None, "区间退化"
    pos = (px - lo) / (hi - lo)
    return pos, f"近{len(seq)}日区间 {lo:.2f}~{hi:.2f} 分位 {pos:.0%}"


# ============================================================
# 止损 / 计分
# ============================================================
def stop_from_support(support_px, atr, px=None):
    """止损 = min(支撑×(1−1.5%), 支撑 − ATR_MULT×ATR)，取更低者；
    再对"距现价 > STOP_MAX_ATR_FROM_PX×ATR"收紧为跟踪止损。返回 (止损, 说明)。"""
    if support_px is None:
        return None, ""
    floor = support_px * (1 - STOP_PCT_FLOOR)
    stop = floor
    why = f"支撑{support_px:.2f} 下方 {STOP_PCT_FLOOR:.1%} = {floor:.2f}"
    if atr:
        atr_stop = support_px - ATR_MULT * atr
        if atr_stop < floor:
            stop = atr_stop
            why = (f"支撑{support_px:.2f} − {ATR_MULT:g}×ATR({atr:.2f}) = {atr_stop:.2f}"
                   f"（宽于支撑下方{STOP_PCT_FLOOR:.1%}的{floor:.2f}，取宽者）")
        if px:
            cap = px - STOP_MAX_ATR_FROM_PX * atr
            if stop < cap and cap < support_px:
                stop = cap
                why += f" → 距现价>{STOP_MAX_ATR_FROM_PX:g}×ATR，收紧为跟踪止损 {stop:.2f}"
    return stop, why


def rr_score(rr, bands=RR_BANDS):
    """R:R → 分值。bands = [(下限, 分值)] 降序，都不满足 → 3。"""
    for thr, sc in bands:
        if rr >= thr:
            return sc
    return 3


# ============================================================
# 止损（单一真值源，2026-08-29 由 levels.py 上移）
# ============================================================
def stop_of(support_px, a, px=None):
    """止损 = min(支撑×(1−1.5%), 支撑 − ATR_MULT×ATR)，取更宽(更低)者；
    再对"距现价 > STOP_MAX_ATR_FROM_PX×ATR"收紧为跟踪止损。

    上移原因：多轨买入计划的每一轨都要算自己的止损，若各写一份必然再次出现
    "同票双口径"（历史上 levels.py 与 score_six.py 就各算过一次）。"""
    if support_px is None:
        return None, ""
    floor = support_px * (1 - STOP_PCT_FLOOR)
    stop, why = floor, f"支撑{support_px:.2f} 下方 {STOP_PCT_FLOOR:.1%} = {floor:.2f}"
    if a:
        atr_stop = support_px - ATR_MULT * a
        if atr_stop < floor:
            stop, why = atr_stop, (f"支撑{support_px:.2f} − {ATR_MULT:g}×ATR({a:.2f}) "
                                   f"= {atr_stop:.2f}（宽于支撑下方{STOP_PCT_FLOOR:.1%}的{floor:.2f}，取宽者）")
        if px:
            cap = px - STOP_MAX_ATR_FROM_PX * a
            if stop < cap and cap < support_px:
                stop = cap
                why += (f" → 距现价>{STOP_MAX_ATR_FROM_PX:g}×ATR，"
                        f"收紧为跟踪止损 {stop:.2f}")
    return stop, why


# ============================================================
# 入场模式与多轨买入计划（2026-08-29 新增）
# ============================================================
# 痛点：旧版只有"挂核心支撑等回调"一条路。强势股（诺普信/生益科技/若羽臣）常年
#   贴着 MA5/MA10 走，10 日内回踩到核心支撑的概率常常只有 10~30%，挂单=废单，
#   评分再高也赚不到钱 —— 表现为"每次都错过一波波段"。
# 方案：
#   1) 用历史回测量化"每一档挂单在 N 日内能成交的概率"（尺度无关的相对位移法）；
#   2) 按概率自适应切换入场轨道：回调轨 A / 均线轨 B / 突破轨 C，三轨分摊风险预算；
#   3) 概率过低的轨道强制降权并标红，禁止把它当唯一上车方式；
#   4) 增加"强制跟随条款"作为踏空保险：窗口内未触发且已涨超阈值 → 尾盘按 MA5 追。

REACH_LOOKBACK = 120      # 成交概率统计的样本窗口（交易日）
REACH_MAX_HOLD = 10       # 挂单有效期：10 个交易日内未触及即视为废单
LOW_PROB = 0.35           # 成交概率低于此值 → 标红"废单风险高"
FOMO_WINDOW = 5           # 强制跟随观察窗口（交易日）
FOMO_TRIGGER_PCT = 0.06   # 窗口内涨幅超过该值 → 触发尾盘跟随
FOMO_WEIGHT = 0.15        # 强制跟随占用的风险预算比例
BREAKOUT_CONFIRM = 1.005  # 突破确认：站上阻力 0.5% 才算有效突破
BREAKOUT_ZONE_ATR = 2.5   # 现价距实质阻力 ≤ 该倍数×ATR 视为"突破在即"

# ---- 贴身位 vs 有效回调（2026-08-29 关键修正）----
# 旧口径把"离现价最近的候选"当核心支撑，而最近的常常是昨收/MA5/整数关口这类贴身位。
#   诺普信 8/28：第一支撑 10.49 距现价仅 -0.4%（就是昨收），"回调"到那儿等于市价追高；
#   但真正的回调位 MA10=9.62（-8.7%）10 日成交概率只有 14%。
#   用贴身位算概率会得出"96% 能成交"的假象，把"等不到回调"这个真问题彻底掩盖掉。
MIN_PULLBACK_ATR = 1.0    # 有效回调：距现价至少 1×ATR，更近的属日内噪音、不算回调
MIN_TRACK_ATR = 0.8       # 均线轨：回踩位至少 0.8×ATR，否则与现价轨重复
MERGE_ATR = 0.5           # 两条轨入场价相距 <0.5×ATR 视为同一条，合并权重

# 各模式下风险预算在四条轨之间的分配
#   N=现价轨（立即买） A=有效回调轨 B=均线轨 C=突破轨
TRACK_WEIGHT = {
    "PULLBACK":      {"N": 0.15, "A": 0.45, "B": 0.25, "C": 0.15},
    "HYBRID":        {"N": 0.20, "A": 0.25, "B": 0.35, "C": 0.20},
    "TREND_FOLLOW":  {"N": 0.30, "A": 0.10, "B": 0.35, "C": 0.25},
    "BREAKOUT":      {"N": 0.15, "A": 0.10, "B": 0.20, "C": 0.55},
}
REGIME_LABEL = {
    "PULLBACK":     "回调型：有效回调位历史上够得着，以挂单等回调为主",
    "HYBRID":       "均衡型：回调可期但概率一般，回调轨与均线轨并行",
    "TREND_FOLLOW": "趋势跟随型：强势股不回踩，等深度回调=废单，现价轨+均线轨为主",
    "BREAKOUT":     "突破型：贴着实质阻力+多头排列，以突破追入为主",
}


def reach_prob(bars, rel, max_hold=REACH_MAX_HOLD, lookback=REACH_LOOKBACK):
    """挂单成交概率：以"相对当日收盘的位移"为标尺，统计历史上有多少比例的交易日
    能在随后 max_hold 日内触及该位移。

    rel < 0 = 回调单（目标 = 收盘×(1+rel)），判据：未来最低价 ≤ 目标；
    rel > 0 = 突破单（目标 = 收盘×(1+rel)），判据：未来最高价 ≥ 目标。

    必须用相对位移而非绝对价位：直接用价位比较会被股价的长期涨跌带偏
    （票从 30 涨到 60 后，30 元的历史价位永远"更容易触及"，概率会被系统性高估）。
    返回 (命中率, 中位等待天数, 样本数)。"""
    if not bars or len(bars) < 5:
        return None, None, 0
    n = len(bars)
    lo = max(1, n - lookback)
    hits, waits, total = 0, [], 0
    for i in range(lo - 1, n - 1):
        if i < 0:
            continue
        c = bars[i]["last"]
        if not c:
            continue
        hit_at = None
        for k in range(1, max_hold + 1):
            j = i + k
            if j >= n:
                break
            if rel < 0:
                if bars[j]["low"] <= c * (1 + rel):
                    hit_at = k
                    break
            else:
                if bars[j]["high"] >= c * (1 + rel):
                    hit_at = k
                    break
        total += 1
        if hit_at:
            hits += 1
            waits.append(hit_at)
    if not total:
        return None, None, 0
    med = sorted(waits)[len(waits) // 2] if waits else None
    return hits / total, med, total


def effective_pullback_support(px, ma, boll, bars, atr):
    """有效回调支撑：距现价 ≥ MIN_PULLBACK_ATR×ATR 的最近支撑 → (价格, 依据列表)。

    为什么要跳过贴身位：详见 MIN_PULLBACK_ATR 注释。贴身位（昨收/MA5/整数关口）
    距现价不到 1 个 ATR，"回调"到那里只是日内波动，挂单等价于市价追高；用它算成交
    概率会得到 90%+ 的假象，把"真正的回调等不到"这个真问题彻底掩盖掉。"""
    if not px:
        return None, []
    c = support_candidates(px, ma, boll, bars)
    if atr:
        far = [x for x in c if (px - x[0]) >= MIN_PULLBACK_ATR * atr]
    else:
        far = [x for x in c if (px - x[0]) / px >= 0.03]
    if far:
        p, b = far[0]
        return p, ([b] if isinstance(b, str) else list(b))
    if atr:
        p = px - 1.5 * atr
        return p, [f"无≥{MIN_PULLBACK_ATR:g}×ATR的结构支撑，ATR外推(−1.5×ATR)"]
    return None, []


def entry_regime(px, ma, boll, bars, atr, core_support, nearest_resistance):
    """判定入场模式 → dict(regime, p_eff, p_break, d_eff_atr, 理由列表)。

    判定优先级（关键：全部基于"有效回调位"而非贴身位）：
      1) 有效回调位历史上够得着（p_eff ≥ 0.5）→ PULLBACK
      2) 贴着实质阻力 + 多头排列 + 向上触及概率够高（p_break ≥ 0.40）→ BREAKOUT
      3) 有效回调位历史上够不着（p_eff < LOW_PROB）→ TREND_FOLLOW（典型强势股）
      4) 其余 → HYBRID"""
    out = {"regime": None, "p_core": None, "p_eff": None, "p_break": None,
           "d_core_atr": None, "d_eff_atr": None, "reasons": []}
    if not px or not bars or not atr:
        out["regime"] = "HYBRID"
        out["reasons"].append("缺 ATR/K 线，回落均衡型（保守默认）")
        return out

    ma5, ma10, ma20 = _f(ma.get("MA_5")), _f(ma.get("MA_10")), _f(ma.get("MA_20"))

    eff, eff_basis = effective_pullback_support(px, ma, boll, bars, atr)
    out["eff_support"], out["eff_basis"] = eff, eff_basis

    if core_support:
        out["d_core_atr"] = (px - core_support) / atr
        out["p_core"], _, _ = reach_prob(bars, core_support / px - 1)
    if eff and eff < px:
        out["d_eff_atr"] = (px - eff) / atr
        out["p_eff"], _, _ = reach_prob(bars, eff / px - 1)
    if nearest_resistance and nearest_resistance > px:
        out["p_break"], _, _ = reach_prob(bars, nearest_resistance * BREAKOUT_CONFIRM / px - 1)

    p_eff, p_break = out["p_eff"], out["p_break"]
    d = out["d_eff_atr"]
    stack = bool(ma5 and ma10 and ma20 and ma5 > ma10 > ma20 and px > ma20)

    if p_eff is not None and p_eff >= 0.5:
        out["regime"] = "PULLBACK"
        out["reasons"].append(
            f"有效回调位{eff:.2f}（{' + '.join(eff_basis)}）距现价{d:.1f}×ATR，"
            f"历史{REACH_MAX_HOLD}日内触及概率{p_eff:.0%} → 等回调是合理的主要上车方式")
    elif (nearest_resistance and p_break is not None and p_break >= 0.40 and stack
          and (nearest_resistance - px) <= BREAKOUT_ZONE_ATR * atr):
        out["regime"] = "BREAKOUT"
        out["reasons"].append(
            f"现价距实质阻力{nearest_resistance:.2f}仅{(nearest_resistance-px)/atr:.1f}×ATR，"
            f"均线多头排列，历史{REACH_MAX_HOLD}日内向上触及概率{p_break:.0%} → 突破追入优先；"
            f"而有效回调位{eff:.2f}（−{d:.1f}×ATR）触及概率仅{p_eff:.0%}，等回调性价比低")
    elif p_eff is not None and p_eff < LOW_PROB:
        out["regime"] = "TREND_FOLLOW"
        out["reasons"].append(
            f"有效回调位{eff:.2f}（−{d:.1f}×ATR）历史{REACH_MAX_HOLD}日内触及概率仅{p_eff:.0%}"
            f" → 等回调大概率等成废单，改以现价轨/均线轨跟随")
    else:
        out["regime"] = "HYBRID"
        pe = f"{p_eff:.0%}" if p_eff is not None else "—"
        dd = f"{d:.1f}" if d is not None else "—"
        out["reasons"].append(
            f"有效回调位{eff:.2f if eff else 0:.2f}触及概率{pe}、回踩距离{dd}×ATR，"
            f"均处中间地带 → 回调轨与均线轨并行")
        if p_eff is None:
            out["reasons"][-1] += "（缺有效回调位，成交概率无法计算）"
    out["label"] = REGIME_LABEL.get(out["regime"], "")
    out["stack"] = stack
    return out


def _track(name, title, entry, stop, weight, budget, cap, trigger, note,
           prob=None, wait=None, px=None):
    """单轨计划：按"风险预算 × 该轨权重 ÷ 止损幅度"反推仓位（与旧版 position_plan 同口径，
    只是把总预算按轨道权重切分，使 Σ(仓位×止损幅度) = 总风险预算）。"""
    if not entry or not stop or entry <= stop or not weight:
        return None
    stop_pct = (entry - stop) / entry
    if stop_pct <= 0:
        return None
    pos = min(budget * weight / stop_pct, cap * weight)
    t = {"name": name, "title": title, "entry": entry, "stop": stop,
         "stop_pct": stop_pct, "weight": weight, "pos": pos,
         "risk": pos * stop_pct, "trigger": trigger, "note": note,
         "prob": prob, "wait": wait,
         "low_prob": bool(prob is not None and prob < LOW_PROB)}
    if px:
        t["dist"] = (entry - px) / px
        t["px"] = px
    return t


def _merge_tracks(tracks, atr, budget, cap):
    """两条轨的入场价相距 < MERGE_ATR×ATR 时视为同一条（回调轨与均线轨常重合），
    合并权重、入场取更低者、止损取更低者。"""
    if not atr or len(tracks) < 2:
        return tracks
    out = []
    for t in sorted(tracks, key=lambda x: -x["entry"]):
        # 只合并"同为现价下方的回踩类轨道"（回调轨 A 与均线轨 B 常落在同一带）；
        # 现价轨 N 与突破轨 C 方向/性质不同，合并会把"突破买入"降级成"回踩买入"，禁止。
        mergable = t.get("name") in ("A", "B")
        if (out and mergable and out[-1].get("name") in ("A", "B")
                and abs(out[-1]["entry"] - t["entry"]) < MERGE_ATR * atr):
            p = out[-1]
            p["entry"] = min(p["entry"], t["entry"])
            p["stop"] = min(p["stop"], t["stop"])
            p["stop_pct"] = (p["entry"] - p["stop"]) / p["entry"]
            p["weight"] = round(p["weight"] + t["weight"], 4)
            p["pos"] = min(budget * p["weight"] / p["stop_pct"], cap * p["weight"])
            p["risk"] = p["pos"] * p["stop_pct"]
            p["title"] = f"{p['title']} + {t['title']}"
            # 合并后入场价已改为两者更低者，原 trigger 里的旧价位会自相矛盾，重写
            p["trigger"] = (f"盘中回踩 {p['entry']:.2f} 不破即可买入（回调轨与均线轨在此重合，"
                            f"相距 <{MERGE_ATR:g}×ATR，视为同一档）")
            if t.get("prob") is not None and p.get("prob") is not None:
                p["prob"] = max(p["prob"], t["prob"])
            p["dist"] = (p["entry"] - p["px"]) / p["px"]
            p["merged"] = True
            continue
        out.append(t)
    return out


def entry_tracks(px, ma, boll, bars, atr, core_support, nearest_resistance,
                 budget=0.03, cap=1.0, regime=None, stop_core=None,
                 near_resist=None, near_resist_basis=""):
    """生成四轨买入计划 + 强制跟随条款 + 踏空成本评估。

    N 现价轨：立即买入，止损 = 趋势失效位（stop_core）
    A 回调轨：挂**有效回调位**（≥1×ATR，跳过贴身位），止损 = 该位下方
    B 均线轨：回踩 MA5/MA10/MA20 中最近且 ≥0.8×ATR 的一条，止损 = 该均线下方
    C 突破轨：站上最近实质阻力 ×1.005 追入，止损 = 阻力下方（阻力变支撑）
    FOMO     ：窗口内各轨均未触发且已涨超阈值 → 尾盘按 MA5 追（踏空保险）

    每条轨独立用"风险预算×该轨权重÷该轨止损幅度"反推仓位，
    故 Σ(仓位×止损幅度) = 总风险预算，不会因为多开几条轨而放大总风险。"""
    res = {"regime": regime, "tracks": [], "fomo": None, "miss": None, "notes": []}
    if not px or not atr:
        return res

    rg = (regime or {}).get("regime") or "HYBRID"
    w = dict(TRACK_WEIGHT.get(rg, TRACK_WEIGHT["HYBRID"]))
    p_eff = (regime or {}).get("p_eff")
    eff = (regime or {}).get("eff_support")

    # 废单保护：有效回调位历史上够不着时，把回调轨预算压到 0.10，让位给现价/均线/突破轨
    if p_eff is not None and p_eff < LOW_PROB and w["A"] > 0.10:
        freed = w["A"] - 0.10
        w["A"] = 0.10
        w["N"] += freed * 0.5
        w["B"] += freed * 0.3
        w["C"] += freed * 0.2
        res["notes"].append(
            f"有效回调位触及概率仅{p_eff:.0%}（<{LOW_PROB:.0%}），回调轨预算由"
            f"{TRACK_WEIGHT[rg]['A']:.0%}压缩至10%，让位给现价轨/均线轨/突破轨")

    # --- N 现价轨 ---
    if stop_core and px > stop_core:
        t = _track("N", "现价轨（立即建仓）", px, stop_core, w["N"], budget, cap,
                   "不等待回调，直接以现价建底仓（强势股踏空风险的主要对冲手段）",
                   "止损沿用趋势失效位 → 入场价越高、止损幅度越大、可买仓位越小",
                   None, None, px)
        if t:
            res["tracks"].append(t)

    # --- A 有效回调轨 ---
    eff_basis = (regime or {}).get("eff_basis") or []
    if isinstance(eff_basis, str):          # support_candidates 可能只回传单个依据字符串
        eff_basis = [eff_basis]
    if eff and eff < px:
        st, why = stop_of(eff, atr, px)
        prob, wait, _ = reach_prob(bars, eff / px - 1)
        t = _track("A", "回调轨（挂有效回调位）", eff, st, w["A"], budget, cap,
                   f"盘中回踩 {eff:.2f} 不破（挂单价 {eff:.2f}，{REACH_MAX_HOLD}日内有效）",
                   why, prob, wait, px)
        if t:
            t["basis"] = " + ".join(eff_basis)
            res["tracks"].append(t)

    # --- B 均线轨（须 ≥0.8×ATR，否则与现价轨重复）---
    ma5, ma10, ma20 = _f(ma.get("MA_5")), _f(ma.get("MA_10")), _f(ma.get("MA_20"))
    b_px, b_basis = None, None
    for lv, nm in ((ma5, "MA5"), (ma10, "MA10"), (ma20, "MA20")):
        if lv and lv < px and (px - lv) >= MIN_TRACK_ATR * atr:
            b_px, b_basis = lv, nm
            break
    if b_px:
        st, why = stop_of(b_px, atr, px)
        prob, wait, _ = reach_prob(bars, b_px / px - 1)
        t = _track("B", f"均线轨（回踩{b_basis}）", b_px, st, w["B"], budget, cap,
                   f"盘中回踩 {b_basis}({b_px:.2f}) 且收盘不破 → 尾盘买入",
                   why, prob, wait, px)
        if t:
            t["basis"] = b_basis
            res["tracks"].append(t)

    # --- C 突破轨 ---
    # 注意：突破轨要突破的是"眼前这道坎"（即时阻力 147.79 之类），
    #   不能用 nearest_resistance —— 那是 ≥2×ATR 之外的 R:R 目标位（生益算出 177.93，
    #   +22%，拿它当突破入场价毫无意义，挂一年也等不到）。
    c_res = near_resist or nearest_resistance
    c_res_basis = near_resist_basis if near_resist else ""
    if c_res and c_res > px:
        ent = c_res * BREAKOUT_CONFIRM
        st, why = stop_of(c_res, atr, px)
        prob, wait, _ = reach_prob(bars, ent / px - 1)
        t = _track("C", "突破轨（站上即时阻力）", ent, st, w["C"], budget, cap,
                   f"放量（≥5日均量1.2倍）站上 {c_res:.2f} 且收盘站稳 → 次日买入",
                   why, prob, wait, px)
        if t:
            t["basis"] = c_res_basis
            res["tracks"].append(t)

    res["tracks"] = _merge_tracks(res["tracks"], atr, budget, cap)

    # 权重归一化：某条轨不成立时（如福耀玻璃 8/28 的 MA5/10/20 全挤在现价下方 1.4% 内，
    #   均线轨与现价轨重复而被剔除），它的预算不能凭空蒸发 —— 否则"风险预算 3%"
    #   实际只用了 2.25%，参数失去意义。剩余额度按比分配给有效轨道，总敞口不变。
    wsum = sum(t["weight"] for t in res["tracks"])
    if res["tracks"] and 0 < wsum < 0.999:
        for t in res["tracks"]:
            t["weight"] = round(t["weight"] / wsum, 4)
            t["pos"] = min(budget * t["weight"] / t["stop_pct"], cap * t["weight"])
            t["risk"] = t["pos"] * t["stop_pct"]
        res["notes"].append(
            f"部分轨道不成立（原始权重合计 {wsum:.0%}），剩余风险额度已按比分配给有效轨道，"
            f"总风险敞口仍为 {budget:.0%}")

    # --- 踏空成本（这是整个改造要回答的核心问题）---
    if p_eff is not None and eff:
        res["miss"] = {
            "p_eff": p_eff, "eff": eff, "low": p_eff < LOW_PROB,
            "text": (f"若只在回调位 {eff:.2f}（−{(px-eff)/atr:.1f}×ATR）挂单："
                     f"历史{REACH_LOOKBACK}日样本中{REACH_MAX_HOLD}日内能成交的概率为 **{p_eff:.0%}**"
                     + (f"——属废单风险区，**只挂回调单大概率错过整段行情**"
                        if p_eff < LOW_PROB else
                        "——回调可期，挂单是合理的主要上车方式")),
        }
    elif core_support:
        pc = (regime or {}).get("p_core")
        pctxt = f"，历史触及概率 {pc:.0%}" if pc is not None else ""
        res["miss"] = {
            "p_eff": pc, "eff": core_support, "low": None,
            "text": (f"未找到 ≥{MIN_PULLBACK_ATR:g}×ATR 的有效回调位（最近支撑 "
                     f"{core_support:.2f} 属贴身位{pctxt}）→ 等回调无意义，"
                     f"应以现价轨/突破轨为主"),
        }

    # --- 强制跟随条款（踏空保险）---
    fomo_px = ma5 or (bars[-1]["last"] if bars else None)
    if fomo_px:
        st, why = stop_of(fomo_px, atr, px)
        if st and fomo_px > st:
            stop_pct = (fomo_px - st) / fomo_px
            pos = min(budget * FOMO_WEIGHT / stop_pct, cap * FOMO_WEIGHT)
            res["fomo"] = {
                "window": FOMO_WINDOW, "trigger_pct": FOMO_TRIGGER_PCT,
                "entry_basis": "MA5" if ma5 else "最新收盘",
                "entry": fomo_px, "stop": st, "stop_pct": stop_pct,
                "pos": pos, "weight": FOMO_WEIGHT, "note": why,
                "text": (f"若 {FOMO_WINDOW} 个交易日内各轨均未触发，"
                         f"且股价较今日收盘上涨 ≥{FOMO_TRIGGER_PCT:.0%}，"
                         f"则以当日{'MA5' if ma5 else '收盘价'}（现为 {fomo_px:.2f}）尾盘买入，"
                         f"止损 {st:.2f}，仓位上限 {pos:.0%}"
                         f"（占用风险预算的 {FOMO_WEIGHT:.0%}，从剩余未用额度中出，不额外增加总风险）"),
            }
    return res


def cluster(cands, px, tol=CLUSTER_TOL):
    """把候选按价位聚类成"共振区"。cands = [(price, basis, weight)]。

    1% 内的候选合并：价格为加权平均，依据合并（去重），权重累加（越多依据共振越强）。"""
    if not cands:
        return []
    items = sorted(cands, key=lambda x: x[0])
    tol_abs = abs(px or items[0][0]) * tol
    zones = []
    for p, b, w in items:
        if zones and p - zones[-1]["hi"] <= tol_abs:
            z = zones[-1]
            tot = z["weight"] + w
            z["price"] = (z["price"] * z["weight"] + p * w) / tot if tot else p
            z["hi"] = max(z["hi"], p)
            z["weight"] = tot
            if b not in z["bases"]:
                z["bases"].append(b)
        else:
            zones.append({"price": p, "hi": p, "weight": w, "bases": [b]})
    return zones
