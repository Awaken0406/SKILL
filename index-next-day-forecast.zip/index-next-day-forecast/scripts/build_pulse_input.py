# -*- coding: utf-8 -*-
"""
build_pulse_input.py —— 把 westock 接口原始返回组装成 abnormal_sectors.py 的输入包。

为什么要单独一层：
  1) data_sector(mode=ranking&kind=concept) 行数通常几百条，**超过 8 万字符会自动落盘**，
     禁止读回上下文；本脚本直接 json.load 落盘文件，全程不进上下文。
  2) 接口返回有包装层（{"data":{"rows":[...]}}），本脚本做兼容解包，
     让 abnormal_sectors.py 只认统一格式，避免每次手写解析出错。

用法：
  python build_pulse_input.py --sector <落盘文件> [--dist <changedist落盘文件>] \
      --asof 2026-09-18 --scope concept --out OUT/pulse_raw.json

输入兼容：
  --sector  {"data":{"rows":[...]}} / {"rows":[...]} / [ {...}, ... ]
  --dist    {"data":{...}} / {...}
输出：
  {"asof":..., "scope":..., "rows":[...], "dist":{...}}
"""
import argparse
import io
import json
import os
import re


def load_json(path):
    if not path:
        return None
    with io.open(path, encoding="utf-8-sig") as f:
        txt = f.read()
    txt = txt.strip()
    if not txt:
        raise SystemExit("[错误] 文件为空: %s" % path)
    try:
        return json.loads(txt)
    except ValueError:
        # 少数情况下工具会追加一行非 JSON 前缀/尾注，尝试切出最大的 JSON 片段
        starts = [m.start() for m in re.finditer(r"[{\[]", txt)]
        for s in starts:
            for e in range(len(txt), s, -1):
                frag = txt[s:e]
                if not (frag.endswith("}") or frag.endswith("]")):
                    continue
                try:
                    return json.loads(frag)
                except ValueError:
                    continue
        raise SystemExit("[错误] 无法解析为 JSON: %s" % path)


def unwrap(node, keys=("data", "result")):
    """剥掉接口的包装层，返回最内层对象。"""
    seen = 0
    while isinstance(node, dict) and seen < 4:
        hit = None
        for k in keys:
            v = node.get(k)
            if isinstance(v, (dict, list)) and v:
                hit = v
                break
        if hit is None:
            break
        node = hit
        seen += 1
    return node


def find_rows(node):
    """从任意层级的返回里找出板块行列表。"""
    if isinstance(node, list):
        return node
    if not isinstance(node, dict):
        return []
    for k in ("rows", "list", "items", "data"):
        v = node.get(k)
        if isinstance(v, list) and v and isinstance(v[0], dict):
            return v
    # 兜底：取唯一一个"元素是 dict 且有 code/name"的值
    for v in node.values():
        if isinstance(v, list) and v and isinstance(v[0], dict) \
                and ("code" in v[0] or "name" in v[0]):
            return v
    return []


def find_dist(node):
    """从 changedist 返回里找出涨跌分布 dict。"""
    if not isinstance(node, dict):
        return {}
    # 特征字段：涨跌家数或涨跌停家数
    marks = ("upCount", "downCount", "upLimitCount",
             "limitUpCount", "flatCount")
    if any(k in node for k in marks):
        return node
    for v in node.values():
        if isinstance(v, dict) and any(k in v for k in marks):
            return v
    return {}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sector", required=True,
                    help="data_sector(mode=ranking) 的原始返回 / 落盘文件")
    ap.add_argument("--dist", default=None,
                    help="data_changedist() 的原始返回 / 落盘文件（可选，用于市场背景）")
    ap.add_argument("--asof", required=True, help="数据日期 YYYY-MM-DD")
    ap.add_argument("--scope", default="concept",
                    help="板块口径标签，concept（概念）或 industry（行业），默认 concept")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    s_raw = unwrap(load_json(a.sector))
    rows = find_rows(s_raw)
    if not rows:
        raise SystemExit("[错误] 未在 %s 中找到板块行数据（rows 为空）" % a.sector)

    out_rows = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        code = r.get("code") or r.get("symbol") or r.get("secId")
        if not code:
            continue
        out_rows.append(r)

    dist = {}
    if a.dist:
        dist = find_dist(unwrap(load_json(a.dist)))

    pkg = {"asof": a.asof, "scope": a.scope, "rows": out_rows, "dist": dist}
    d = os.path.dirname(os.path.abspath(a.out))
    if d and not os.path.isdir(d):
        os.makedirs(d)
    json.dump(pkg, io.open(a.out, "w", encoding="utf-8"), ensure_ascii=False)

    keys = set()
    for r in out_rows[:200]:
        keys |= set(r.keys())
    print("[OK] rows=%d -> %s" % (len(out_rows), a.out))
    print("[OK] dist=%s" % ("yes" if dist else "no（缺全市场涨跌背景，KPI 卡会少一行涨停/成交额）"))
    print("[字段] %s" % ", ".join(sorted(keys)))


if __name__ == "__main__":
    main()
