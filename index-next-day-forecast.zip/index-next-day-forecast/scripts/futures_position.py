# -*- coding: utf-8 -*-
"""
股指期货会员持仓：中信席位 + 机构（前 20 会员合计）今日净开多 / 净开空及手数。

数据源：中国金融期货交易所 每日会员成交持仓排名
    http://www.cffex.com.cn/sj/ccpm/{YYYYMM}/{DD}/{PRODUCT}.xml
字段语义（已实测确认）：
    datatypeid = 0 成交量排名 / 1 持买单量（多头持仓）排名 / 2 持卖单量（空头持仓）排名
    volume     = 该席位该合约的成交或持仓量（手）
    varvolume  = 较上一交易日的增减（手）
    shortname  = 会员简称 + "(代客)" —— 中金所披露的是经纪业务口径，不含自营

用法:
    python futures_position.py [--date 2026-09-11] [--seat 中信期货] [--out futures.json]

设计要点:
  - 不传 --date 时自动向前回溯找最近有数据的交易日（非交易日会 302 到 404 页面，必须靠解析校验识别）
  - 同时给出「主力合约」与「品种全合约合计」两个口径
  - 只输出客观数字；方向性解读交给模型写进 config 的 futures_note
"""
import argparse
import json
import sys
import urllib.request
import xml.etree.ElementTree as ET
from collections import defaultdict
from datetime import date, timedelta

BASE = "http://www.cffex.com.cn/sj/ccpm/%s/%s/%s.xml"
PRODUCTS = ("IF", "IH", "IC", "IM")
PRODUCT_CN = {"IF": "沪深300", "IH": "上证50", "IC": "中证500", "IM": "中证1000"}
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}


def fetch(product, ymd):
    """返回 (root, err)。非交易日返回的是 302 的 HTML 页面，解析会失败 -> 靠这里识别。"""
    y, m, d = ymd[:4], ymd[4:6], ymd[6:8]
    url = BASE % (y + m, d, product)
    try:
        req = urllib.request.Request(url, headers=UA)
        raw = urllib.request.urlopen(req, timeout=20).read()
    except Exception as e:
        return None, "请求失败 %s" % e
    if not raw.lstrip().startswith(b"<?xml"):
        return None, "非 XML 内容（该日期无数据 / 非交易日）"
    try:
        root = ET.fromstring(raw)
    except ET.ParseError as e:
        return None, "XML 解析失败 %s" % e
    if len(root.findall("data")) == 0:
        return None, "空数据"
    return root, None


def parse_product(root):
    """-> {member: {contract: {"long","short","d_long","d_short","vol"}}}, 主力合约"""
    rec = defaultdict(lambda: defaultdict(lambda: {"long": 0, "short": 0, "d_long": 0,
                                                   "d_short": 0, "vol": 0}))
    cvol = defaultdict(int)
    tradingday = None
    for d in root.findall("data"):
        inst = d.findtext("instrumentid")
        dt = d.findtext("datatypeid")
        name = d.findtext("shortname")
        v = int(d.findtext("volume") or 0)
        chg = int(d.findtext("varvolume") or 0)
        tradingday = tradingday or d.findtext("tradingday")
        if dt == "0":
            rec[name][inst]["vol"] += v
            cvol[inst] += v
        elif dt == "1":
            rec[name][inst]["long"] += v
            rec[name][inst]["d_long"] += chg
        elif dt == "2":
            rec[name][inst]["short"] += v
            rec[name][inst]["d_short"] += chg
    main = max(cvol, key=cvol.get) if cvol else None
    return rec, main, tradingday


def agg(rec, contracts=None):
    """把席位在某合约集合上的多空与增减加总。contracts=None 表示全部合约。"""
    o = {"long": 0, "short": 0, "d_long": 0, "d_short": 0}
    for member, byc in rec.items():
        for inst, r in byc.items():
            if contracts is not None and inst not in contracts:
                continue
            for k in o:
                o[k] += r[k]
    o["net"] = o["long"] - o["short"]
    o["d_net"] = o["d_long"] - o["d_short"]
    return o


def agg_member(rec, member, contracts=None):
    o = {"long": 0, "short": 0, "d_long": 0, "d_short": 0}
    for inst, r in rec.get(member, {}).items():
        if contracts is not None and inst not in contracts:
            continue
        for k in o:
            o[k] += r[k]
    o["net"] = o["long"] - o["short"]
    o["d_net"] = o["d_long"] - o["d_short"]
    return o


def pick_member(rec, keyword):
    hit = [n for n in rec if keyword in n]
    return hit


def verdict(o):
    """把净变动翻译成人话。"""
    dn = o["d_net"]
    if dn > 0:
        action, cls = "净开多", "up"
    elif dn < 0:
        action, cls = "净开空", "dn"
    else:
        action, cls = "净持仓不变", "flat"
    if o["d_long"] > 0 and o["d_short"] > 0:
        detail = "多空双增：多单 %+d 手 > 空单 %+d 手" % (o["d_long"], o["d_short"])
    elif o["d_long"] > 0 and o["d_short"] < 0:
        detail = "加多单 %+d 手、减空单 %+d 手" % (o["d_long"], o["d_short"])
    elif o["d_long"] < 0 and o["d_short"] > 0:
        detail = "减多单 %+d 手、加空单 %+d 手" % (o["d_long"], o["d_short"])
    elif o["d_long"] < 0 and o["d_short"] < 0:
        detail = "多空双减：多单 %+d 手、空单 %+d 手" % (o["d_long"], o["d_short"])
    else:
        detail = "多单 %+d 手、空单 %+d 手" % (o["d_long"], o["d_short"])
    return {"action": action, "cls": cls, "d_net": dn, "detail": detail,
            "text": "%s %d 手（%s）" % (action, abs(dn), detail)}


def find_trading_day(start, maxback=12):
    cur = start
    for _ in range(maxback):
        ymd = cur.strftime("%Y%m%d")
        root, err = fetch("IF", ymd)
        if root is not None:
            return ymd, None
        cur -= timedelta(days=1)
    return None, "回溯 %d 天仍未找到有数据的交易日" % maxback


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--date", default=None, help="YYYY-MM-DD 或 YYYYMMDD，默认自动探测最近交易日")
    ap.add_argument("--seat", default="中信期货", help="席位关键词，默认中信期货")
    ap.add_argument("--products", default=",".join(PRODUCTS))
    ap.add_argument("--out", default=None, help="输出 JSON 路径")
    args = ap.parse_args()

    prods = [p.strip().upper() for p in args.products.split(",") if p.strip()]

    if args.date:
        ymd = args.date.replace("-", "")
    else:
        ymd, err = find_trading_day(date.today())
        if err:
            print("[fatal]", err)
            sys.exit(2)

    out = {"meta": {"tradingday": ymd,
                    "date": "%s-%s-%s" % (ymd[:4], ymd[4:6], ymd[6:8]),
                    "source": "中金所 会员成交持仓排名 www.cffex.com.cn/sj/ccpm/",
                    "products": prods,
                    "main_contract": {},
                    "note": "披露口径为经纪业务(代客)，仅含各品种成交/持买/持卖前 20 名会员"}}
    recs, mains, seat_names = {}, {}, set()
    for p in prods:
        root, err = fetch(p, ymd)
        if root is None:
            print("[warn] %s 取数失败：%s" % (p, err))
            continue
        rec, main, td = parse_product(root)
        recs[p] = rec
        mains[p] = main
        out["meta"]["main_contract"][p] = main
        if td:
            out["meta"]["tradingday"] = td
        seat_names |= set(rec.keys())

    if not recs:
        print("[fatal] 全部品种取数失败")
        sys.exit(2)

    # --- 中信席位 ---
    hits = pick_member(recs[prods[0]], args.seat)
    if not hits:
        print("[fatal] 未找到匹配席位：%s；可用样例：%s"
              % (args.seat, sorted(seat_names)[:10]))
        sys.exit(2)
    seat_name = hits[0]
    seat = {"name": seat_name, "by_product": {}, "total_main": None, "total_all": None}
    tm = {"long": 0, "short": 0, "d_long": 0, "d_short": 0}
    ta = {"long": 0, "short": 0, "d_long": 0, "d_short": 0}
    for p, rec in recs.items():
        m = agg_member(rec, seat_name, {mains[p]} if mains.get(p) else None)
        a = agg_member(rec, seat_name)
        seat["by_product"][p] = {"cn": PRODUCT_CN.get(p, p), "main": m, "all": a}
        for k in tm:
            tm[k] += m[k]
            ta[k] += a[k]
    for o in (tm, ta):
        o["net"] = o["long"] - o["short"]
        o["d_net"] = o["d_long"] - o["d_short"]
    seat["total_main"], seat["total_all"] = tm, ta
    out["seat"] = seat

    # --- 机构整体（各品种已披露前 20 会员合计） ---
    inst = {"by_product": {}, "total_main": None, "total_all": None, "n_seats": len(seat_names)}
    im = {"long": 0, "short": 0, "d_long": 0, "d_short": 0}
    ia = {"long": 0, "short": 0, "d_long": 0, "d_short": 0}
    for p, rec in recs.items():
        m = agg(rec, {mains[p]} if mains.get(p) else None)
        a = agg(rec)
        inst["by_product"][p] = {"cn": PRODUCT_CN.get(p, p), "main": m, "all": a}
        for k in im:
            im[k] += m[k]
            ia[k] += a[k]
    for o in (im, ia):
        o["net"] = o["long"] - o["short"]
        o["d_net"] = o["d_long"] - o["d_short"]
    inst["total_main"], inst["total_all"] = im, ia
    out["institutions"] = inst

    # --- 净变动最大的席位 TOP5（全合约口径） ---
    movers = []
    for name in seat_names:
        o = {"long": 0, "short": 0, "d_long": 0, "d_short": 0}
        for p, rec in recs.items():
            r = agg_member(rec, name)
            for k in o:
                o[k] += r[k]
        o["net"] = o["long"] - o["short"]
        o["d_net"] = o["d_long"] - o["d_short"]
        movers.append({"name": name, "long": o["long"], "short": o["short"], "net": o["net"],
                       "d_long": o["d_long"], "d_short": o["d_short"], "d_net": o["d_net"]})
    movers.sort(key=lambda x: -abs(x["d_net"]))
    out["top_movers"] = movers[:5]

    out["verdict"] = {
        "seat_main": verdict(seat["total_main"]),
        "seat_all": verdict(seat["total_all"]),
        "inst_main": verdict(inst["total_main"]),
        "inst_all": verdict(inst["total_all"]),
    }
    out["hint"] = ("参考解读（需与现货量能交叉验证，非独立信号）：机构空单大头是套保盘——"
                   "空单增加常对应现货端买入/持仓上升（偏多），空单减少或净持仓转多常对应对冲解除、"
                   "现货离场（偏空）。席位为代客汇总、仅前 20 名、无法区分套保与投机，故为经验规律而非铁律。")

    js = json.dumps(out, ensure_ascii=False, indent=2)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(js)
        print("WROTE %s" % args.out)

    d = out["meta"]["date"]
    print("\n=== 股指期货席位持仓 %s（%s）===" % (d, out["meta"]["source"]))
    print("主力合约:", " ".join("%s=%s" % (p, mains.get(p)) for p in prods if mains.get(p)))
    for tag, o in (("中信·主力", seat["total_main"]), ("中信·全合约", seat["total_all"]),
                   ("机构·主力", inst["total_main"]), ("机构·全合约", inst["total_all"])):
        print("  %-10s 多 %6d(%+6d) 空 %6d(%+6d) 净 %7d 净变动 %+6d -> %s"
              % (tag, o["long"], o["d_long"], o["short"], o["d_short"], o["net"], o["d_net"],
                 verdict(o)["action"]))
    print("  中信席位:", seat_name)
    print("  净变动 TOP5:", ", ".join("%s %+d" % (m["name"].replace("(代客)", ""), m["d_net"])
                                    for m in out["top_movers"]))
    if not args.out:
        print("\n[JSON]\n" + js)


if __name__ == "__main__":
    main()
