#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
retail_ratio.py — 股票散户比例/筹码结构三层口径查询工具 v2.0 (2026-08-29)

用法:
    python retail_ratio.py 000636            # 深市
    python retail_ratio.py 600519            # 沪市
    python retail_ratio.py sz000636          # 带前缀也可
    python retail_ratio.py 000636 --json     # JSON 输出(供管线集成)

三层口径:
  L1 持股口径(季频锚点): 散户比例 ≈ 100% - 机构合计
      主口径 = 机构持仓明细聚合(RPT_MAIN_ORGHOLDDETAIL, 分母=A股流通盘)
      降级口径 = 十大流通股东机构占比(RPT_F10_EH_FREEHOLDERS, 分母=总股本)
  L2 户数趋势(月/季频): 股东户数/户均持股/户均市值 + 环比 → 散户化预警
  L3 行为口径(日频): 小单净流入占比(20日) + 融资余额占流通市值比 + 两融净买入趋势

数据源:
  东财 datacenter-web RPT_HOLDERNUM_DET / RPT_F10_EH_FREEHOLDERS /
       RPT_MAIN_ORGHOLDDETAIL(分页) / RPTA_WEB_RZRQ_GGMX
  资金流: 首选 westock data_fund_flow(--flow-file), 东财 push2his 兜底(易限流)
  北向: 2024-08 后无个股日度明细, 季度持仓用 westock data_north_holding

============================ v2.0 修复记录 ============================
以下 5 项均为 2026-08-29 实测确认的计算错误, 影响 v1.0 全部历史结果:

[P0-1] A+H 股票散户比例严重高估(长飞光纤 601869: v1 给 52.9%, 真实 ≈20.0%)
       根因: v1 用 extra = 明细聚合 - 十大机构 跨口径相减, 且注释把两个分母说反了。
       实测(同名主体 明细%/十大% 比值): 长飞 2.037 / 宁德 1.051 / 生益(纯A全流通) 1.000
       → 十大 FREE_HOLDNUM_RATIO 分母 = 公司总股本(含H股、含限售)
       → 明细 FREESHARES_RATIO  分母 = A股流通盘
       实测长飞明细中 BlackRock/CPE/Harvest/HKSCC/代理人 命中数全部为 0
       → 明细天然只覆盖 A 股机构, 自动排除 H 股托管
       修法: 机构合计直接取明细聚合, 不再与十大相减; 十大仅作展示与降级源。

[P0-2] H 股托管识别不全: v1 只认"香港中央结算(代理人)", 漏掉
       "HKSCC NOMINEES LIMITED"(宁德时代 300750 十大中占 4.87%)
       → 宁德 H 股托管被算成 A 股机构, 机构占比虚高、散户被低估。
       修法: 改为模式列表 HK_PROXY_PATTERNS(含中英文/全半角括号变体)。

[P0-3] 机构明细未分页: v1 只取单页 pageSize=500。
       实测【最新报告期(2026-06-30)】去重主体数(2026-08-29 复测):
         宁德 2515 / 茅台 1265 / 生益 975 / 长飞 308 / 风华 231 / 诺普信 55
       单页 500 只够覆盖诺普信, 其余全部被截断 → 聚合低估:
         宁德 1.11pp / 生益 0.11pp / 茅台 0.12pp
       修法: 新增 _dc_all() 分页拉取 + 按报告期过滤, 上限 DC_MAX_PAGES。

       ⚠ 为什么要先探最新 REPORT_DATE, 再用 (REPORT_DATE='YYYY-MM-DD') 过滤后分页:
         1) 效率: 宁德过滤后 6 页拿全; 不过滤时 8 页拿到 2758 个主体, 其中最新期
            只占 2515, 剩下 243 个是 2026-03-31 的历史期 —— 白白浪费 2 页预算。
         2) capped 语义正确性(决定性): 宁德不过滤时 capped=True, 会误报
            "长尾小基金可能未计入"; 过滤后 capped=False, 证明最新期确实拿全。
            不过滤时触的是【历史期】的顶, 不是【最新期】的顶 —— 那个告警是假的。
         3) 日期必须用【单引号】包裹, 双引号返回 0 条(实测)。
       注: 该接口按报告期倒序返回, 故不过滤时最新期通常也排在前面能拿到,
           但这属未承诺行为, 且 capped 语义必然错误, 因此仍必须过滤。

[P1-4] L3 资金流静默失败: v1 东财接口挂掉时返回空列表且不报警,
       导致 chip_adjustment 的"散户化+主力净流出 −2"永远不触发。
       2026-08-29 实测 6/6 标的全部失败(push2his 与 push2 均 RemoteDisconnected, 属限流)。
       修法: 返回 (rows, source, reason) 三元组, 降级原因进 JSON 的 degraded 字段。

[P1-5] 十大与明细报告期不同期仍静默相减(宁德: 十大 2026-08-05 vs 明细 2026-06-30)。
       修法: 检测后写入 warnings。

其他修正: retail 值 clamp[0,100]; 空数据不再静默给出 100%;
         retail_alert 的连续下降判断由 len>=3 放宽到 len>=2;
         户数环比与户均持股环比属同一现象, 不再并列为两条独立证据。

注意: 散户比例为估算口径(机构合计反推), 非官方披露;
      机构持仓明细为季报快照, 快照间变动无法捕捉(漏斗误差);
      "散户比例"实为"散户 + 个人大股东"(自然人持股无法从机构口径中剥离)。
"""
import argparse
import json
import sys
import time
import urllib.parse
import urllib.request
from datetime import date

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
      "Referer": "https://data.eastmoney.com/"}
DC = "https://datacenter-web.eastmoney.com/api/data/v1/get"

# 分页上限: 明细按持仓降序返回, 长尾基金持仓占比极小,
# 实测 8 页(4000条)后边际收益 <0.01pp, 再拉反而触发限流。
DC_MAX_PAGES = 8
DC_PAGE_SIZE = 500


def _get(url, retries=4, timeout=25):
    """指数退避重试。东财对高频请求会直接断连(RemoteDisconnected), 需退避而非密集重试。"""
    last = None
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers=UA)
            return json.loads(urllib.request.urlopen(req, timeout=timeout).read().decode())
        except Exception as e:  # noqa: BLE001
            last = e
            if i < retries - 1:
                time.sleep(1.5 * (2 ** i))   # 1.5s / 3s / 6s
    raise RuntimeError(f"请求失败(重试{retries}次): {type(last).__name__}: {last}")


def _dc(report, flt, cols="ALL", size=100, page=1, sort_cols=""):
    sc = f"&sortColumns={sort_cols}&sortTypes=-1" if sort_cols else ""
    url = (f"{DC}?reportName={report}&columns={urllib.parse.quote(cols)}"
           f"&filter={urllib.parse.quote(flt)}&pageSize={size}&pageNumber={page}"
           f"{sc}&source=WEB&client=WEB")
    d = _get(url)
    return (d.get("result") or {}).get("data") or []


def _dc_all(report, flt, dedup_key, size=DC_PAGE_SIZE, max_pages=DC_MAX_PAGES,
            sort_cols="", page_sleep=0.25):
    """分页拉全并按 dedup_key 去重。返回 (rows, pages, capped)。

    dedup_key: 函数(row) -> hashable。跨页会重复返回同一主体(实测两页交集 18/500),
    必须去重后再聚合, 否则重复计数会把机构占比抬高。
    """
    seen, pages, capped = {}, 0, False
    for p in range(1, max_pages + 1):
        try:
            rows = _dc(report, flt, cols="ALL", size=size, page=p, sort_cols=sort_cols)
        except Exception as e:  # noqa: BLE001
            print(f"[warn] {report} 第{p}页失败: {e}", file=sys.stderr)
            break
        if not rows:
            break
        pages = p
        for r in rows:
            k = dedup_key(r)
            if k:
                seen.setdefault(k, r)
        if len(rows) < size:
            break
        if p == max_pages:
            capped = True
        time.sleep(page_sleep)
    return list(seen.values()), pages, capped


def norm_code(raw):
    """归一化到 (纯6位代码, 带前缀代码, 东财secid市场号 0=深 1=沪)"""
    s = raw.strip().lower()
    for p in ("sh", "sz", "bj"):
        if s.startswith(p):
            num = s[2:]
            mkt = 1 if p == "sh" else (0 if p == "sz" else 0)
            return num, ("sh" if p == "sh" else "sz") + num, mkt
    if len(s) == 6 and s.isdigit():
        mkt = 1 if s.startswith(("6", "9", "5")) else 0
        pre = "sh" if mkt == 1 else "sz"
        return s, pre + s, mkt
    raise ValueError(f"无法识别代码: {raw}")


# ---------------- L1: 持股口径 ----------------

# 【2026-08-29 v2.2 重要发现】基金披露规则导致不同报告期的机构明细口径完备性天差地别:
#   季报(Q1/Q3, 报告期月份 3/9)  : 基金【只披露前十大重仓股】→ 口径严重残缺
#   半年报/年报(Q2/Q4, 月份 6/12): 基金披露【全部持仓】      → 口径完备
# 实测 Q1 主体数 / 上年报主体数 的覆盖率(2026-08-29, 8只票):
#   诺普信 8% / 生益 11% / 风华 17% / 海康 18% / 五粮液 28% / 立讯 33% / 宁德 80% / 茅台 83%
#   中位 28%。覆盖率取决于"该股是否为众多基金的前十大重仓": 茅台/宁德是核心持仓故覆盖高,
#   小票大量基金持有却不在前十大 → 季报口径下"消失"。
# 后果: 生益科技 年报期散户 29.05% → Q1 期 40.19%, 这 11pp 全是披露残缺的假象,
#       不是真实筹码变动。跨报告期类型比较散户比例是拿残缺数据当完整数据比。
FULL_DISCLOSURE_MONTHS = (6, 12)      # 半年报 / 年报 → 全部持仓, 口径完备
PARTIAL_DISCLOSURE_MONTHS = (3, 9)    # 一季报 / 三季报 → 仅前十大重仓, 口径残缺


def disclosure_completeness(report_date):
    """报告期的披露完备性: 'full'(半年报/年报) | 'partial'(季报) | 'unknown'"""
    try:
        m = int(str(report_date)[5:7])
    except Exception:  # noqa: BLE001
        return "unknown"
    if m in FULL_DISCLOSURE_MONTHS:
        return "full"
    if m in PARTIAL_DISCLOSURE_MONTHS:
        return "partial"
    return "unknown"


def prev_full_period(report_date):
    """往前找最近一个完备披露期(Q2/Q4), 用于季报口径下提供对照。返回 None 表示无法判断。"""
    try:
        y, m = int(str(report_date)[:4]), int(str(report_date)[5:7])
    except Exception:  # noqa: BLE001
        return None
    return {3: f"{y-1}-12-31", 6: f"{y-1}-12-31",
            9: f"{y}-06-30", 12: f"{y}-06-30"}.get(m)


# H 股整体托管户(名义持有人), 非 A 股机构持股, 必须从机构口径中剔除。
# 2026-08-29 实测: 宁德时代十大中为英文名 "HKSCC NOMINEES LIMITED"(4.87%),
# v1 只匹配中文"香港中央结算(代理人)"导致漏判 → 机构占比虚高。
HK_PROXY_PATTERNS = (
    "香港中央结算(代理人)",      # 长飞光纤 601869 (半角括号)
    "香港中央结算（代理人）",     # 全角括号变体
    "HKSCC NOMINEES",          # 宁德时代 300750
    "HKSCC NOMINEE",
)

# 判定"机构"的辅助特征: 东财 IS_HOLDORG 偶有缺失(实测生益
# "广新集团-中信证券-26GXKEB1担保及信托财产专户" 被判为个人), 用名称兜底。
ORG_NAME_HINTS = (
    "有限公司", "股份", "集团", "基金", "投资", "资产管理", "信托", "保险",
    "证券", "银行", "社保", "合伙企业", "中心", "研究院", "大学", "协会",
    "QFII", "Limited", "LTD", "Inc", "AG", "Capital", "Asset", "Fund",
)


def is_hk_proxy(name):
    n = (name or "").upper()
    return any(p.upper() in n for p in HK_PROXY_PATTERNS)


def top10_freeholders(num, mkt):
    """十大流通股东。返回 (holders, date)；无数据返回 (None, None) —— 不可返回 [],
    否则上层 sum([]) = 0 会静默算出"散户 100%"这种假结果。"""
    rows = _dc("RPT_F10_EH_FREEHOLDERS", f'(SECUCODE="{num}.{"SZ" if mkt==0 else "SH"}")',
               cols="ALL", size=500)
    if not rows:
        return None, None
    dates = [r["END_DATE"][:10] for r in rows if r.get("END_DATE")]
    if not dates:
        return None, None
    latest = max(dates)
    out = []
    for r in rows:
        if (r.get("END_DATE") or "")[:10] != latest:
            continue
        name = r.get("HOLDER_NAME", "") or ""
        flag = str(r.get("IS_HOLDORG") or "0")
        is_org = flag == "1" or (flag in ("", "0", "None")
                                 and any(h in name for h in ORG_NAME_HINTS))
        out.append({
            "name": name,
            "pct": float(r.get("FREE_HOLDNUM_RATIO") or 0),
            "is_org": bool(is_org),
            "type": r.get("HOLDER_TYPE") or "",
        })
    return sorted(out, key=lambda x: -x["pct"]), latest


def org_hold_detail(num, mkt, date_filter=None):
    """机构持仓明细聚合 —— 【v2 主口径】。

    口径(2026-08-29 实测, 修正 v1 注释中写反的部分):
      FREESHARES_RATIO 分母 = 【A股流通盘】
      而十大 FREE_HOLDNUM_RATIO 分母 = 【公司总股本】(含H股、含限售)
      同名主体 明细%/十大% 比值: 长飞 2.037 / 宁德 1.051 / 生益(纯A全流通) 1.000
    实测长飞明细中 BlackRock/CPE/Harvest/HKSCC/代理人 命中数全部为 0
      → 本明细天然只覆盖 A 股机构, 自动排除 H 股托管, 无需再做 A+H 特殊分支。

    返回 (聚合%, 报告期, 主体数, 是否触分页上限, 按类型分解)
    """
    base_flt = f'(SECUCODE="{num}.{"SZ" if mkt==0 else "SH"}")'
    # 先探一页拿最新报告期, 再按 (REPORT_DATE='YYYY-MM-DD') 过滤后分页。
    # 不过滤的代价(实测宁德时代 300750):
    #   8 页拿到 2758 个主体, 其中最新期只占 2515, 剩下 243 个是历史期 → 浪费 2 页预算;
    #   且 capped=True 会误报"长尾小基金未计入", 而过滤后 capped=False 证明已拿全
    #   —— 不过滤时触的是【历史期】的顶, 不是【最新期】的顶。
    # 过滤串中的日期必须用单引号, 双引号返回 0 条(实测)。
    try:
        probe = _dc("RPT_MAIN_ORGHOLDDETAIL", base_flt, cols="ALL", size=1, page=1)
    except Exception:  # noqa: BLE001
        probe = []
    latest = max(((r.get("REPORT_DATE") or "")[:10] for r in probe), default="")
    if date_filter:
        latest = date_filter          # 与十大对齐到同一报告期(避免跨期混算)
    flt = base_flt
    if latest:
        # 实测: 必须用单引号包裹日期, 双引号返回 0 条
        flt = f"{base_flt}(REPORT_DATE='{latest}')"
    rows, pages, capped = _dc_all(
        "RPT_MAIN_ORGHOLDDETAIL", flt, page_sleep=0.25,
        dedup_key=lambda r: (r.get("HOLDER_CODE") or r.get("FUND_CODE")
                             or r.get("HOLDER_NAME") or ""))
    if not rows and latest:          # 过滤式失败则回退到全期拉取
        rows, pages, capped = _dc_all(
            "RPT_MAIN_ORGHOLDDETAIL", base_flt, page_sleep=0.25,
            dedup_key=lambda r: (r.get("HOLDER_CODE") or r.get("FUND_CODE")
                                 or r.get("HOLDER_NAME") or ""))
        by_date = {}
        for r in rows:
            d = (r.get("REPORT_DATE") or "")[:10]
            if d == latest:
                by_date.setdefault(d, []).append(r)
        rows = by_date.get(latest) or []
    if not rows:
        return None, latest or None, 0, capped, {}
    holders, by_type = {}, {}
    for r in rows:
        code = (r.get("HOLDER_CODE") or r.get("FUND_CODE")
                or r.get("HOLDER_NAME") or "")
        pct = float(r.get("FREESHARES_RATIO") or 0)
        if not code or pct <= 0:
            continue
        if is_hk_proxy(r.get("HOLDER_NAME")):
            continue                   # 双保险: 明细理论上不含, 出现则剔除
        holders[code] = max(holders.get(code, 0), pct)   # 同主体取最大, 防重复行
        ot = r.get("F9_ORGTYPE_NAME") or "未分类"
        by_type[ot] = round(by_type.get(ot, 0) + pct, 3)
    if not holders:
        return None, latest or None, 0, capped, {}
    return sum(holders.values()), latest or None, len(holders), capped, by_type


def l1_holding(num, mkt):
    """散户比例估算。

    v2 主口径: 机构合计 = 机构持仓明细聚合(A股流通盘口径)
       —— 明细已含十大内机构, 无需跨集合去重, 也无需与十大相减(v1 的相减是
          跨分母的, 在 A+H 股上会算出荒谬结果: 长飞 v1=52.9% vs v2=20.0%)
    v2 降级口径: 明细失败时回退到十大机构占比, 并显式标注 basis=degraded。
    """
    warns = []
    holders, t10_date = top10_freeholders(num, mkt)
    holders = holders or []

    # 十大部分: 仅用于展示、交叉校验与降级
    hk_proxy_pct = sum(h["pct"] for h in holders if is_hk_proxy(h["name"]))
    is_ah = hk_proxy_pct > 0
    eff = [h for h in holders if not is_hk_proxy(h["name"])]
    t10_org = sum(h["pct"] for h in eff if h["is_org"])
    t10_all = sum(h["pct"] for h in eff)

    # 明细分(主口径)
    agg = det_date = None
    n_holder, capped, by_type = 0, False, {}
    try:
        agg, det_date, n_holder, capped, by_type = org_hold_detail(num, mkt)
    except Exception as e:  # noqa: BLE001
        warns.append(f"机构持仓明细拉取失败({type(e).__name__}), 已降级到十大口径")
        print(f"[warn] 机构持仓明细失败: {e}", file=sys.stderr)

    if t10_date and det_date and t10_date != det_date:
        warns.append(f"十大({t10_date})与机构明细({det_date})报告期不同期, "
                     f"数值不可直接相减(本项目已改用单一口径, 不受影响)")
    if capped:
        warns.append(f"机构明细分页触顶({DC_MAX_PAGES}页), 长尾小基金可能未计入, "
                     f"机构占比略偏低→散户比例略偏高")
    if not holders and agg is None:
        return {
            "date": None, "is_ah": False, "hk_proxy_pct": 0.0,
            "top10_all": None, "top10_org": None, "top10_retail_list": None,
            "org_total_est": None, "retail_ratio_est": None, "basis": "none",
            "note": "无持股数据, 不给出散户比例(宁缺勿假)", "top10": [],
            "warnings": warns or ["十大流通股东与机构明细均无数据"],
        }

    if agg is not None and agg > 0:
        inst_total = agg
        basis = "detail"
        note = (f"主口径=机构持仓明细聚合(A股流通盘口径, {n_holder}个主体, 报告期{det_date}); "
                f"散户比例=100%-机构合计")
    else:
        inst_total = t10_org
        basis = "top10_degraded"
        warns.append("明细不可用, 降级为十大流通股东口径(分母=总股本), "
                     "A+H股/高限售股会失真")
        note = (f"降级口径=十大流通股东机构占比(分母=总股本, 报告期{t10_date}); "
                f"未计入十大外的小基金, 机构占比偏低→散户比例偏高")

    retail = max(0.0, min(100.0, 100.0 - inst_total))   # clamp: 明细聚合>100 时不为负

    # 【v2.2】报告期披露完备性检测 —— 季报(Q1/Q3)只披露基金前十大重仓股,
    # 口径严重残缺, 散户比例被系统性高估, 且不可与半年报/年报数值做趋势对比。
    completeness = disclosure_completeness(det_date or t10_date)
    full_ref = None
    if completeness == "partial" and (det_date or t10_date):
        warns.append(
            f"当前报告期 {det_date or t10_date} 为【季报口径】: 基金仅披露前十大重仓股, "
            f"机构明细严重残缺(实测覆盖率中位仅28%), 机构占比被低估→散户比例被高估, "
            f"且不可与半年报/年报的散户比例做趋势对比")
        # 额外给出最近一个完备披露期(Q2/Q4)的对照值
        pf = prev_full_period(det_date or t10_date)
        if pf:
            try:
                agg2, d2, n2, _, _ = org_hold_detail(num, mkt, date_filter=pf)
                if agg2 is not None and agg2 > 0:
                    full_ref = {
                        "period": d2 or pf,
                        "org_total_est": round(agg2, 2),
                        "retail_ratio_est": round(max(0.0, min(100.0, 100.0 - agg2)), 2),
                        "holders": n2,
                    }
                    gap = round(retail - full_ref["retail_ratio_est"], 2)
                    warns.append(
                        f"完备期对照 {pf}: 散户 {full_ref['retail_ratio_est']}% "
                        f"(vs 季报口径 {retail:.2f}%, 差 {gap:+.2f}pp, 差额主要来自披露残缺)")
            except Exception as e:  # noqa: BLE001
                warns.append(f"完备期对照({pf})拉取失败({type(e).__name__})")

    if is_ah:
        note = (f"A+H结构: 已剔除H股托管户{hk_proxy_pct:.2f}%"
                f"({'/'.join(sorted({h['name'][:20] for h in holders if is_hk_proxy(h['name'])}))}); "
                f"机构明细本身只覆盖A股机构, 无需换算。{note}")
    return {
        "date": det_date or t10_date,
        "t10_date": t10_date,
        "detail_date": det_date,
        "is_ah": is_ah,
        "hk_proxy_pct": round(hk_proxy_pct, 2),
        "top10_all": round(t10_all, 2) if holders else None,
        "top10_org": round(t10_org, 2) if holders else None,
        "top10_retail_list": round(t10_all - t10_org, 2) if holders else None,
        "detail_holders": n_holder,
        "detail_by_type": by_type,
        "detail_pages_capped": capped,
        "org_total_est": round(inst_total, 2),
        "retail_ratio_est": round(retail, 2),
        "basis": basis,
        "disclosure": completeness,          # full=半年报/年报(完备) partial=季报(残缺)
        "full_period_reference": full_ref,   # 季报口径下给出的完备期对照值
        "note": note,
        "top10": holders,
        "warnings": warns,
    }


# ---------------- L2: 户数趋势 ----------------

# 最新一期距今超过此天数即视为"过期", 不据此下预警结论。
# 季报: 报告期末 → 披露 ≈ 1-2 个月; 若接口缺最新季报, 退到上一季 ≈ +91 天。
# 正常最大 ≈ 60(本期) + 91(退一季) ≈ 151 天 → 取 200 天作阈值。
L2_STALE_DAYS = 200


def days_since(datestr, today=None):
    """距今天数。日期解析失败返回 None(调用方需按"无法判断新鲜度"处理, 不得当作过期)。"""
    try:
        y, m, d = (int(x) for x in str(datestr)[:10].split("-"))
        return ((today or date.today()) - date(y, m, d)).days
    except Exception:  # noqa: BLE001
        return None


def holder_num_history(num, size=8):
    rows = _dc("RPT_HOLDERNUM_DET", f'(SECURITY_CODE="{num}")',
               cols="ALL", size=size)
    rows = sorted(rows, key=lambda r: r["END_DATE"], reverse=True)
    hist = []
    for r in rows:
        hist.append({
            "end_date": r["END_DATE"][:10],
            "notice_date": (r.get("HOLD_NOTICE_DATE") or "")[:10],
            "holders": r.get("HOLDER_NUM"),
            "chg_pct": round(float(r.get("HOLDER_NUM_RATIO") or 0), 2),
            "avg_shares": r.get("AVG_HOLD_NUM"),
            "avg_mcap_wan": round(float(r.get("AVG_MARKET_CAP") or 0) / 1e4, 1) if r.get("AVG_MARKET_CAP") else None,
            "interval_chg_pct": round(float(r.get("INTERVAL_CHRATE") or 0), 2) if r.get("INTERVAL_CHRATE") is not None else None,
        })
    return hist


def retail_alert(hist):
    """散户化/集中度预警规则。

    v2 修正:
      - 连续两期判断只用前 2 期, 条件却写 len>=3(v1) → 只有 2 期历史时永远判不出
        "集中度改善"。已放宽为 len>=2。
      - 户数环比与户均持股环比是同一现象的两种表述(户均持股=流通股/户数),
        v1 并列成两条, 读起来像两个独立证据。已合并为一条主证据 + 一条佐证。
      - 新增新鲜度闸门(2026-08-29 长飞光纤暴露): 东财 RPT_HOLDERNUM_DET 对部分
        标的历史覆盖不全 —— 长飞光纤 601869 只有 1 期且是 2018-07-20(距今 2962 天),
        复星医药 600196 直接 0 条。v1/v2 初版都拿 hist[0] 当"最新"直接判,
        若某票有 ≥2 期但全部过期, 就会拿几年前的状态误判为当下趋势。
        → 最新期距今 > L2_STALE_DAYS 一律返回"数据过期", 不下任何预警。
    """
    if not hist:
        return {"level": "无数据",
                "detail": f"东财 RPT_HOLDERNUM_DET 无该股股东户数记录, L2 不可用"}
    if len(hist) < 2:
        age = days_since(hist[0]["end_date"])
        tail = f"(最新期 {hist[0]['end_date']}, 距今 {age} 天)" if age is not None else ""
        return {"level": "数据不足", "detail": f"户数历史不足2期(仅{len(hist)}期){tail}"}
    age = days_since(hist[0]["end_date"])
    if age is not None and age > L2_STALE_DAYS:
        return {"level": "数据过期",
                "detail": (f"最新期 {hist[0]['end_date']} 距今 {age} 天"
                           f"(>{L2_STALE_DAYS}天阈值), 历史覆盖不全, "
                           f"不据此判断散户化/集中度; 请改用 L1/L3 或人工核对")}
    cur = hist[0]
    alerts, evidence = [], []
    if cur["chg_pct"] is not None and cur["chg_pct"] >= 30:
        alerts.append(f"最新期户数环比+{cur['chg_pct']:.0f}%(≥+30%阈值)")
    if hist[0]["avg_shares"] and hist[1]["avg_shares"]:
        drop = (hist[0]["avg_shares"] - hist[1]["avg_shares"]) / hist[1]["avg_shares"] * 100
        if drop <= -20:
            # 与户数环比同源(户均持股 = 流通股/户数), 标注为佐证而非独立证据
            evidence.append(f"佐证: 户均持股环比{drop:.0f}%(≤-20%阈值, 与户数环比同源)")
    if (cur["chg_pct"] is not None and hist[1]["chg_pct"] is not None
            and cur["chg_pct"] > 0 and hist[1]["chg_pct"] > 0):
        alerts.append("户数连续两期上升")
    if alerts:
        return {"level": "散户化预警", "detail": "; ".join(alerts + evidence)}
    down2 = ((cur["chg_pct"] or 0) < 0 and (hist[1]["chg_pct"] or 0) < 0)
    if down2:
        return {"level": "集中度改善", "detail": "户数连续两期下降, 筹码趋于集中"}
    return {"level": "中性", "detail": "未触发预警规则"}


# ---------------- L3: 行为口径 ----------------

def fund_flow_20d(num, mkt, days=20, flow_file=None):
    """资金流日K。返回 (rows, source, reason)。

    v2 修正[P1-4]: v1 返回 (rows, source) 两元组, 接口挂掉时返回 ([], "无"),
    调用方拿到空列表无从判断是"真的没资金流"还是"接口挂了"。
    2026-08-29 实测 6/6 标的东财全线 RemoteDisconnected(push2his 与 push2 均限流),
    导致 chip_adjustment 的"散户化+主力20日净流出 −2"永远不触发(生益少扣2分)。
    → 增加 reason 字段, 降级原因进入 JSON 的 degraded[], 由上层显式呈现。

    源优先级: westock 落盘 JSON(--flow-file) 优先于东财 —— 东财易限流,
    westock 经 MCP 连接器取数稳定。命令行未给 --flow-file 时才走东财。
    """
    reason = None
    # 1) westock(data_fund_flow 落盘 JSON) —— 优先
    if flow_file:
        try:
            d = json.load(open(flow_file, encoding="utf-8"))
            items = d.get("data") or []
            if isinstance(items, dict):
                items = items.get("data") or []
            rows = []
            for r in items:
                sn = None
                try:  # SmallNetFlow 优先; 无则用 散户买入-卖出 近似
                    if r.get("SmallNetFlow") is not None:
                        sn = float(r["SmallNetFlow"])
                    elif r.get("RetailInFlow") is not None and r.get("RetailOutFlow") is not None:
                        sn = float(r["RetailInFlow"]) - float(r["RetailOutFlow"])
                except Exception:  # noqa: BLE001
                    sn = None
                rows.append({
                    "date": (r.get("EndDate") or r.get("date") or "")[:10],
                    "main_net": float(r.get("MainNetFlow") or 0),
                    "small_net": sn or 0,
                    "main_pct": None, "small_pct": None,
                    "close": float(r.get("ClosePrice") or 0),
                })
            rows = [r for r in rows if r["date"]]
            rows.sort(key=lambda r: r["date"])
            if rows:
                return rows[-days:], "westock data_fund_flow", None
            reason = "westock 资金流文件无有效记录"
        except Exception as e:  # noqa: BLE001
            reason = f"westock 资金流文件读取失败({type(e).__name__})"
    # 2) 东财兜底(易限流)
    secid = f"{mkt}.{num}"
    url = (f"https://push2his.eastmoney.com/api/qt/stock/fflow/daykline/get?lmt={days}"
           f"&klt=101&secid={secid}&fields1=f1,f2,f3,f7"
           f"&fields2=f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61,f62,f63,f64,f65")
    try:
        d = _get(url, retries=4)
        kl = (d.get("data") or {}).get("klines") or []
        rows = []
        for r in kl:
            f = r.split(",")
            if len(f) < 12:
                continue
            # f0=日期 f1=主力净额 f2=小单净额 f3=中单 f4=大单 f5=超大单
            # f6=主力净占比 f7=小单净占比 ... f11=f62=收盘价 (实测2026-08-28)
            rows.append({
                "date": f[0], "main_net": float(f[1]), "small_net": float(f[2]),
                "main_pct": float(f[6]), "small_pct": float(f[7]), "close": float(f[11]),
            })
        if rows:
            return rows, "东方财富push2his", None
        if not reason:
            reason = "东财资金流接口返回空"
    except Exception as e:  # noqa: BLE001
        reason = f"东财资金流接口不可用({type(e).__name__}); " + (reason or "")
    return [], "无", (reason.strip("; ") or "无可用资金流数据源")


def margin(num, size=5, margin_file=None, prefixed=""):
    """两融明细: 优先 westock data_fund_margin 落盘JSON(--margin-file), 失败降级东财。

    westock 字段: FinanceValue=融资余额 FinanceBuyValue=融资买入 FinanceRefundValue=融资偿还
                 净买入 = FinanceBuyValue - FinanceRefundValue (与东财RZJME口径一致, 2026-08-28实测分毫不差)
    东财字段:    RZYE=融资余额 RZYEZB=融资余额/流通市值% RZJME=融资净买入
    注意: westock 无"占流通市值%"字段, 需结合流通市值计算或省略该列。
    """
    if margin_file:
        try:
            d = json.load(open(margin_file, encoding="utf-8"))
            items = d.get("data") or {}
            if isinstance(items, dict):
                items = (items.get(num) or items.get(prefixed)
                         or items.get("data") or [])
            rows = []
            for r in items:
                fb = float(r.get("FinanceBuyValue") or 0)
                fr = float(r.get("FinanceRefundValue") or 0)
                rows.append({
                    "date": (r.get("date") or "")[:10],
                    "rz_ye_yi": round(float(r.get("FinanceValue") or 0) / 1e8, 2),
                    "rz占比%": None,  # westock 无此字段
                    "rz_jme_yi": round((fb - fr) / 1e8, 2),
                })
            rows = [r for r in rows if r["date"]]
            rows.sort(key=lambda r: r["date"], reverse=True)
            if rows:
                return rows[:size], "westock data_fund_margin"
        except Exception:  # noqa: BLE001
            pass
    # 东财兜底
    rows = _dc("RPTA_WEB_RZRQ_GGMX", f'(scode="{num}")', cols="ALL", size=size,
               sort_cols="DATE")
    rows = sorted(rows, key=lambda r: r["DATE"], reverse=True)
    out = []
    for r in rows:
        out.append({
            "date": r["DATE"][:10],
            "rz_ye_yi": round(float(r["RZYE"] or 0) / 1e8, 2),          # 融资余额(亿)
            "rz占比%": round(float(r["RZYEZB"] or 0), 2),                  # 融资余额/流通市值
            "rz_jme_yi": round(float(r["RZJME"] or 0) / 1e8, 2),          # 融资净买入(亿)
        })
    return out, "东方财富RPTA_WEB_RZRQ_GGMX(兜底)"


# ---------------- main ----------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("code")
    ap.add_argument("--json", action="store_true", help="JSON 输出")
    ap.add_argument("--days", type=int, default=20)
    ap.add_argument("--flow-file", default=None,
                    help="资金流降级/优先源: westock data_fund_flow 落盘JSON路径")
    ap.add_argument("--margin-file", default=None,
                    help="两融优先源: westock data_fund_margin 落盘JSON路径(失败降级东财)")
    a = ap.parse_args()
    num, prefixed, mkt = norm_code(a.code)
    days = a.days

    if a.json:
        flows, flow_src, flow_reason = fund_flow_20d(num, mkt, days, a.flow_file)
        mg, mg_src = margin(num, margin_file=a.margin_file, prefixed=prefixed)
        l1 = l1_holding(num, mkt)
        data = {
            "code": prefixed, "query_time": time.strftime("%Y-%m-%d %H:%M:%S"),
            "L1_holding": l1,
            "L2_holder_num": holder_num_history(num),
            "L2_alert": None,
            "L3_flow_20d": flows, "L3_flow_source": flow_src,
            "L3_margin": mg, "L3_margin_source": mg_src,
            "sources": "东方财富数据中心; 北向季度见 westock data_north_holding",
            # 降级清单: 调用方(尤其评分内核)必须能看到"哪些维度是缺的",
            # 否则会把"接口挂了"误读成"该股没有主力流出"。
            "degraded": [],
        }
        hist = data["L2_holder_num"]
        data["L2_alert"] = retail_alert(hist)
        for w in (l1.get("warnings") or []):
            data["degraded"].append(f"L1: {w}")
        # L2 不可用(无数据/不足2期/过期)时同样必须进 degraded ——
        # 否则上层会把"没触发散户化预警"读成"筹码结构正常"。
        if data["L2_alert"]["level"] in ("无数据", "数据不足", "数据过期"):
            data["degraded"].append(
                f"L2: {data['L2_alert']['level']} — {data['L2_alert']['detail']} "
                f"→ 筹码趋势维度缺失, 散户化/集中度均无法判断")
        if not flows:
            data["degraded"].append(
                f"L3: 无日频资金流({flow_reason}) → 主力20日净额缺失, "
                f"chip_adjustment 的'散户化+主力净流出 −2'无法触发, 筹码分偏乐观")
        if not mg:
            data["degraded"].append("L3: 两融明细缺失")
        # 20日小单/主力累计
        if data["L3_flow_20d"]:
            small = sum(r["small_net"] for r in data["L3_flow_20d"]) / 1e8
            mainn = sum(r["main_net"] for r in data["L3_flow_20d"]) / 1e8
            data["L3_summary"] = {"small_net_20d_yi": round(small, 2), "main_net_20d_yi": round(mainn, 2)}
        print(json.dumps(data, ensure_ascii=False, indent=1))
        return

    # ---- 人类可读输出 ----
    print(f"=== {prefixed} 散户比例/筹码结构三层口径 ===")
    print(f"查询时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")

    # L1
    try:
        l1 = l1_holding(num, mkt)
        basis_tag = {"detail": "主口径·机构明细",
                     "top10_degraded": "⚠降级·十大口径",
                     "none": "⚠无数据"}.get(l1.get("basis"), l1.get("basis"))
        disc_tag = {"full": "披露完备", "partial": "⚠季报口径·披露残缺",
                    "unknown": "披露期未知"}.get(l1.get("disclosure"), "")
        print(f"[L1 持股口径·季频] 报告期 {l1['date']}  [{basis_tag}] [{disc_tag}]")
        if l1.get("is_ah"):
            print(f"  ⚠ A+H结构: 已剔除H股托管户 {l1['hk_proxy_pct']}%"
                  f"(H股整体托管, 非A股机构持股); 机构明细本身只覆盖A股机构")
        if l1.get("top10_all") is not None:
            print(f"  前十大合计 {l1['top10_all']}% | 其中机构 {l1['top10_org']}% "
                  f"| 十大内个人 {l1['top10_retail_list']}%   (分母=总股本, 仅供对照)")
        if l1.get("basis") == "detail":
            bt = l1.get("detail_by_type") or {}
            top_t = sorted(bt.items(), key=lambda x: -x[1])[:4]
            print(f"  机构明细聚合 = {l1['org_total_est']}%  "
                  f"({l1['detail_holders']}个主体, 分母=A股流通盘)"
                  + (f" | 构成: " + ", ".join(f"{k}{v:.1f}%" for k, v in top_t) if top_t else ""))
        if l1.get("retail_ratio_est") is None:
            print("  → 散户比例: 【无法确认】持股数据缺失, 不给出估算值")
        else:
            print(f"  → 机构合计 ≈ {l1['org_total_est']}% , 散户比例估算 ≈ {l1['retail_ratio_est']}%")
        fr = l1.get("full_period_reference")
        if fr:
            print(f"  ⚠ 季报口径残缺, 完备期对照 {fr['period']}: "
                  f"机构 {fr['org_total_est']}% / 散户 {fr['retail_ratio_est']}% "
                  f"({fr['holders']}个主体) ← 做趋势对比请用这一列")
        print(f"  ({l1['note']})")
        for w in (l1.get("warnings") or []):
            print(f"  ⚠ {w}")
        if l1["top10"]:
            print("  前五大流通股东:")
            for h in l1["top10"][:5]:
                print(f"    {h['name'][:28]:<30} {h['pct']:>6.2f}%  {'机构' if h['is_org'] else '个人'} {h['type']}")
    except Exception as e:  # noqa: BLE001
        print(f"[L1 失败] {e}")

    # L2
    print()
    try:
        hist = holder_num_history(num)
        print(f"[L2 户数趋势] 共{len(hist)}期(含月度披露期)")
        if hist:
            age0 = days_since(hist[0]["end_date"])
            if age0 is not None:
                mark = "  ⚠ 距今较久" if age0 > L2_STALE_DAYS else ""
                print(f"  最新期 {hist[0]['end_date']} 距今 {age0} 天{mark}")
        print(f"  {'截止日':<12}{'户数':>10}{'环比%':>8}{'户均股':>10}{'户均市值(万)':>12}{'披露日':>12}")
        for h in hist[:8]:
            print(f"  {h['end_date']:<12}{h['holders']:>10,}{h['chg_pct']:>8.1f}"
                  f"{(h['avg_shares'] or 0):>10,.0f}{(h['avg_mcap_wan'] or 0):>12.1f}{h['notice_date']:>12}")
        al = retail_alert(hist)
        print(f"  ⚠ 预警: {al['level']} — {al['detail']}")
    except Exception as e:  # noqa: BLE001
        print(f"[L2 失败] {e}")

    # L3
    print()
    try:
        flows, flow_src, flow_reason = fund_flow_20d(num, mkt, days, a.flow_file)
        if flows:
            small = sum(r["small_net"] for r in flows) / 1e8
            mainn = sum(r["main_net"] for r in flows) / 1e8
            last = flows[-1]
            print(f"[L3 行为口径·日频] 近{len(flows)}日 (来源: {flow_src})")
            print(f"  小单(散户)累计净流入 {small:+.2f} 亿 | 主力累计净流入 {mainn:+.2f} 亿")
            print(f"  最新({last['date']}): 小单 {last['small_net']/1e8:+.2f} 亿, 主力 {last['main_net']/1e8:+.2f} 亿, 收盘 {last['close']}")
        else:
            print(f"[L3 行为口径·日频] ⚠ 数据缺失, 不可用")
            print(f"     原因: {flow_reason}")
            print(f"     影响: 主力20日净额未知 → 筹码调整的'散户化+主力净流出 −2'无法触发, 分数偏乐观")
            print(f"     建议: 用 westock data_fund_flow 取数后以 --flow-file 传入")
    except Exception as e:  # noqa: BLE001
        print(f"[L3 失败] {e}")
    try:
        mg, mg_src = margin(num, margin_file=a.margin_file, prefixed=prefixed)
        if mg:
            pct_str = f" (占流通市值 {mg[0]['rz占比%']}%)" if mg[0]["rz占比%"] is not None else ""
            print(f"[L3 两融·日频] 最新{mg[0]['date']} (来源: {mg_src}): 融资余额 {mg[0]['rz_ye_yi']:.1f} 亿{pct_str}, 当日融资净买入 {mg[0]['rz_jme_yi']:+.2f} 亿")
            if len(mg) >= 5:
                seq = [m["rz_jme_yi"] for m in mg[:5]][::-1]
                print(f"          近5日融资净买入序列(旧→新): {['%+.2f' % x for x in seq]}")
    except Exception as e:  # noqa: BLE001
        print(f"[L3 两融失败] {e}")
    print("\n[北向·季频] 个股日度明细 2024-08 起停发; 季度持仓用 westock data_north_holding")
    print("口径说明:")
    print("  · 散户比例 = 100% - 机构合计(估算, 非官方披露); 分母为 A股流通盘")
    print("  · 该口径实为【散户 + 个人大股东】: 自然人持股无法从机构口径中剥离")
    print("    (例: 诺普信卢柏强 7.59% 等自然人股东被计入散户侧)")
    print("  · 十大 FREESHARES 分母=总股本, 机构明细分母=A股流通盘, 两者不可混算")
    print("  · 户数/户均为披露口径, 季报快照, 快照间变动无法捕捉")


if __name__ == "__main__":
    main()
