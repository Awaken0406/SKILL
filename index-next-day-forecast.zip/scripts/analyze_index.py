# -*- coding: utf-8 -*-
"""
大盘指数「次日走势 / 点位推演」量化底稿生成器。

用法:
    python analyze_index.py --kline kline.json [--ma 60] [--json stats.json]

输入 kline.json 支持两种格式:
  1) westock data_kline 原始输出: {"ok":true,"data":{"nodes":[{date,open,last,high,low,amount},...]}}
  2) 纯数组: [{date,open,close|last,high,low,amount|volume}, ...]

输出:
  默认打印人类可读的统计报告; 加 --json 同时落盘结构化结果供 gen_report.py 使用。
"""
import argparse, datetime, json, statistics as st


def load_nodes(path):
    with open(path, "r", encoding="utf-8") as f:
        d = json.load(f)
    if isinstance(d, list):
        nodes = d
    elif isinstance(d, dict) and "nodes" in d:
        nodes = d["nodes"]
    elif isinstance(d, dict) and "data" in d and isinstance(d["data"], dict):
        nodes = d["data"]["nodes"]
    elif isinstance(d, dict) and "data" in d and isinstance(d["data"], list):
        nodes = d["data"]
    else:
        raise ValueError("无法识别的 K 线文件格式: %s" % path)
    nodes = sorted(nodes, key=lambda x: x["date"])

    def g(n, *keys):
        for k in keys:
            if k in n and n[k] is not None:
                return float(n[k])
        return 0.0

    out = []
    for n in nodes:
        out.append({
            "date": n["date"],
            "open": g(n, "open"),
            "close": g(n, "last", "close"),
            "high": g(n, "high"),
            "low": g(n, "low"),
            "amount": g(n, "amount", "turnover"),
            "volume": g(n, "volume"),
        })
    return out


def ma(series, n, i=None):
    """n 日均线；i 为下标，默认取最后一根。数据不足返回 None。"""
    if i is None:
        i = len(series) - 1
    if i + 1 < n:
        return None
    return sum(series[i - n + 1:i + 1]) / n


def wd(s):
    return datetime.date(int(s[:4]), int(s[5:7]), int(s[8:10])).weekday()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kline", required=True, help="K 线 JSON 路径")
    ap.add_argument("--ma", type=int, default=60, help="缠斗统计所用均线窗口，默认 60")
    ap.add_argument("--json", dest="json_out", default=None, help="结构化统计落盘路径")
    args = ap.parse_args()

    nodes = load_nodes(args.kline)
    dates = [n["date"] for n in nodes]
    close = [n["close"] for n in nodes]
    high = [n["high"] for n in nodes]
    low = [n["low"] for n in nodes]
    op = [n["open"] for n in nodes]
    amt = [n["amount"] for n in nodes]
    N = len(close)
    C = close[-1]
    W = args.ma

    print("样本区间: %s ~ %s  共 %d 根日K   最新收盘 %.2f" % (dates[0], dates[-1], N, C))

    # ---------- 1. 均线体系 ----------
    print("\n=== 1. 均线体系（截至 %s）===" % dates[-1])
    ma_map = {}
    for n in (5, 10, 20, 30, 60, 120, 250):
        v = ma(close, n)
        if v is None:
            continue
        ma_map[str(n)] = round(v, 4)
        dev = (C / v - 1) * 100
        tag = "支撑" if C > v else "压力"
        print("  MA%-4d = %8.2f   偏离 %+7.2f 点 (%+.2f%%)  %s" % (n, v, C - v, dev, tag))

    # ---------- 2. 波动率 ----------
    print("\n=== 2. 日收益率波动率与次日区间 ===")
    rets = [(close[i] / close[i - 1] - 1) * 100 for i in range(1, N)]
    vol = {}
    for w in (20, 60, 120, 250):
        if len(rets) < w:
            continue
        seg = rets[-w:]
        sd, mu = st.pstdev(seg), st.mean(seg)
        vol["sigma%d" % w] = round(sd, 4)
        vol["mu%d" % w] = round(mu, 4)
        print("  近%3d日: 日均 %+.3f%%  σ=%.3f%%  → ±1σ %8.0f ~ %-8.0f (±2σ %8.0f ~ %-8.0f)"
              % (w, mu, sd, C * (1 - sd / 100), C * (1 + sd / 100),
                 C * (1 - 2 * sd / 100), C * (1 + 2 * sd / 100)))
    sd_main = vol.get("sigma20") or vol.get("sigma60")
    r1 = [round(C * (1 - sd_main / 100), 1), round(C * (1 + sd_main / 100), 1)]
    r2 = [round(C * (1 - 2 * sd_main / 100), 1), round(C * (1 + 2 * sd_main / 100), 1)]
    print("\n  主口径 σ=%.3f%%  → ±1σ 区间 %.0f ~ %.0f（约68%%概率）" % (sd_main, r1[0], r1[1]))
    vol["range1s"], vol["range2s"], vol["main_sigma"] = r1, r2, sd_main

    # ---------- 3. ATR / 振幅 ----------
    print("\n=== 3. ATR 与日内振幅 ===")
    tr = [max(high[i] - low[i], abs(high[i] - close[i - 1]), abs(low[i] - close[i - 1]))
          for i in range(1, N)]
    atr14 = sum(tr[-14:]) / 14
    atr20 = sum(tr[-20:]) / 20
    amp20 = [(high[i] - low[i]) / close[i - 1] * 100 for i in range(N - 20, N)]
    amp_today = (high[-1] - low[-1]) / close[-2] * 100
    print("  ATR14 = %.2f 点 (%.2f%%)   ATR20 = %.2f 点 (%.2f%%)" %
          (atr14, atr14 / C * 100, atr20, atr20 / C * 100))
    print("  近20日平均振幅 %.2f%%（约 %.0f 点）   当日振幅 %.2f%%（%.0f 点）"
          % (st.mean(amp20), C * st.mean(amp20) / 100, amp_today, high[-1] - low[-1]))
    vol.update({"atr14": round(atr14, 2), "atr20": round(atr20, 2),
                "amp20": round(st.mean(amp20), 3), "amp_today": round(amp_today, 3)})

    # ---------- 4. 形态回测 ----------
    def dist(nx):
        if not nx:
            return None
        up = sum(1 for x in nx if x > 0)
        return {"n": len(nx), "up_rate": round(up / len(nx) * 100, 1),
                "mean": round(st.mean(nx), 3), "median": round(st.median(nx), 3),
                "max": round(max(nx), 2), "min": round(min(nx), 2)}

    print("\n=== 4. 形态回测 ===")
    patterns = []

    # A. 盘中上穿 MA{W}、收盘失守且收阴
    hits = []
    for i in range(W, N - 1):
        m = ma(close, W, i)
        if m is None:
            continue
        if high[i] > m and close[i] < m and close[i] < op[i]:
            hits.append((close[i + 1] / close[i] - 1) * 100)
    d = dist(hits)
    if d:
        d["name"] = "盘中上穿 MA%d、收盘失守且收阴" % W
        d["weight"] = "样本偏小" if d["n"] < 20 else "参考"
        patterns.append(d)
        print("  A. %s: n=%d 上涨%d%% 均值%+.3f%% 中位%+.3f%%"
              % (d["name"], d["n"], d["up_rate"], d["mean"], d["median"]))

    # B. 前日涨超1% 且当日高开低走收阴
    hits = []
    for i in range(2, N - 1):
        if (close[i - 1] / close[i - 2] - 1) * 100 > 1.0 and op[i] > close[i - 1] \
                and close[i] < op[i] and close[i] < close[i - 1]:
            hits.append((close[i + 1] / close[i] - 1) * 100)
    d = dist(hits)
    if d:
        d["name"] = "前日涨超1%后高开低走收阴"
        d["weight"] = "样本很小" if d["n"] < 10 else "参考"
        patterns.append(d)
        print("  B. %s: n=%d 上涨%d%% 均值%+.3f%% 中位%+.3f%%"
              % (d["name"], d["n"], d["up_rate"], d["mean"], d["median"]))

    # C. 收盘价贴近 MA{W}（±0.5%）
    hits = []
    for i in range(W, N - 1):
        m = ma(close, W, i)
        if m is None:
            continue
        if abs((close[i] / m - 1) * 100) <= 0.5:
            hits.append((close[i + 1] / close[i] - 1) * 100)
    d = dist(hits)
    if d:
        d["name"] = "收盘贴近 MA%d（偏离±0.5%%内）" % W
        d["weight"] = "参考"
        patterns.append(d)
        print("  C. %s: n=%d 上涨%d%% 均值%+.3f%% 中位%+.3f%%"
              % (d["name"], d["n"], d["up_rate"], d["mean"], d["median"]))

    # D. 星期效应（严格：星期X 的下一交易日确实是星期Y）
    print("\n=== 5. 星期效应（严格匹配下一交易日，近3年）===")
    names = ["周一", "周二", "周三", "周四", "周五"]
    buck = {i: [] for i in range(5)}
    for i in range(max(1, N - 250), N - 1):
        try:
            w0, w1 = wd(dates[i]), wd(dates[i + 1])
        except Exception:
            continue
        if w0 < 5 and (w0 + 1) % 7 == w1:
            buck[w0].append((close[i + 1] / close[i] - 1) * 100)
    weekday = {}
    for w0 in range(5):
        v = buck[w0]
        if not v:
            continue
        r = dist(v)
        r["name"] = "%s → %s" % (names[w0], names[(w0 + 1) % 7])
        weekday[names[w0]] = r
        print("  %s: n=%3d 上涨%3d%% 均值%+.3f%% 中位%+.3f%%"
              % (r["name"], r["n"], r["up_rate"], r["mean"], r["median"]))

    # 主锚点：当前交易日星期 → 下一交易日
    try:
        cur_w = wd(dates[-1])
        cur_name = names[cur_w]
        if cur_name in weekday:
            anchor = dict(weekday[cur_name])
            anchor["weight"] = "主锚点"
            patterns.append(anchor)
            print("\n  >> 主锚点（%s）：上涨概率 %.0f%%，均值 %+.3f%%，中位 %+.3f%%"
                  % (anchor["name"], anchor["up_rate"], anchor["mean"], anchor["median"]))
    except Exception:
        pass

    # E. 月末最后交易日 → 次月首个交易日
    print("\n=== 6. 月末效应（近3年）===")
    eom = []
    for i in range(max(1, N - 250), N - 1):
        try:
            c0 = datetime.date(int(dates[i][:4]), int(dates[i][5:7]), int(dates[i][8:10]))
            c1 = datetime.date(int(dates[i + 1][:4]), int(dates[i + 1][5:7]), int(dates[i + 1][8:10]))
        except Exception:
            continue
        if c1.month != c0.month:
            eom.append((close[i + 1] / close[i] - 1) * 100)
    eom_r = dist(eom)
    if eom_r:
        eom_r["name"] = "月末最后交易日 → 次月首个交易日"
        print("  n=%d 上涨%.0f%% 均值%+.3f%% 中位%+.3f%%"
              % (eom_r["n"], eom_r["up_rate"], eom_r["mean"], eom_r["median"]))

    # ---------- 7. 关键点位 ----------
    print("\n=== 7. 关键点位 ===")
    def hi(w):
        return max(high[N - w:])
    def lo(w):
        return min(low[N - w:])
    levels = {"h20": hi(20), "l20": lo(20), "h60": hi(60), "l60": lo(60),
              "h10": hi(10), "l10": lo(10)}
    for k in ("h10", "l10", "h20", "l20", "h60", "l60"):
        levels[k] = round(levels[k], 2)
    print("  近10日 %.2f / %.2f   近20日 %.2f / %.2f   近60日 %.2f / %.2f"
          % (levels["h10"], levels["l10"], levels["h20"], levels["l20"],
             levels["h60"], levels["l60"]))
    step = max(5, round(C * 0.00125))
    buckets = {}
    for i in range(max(0, N - 120), N):
        b = int(close[i] // step) * step
        buckets[b] = buckets.get(b, 0) + 1
    clusters = [[b, b + step, c] for b, c in
                sorted(buckets.items(), key=lambda x: -x[1])[:8]]
    levels["clusters"] = clusters
    print("  近120日收盘密集成交区（前5档）：")
    for b, e, c in clusters[:5]:
        print("    %d ~ %d : %d 个交易日" % (b, e, c))

    # ---------- 8. 量能 ----------
    print("\n=== 8. 量能对比 ===")
    volume = {}
    if amt[-1] > 0:
        avgs = {}
        for w in (5, 10, 20, 60):
            if N >= w:
                avgs[w] = sum(amt[-w:]) / w
        volume["today_yi"] = round(amt[-1] / 1e8, 1)
        for w, v in avgs.items():
            volume["a%d" % w] = round(v / 1e8, 1)
            volume["r%d" % w] = round(amt[-1] / v * 100, 1)
            print("  /%3d日均 %8.1f 亿 = %.1f%%" % (w, v / 1e8, amt[-1] / v * 100))

    # ---------- 9. 近期节奏 ----------
    print("\n=== 9. 最近 12 个交易日节奏 ===")
    recent = []
    for i in range(max(1, N - 12), N):
        chg = (close[i] / close[i - 1] - 1) * 100
        recent.append({"date": dates[i], "open": round(op[i], 2), "high": round(high[i], 2),
                       "low": round(low[i], 2), "close": round(close[i], 2),
                       "chg": round(chg, 2), "amt": round(amt[i] / 1e8, 1) if amt[i] else 0})
        print("  %s 开%8.2f 高%8.2f 低%8.2f 收%8.2f %+6.2f%% 额%7.1f亿"
              % (dates[i], op[i], high[i], low[i], close[i], chg,
                 amt[i] / 1e8 if amt[i] else 0))

    # ---------- 10. MA{W} 缠斗序列 ----------
    print("\n=== 10. 近期收盘 vs MA%d ===" % W)
    series = []
    for i in range(max(W, N - 15), N):
        m = ma(close, W, i)
        if m is None:
            continue
        dev = (close[i] / m - 1) * 100
        series.append({"date": dates[i], "close": round(close[i], 2),
                       "ma": round(m, 2), "dev": round(dev, 2), "above": close[i] > m})
        print("  %s 收%8.2f MA%d=%8.2f 偏离%+6.2f%% %s"
              % (dates[i], close[i], W, m, dev, "站上" if close[i] > m else "失守"))
    dev_now = series[-1]["dev"] if series else None
    print("\n  当前偏离 MA%d = %+.2f%%" % (W, dev_now))

    # ---------- 情景点位 ----------
    print("\n=== 11. 情景点位（以现价 %.2f 为基准）===" % C)
    scen = {}
    for lb, p in [("强压力", 2.0), ("第一压力", 0.9), ("中枢", 0.0),
                  ("第一支撑", -0.9), ("强支撑", -2.0)]:
        scen[lb] = round(C * (1 + p / 100), 1)
        print("  %-8s %+.2f%% → %8.1f" % (lb, p, scen[lb]))

    if args.json_out:
        stats = {"meta": {"first": dates[0], "last": dates[-1], "bars": N,
                          "close": round(C, 2), "ma_window": W},
                 "ma": ma_map, "vol": vol, "patterns": patterns, "weekday": weekday,
                 "eom": eom_r, "levels": levels, "volume": volume,
                 "recent": recent, "ma_series": series, "scen": scen}
        with open(args.json_out, "w", encoding="utf-8") as f:
            json.dump(stats, f, ensure_ascii=False, indent=1)
        print("\n>>> 结构化统计已写入 %s" % args.json_out)


if __name__ == "__main__":
    main()
