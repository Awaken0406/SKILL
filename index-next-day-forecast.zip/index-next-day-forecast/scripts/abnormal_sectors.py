#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""异动板块扫描器（概念 / 题材为主，兼容申万一级）

与 sector_strength.py 的分工：
  - sector_strength.py = 「中期强弱排名」：申万一级，5/10 日窗口，涨幅 + 资金双维度分位。
  - abnormal_sectors.py = 「当日异动扫描」：找出**偏离常态**的板块（概念/题材为主），
    回答"今天哪些板块出了动静、动静成不成立、动了几天"。
两者互补：强度排名看谁跑得远，异动扫描看谁今天突然发力。

数据来源约定（由调用方先落盘成 JSON）：
  1) rows    data_sector(mode=ranking, kind=concept, limit=1000)
             -> [{code,name,changePct,turnover,turnoverRate,upCount,
                  mainInflow,mainOutflow,mainNetInflow,mainNetInflow5d,mainNetInflow20d,
                  leader:{code,name,changePct}}]
     kind=industry 时返回的是细分行业，同样可用。
  2) dist    data_changedist()（可选）-> 全市场涨跌家数 / 涨跌停 / 成交额，给异动一个市场背景。
  3) klines  data_kline(code=ptXXXXXXXX, period=day, limit>=11)（可选，只需给候选板块）
             -> 追加 5/10 日涨幅与"已连续异动天数"（连涨/连跌）。

核心口径（写报告时必须照此表述，别自己换说法）：
  - **超额涨跌** = 板块当日涨跌 − 全样本板块涨跌中位数。普涨日里涨 1% 不算异动，
    跌市里涨 1% 才是异动；用中位数而非均值，避免少数极端值抬高基准。
  - **资金强度** = 当日主力净流入 ÷ 当日成交额（%）。比值而非绝对额，
    否则大盘股扎堆的板块（如次新股）永远排在最前，失去信息量。
  - **内部一致性** = 板块上涨家数 / 成分股家数。3 只成分股的板块涨 8% 是噪声不是异动，
    故设 min_members 硬门槛。**领涨股大涨但多数成分股下跌 = 龙头独舞，判定降级为"伪异动"。**
  - **反转 / 背离**：把 5 日主力净流入（趋势资金）与当日净流入（边际资金）对比，
    方向相反即为资金掉头；把涨跌方向与当日资金方向对比，不一致即为价量背离。

用法：
  python abnormal_sectors.py --input pulse_raw.json --out pulse.json [--top 6] \
      [--min-members 5] [--min-amount 20]
"""
import argparse
import io
import json
import re

YI = 10000.0          # 接口资金与成交额单位为万元 -> 亿元

# 「标签类 / 宽基类」概念：只是同名聚合，不是产业链题材，出现在异动榜里没有信息量，默认排除。
# 典型：转融券标的（2812/3528 家）、昨日连板、融资融券、MSCI 中国 A 股、破净股、次新股……
NOISE_KW = ("昨日", "上周", "本月", "年内", "融资融券", "转融券", "深股通", "沪股通",
            "标普", "msci", "富时", "罗素", "上证", "中证", "深证", "沪深300",
            "创业板综", "大盘股", "中盘股", "小盘股", "微盘股", "白马", "蓝筹",
            "股权激励", "股权分散", "回购", "增持", "减持",
            "预增", "预减", "高送转", "次新", "新股", "破净", "低价股", "高价股",
            "绩优", "st股", "养老金", "社保", "基金重仓", "qfii", "机构重仓",
            "信托重仓", "券商重仓", "保险重仓", "连板", "首板", "打板",
            "百日新高", "高贝塔")

TREND_MIN = 0.5       # 资金"反转"榜的趋势资金门槛（亿元）：低于此值属噪声，不判定掉头


def is_noise(name, extra=()):
    n = str(name).lower()
    return any(k in n for k in tuple(NOISE_KW) + tuple(extra))


# ---------------- 工具 ----------------
def num(v, d=0.0):
    try:
        if v is None:
            return d
        return float(v)
    except Exception:
        return d


def parse_counts(s):
    """upCount 形如 '88/91' -> (88, 91)。解析不了返回 (None, None)。"""
    try:
        a, b = str(s).split("/")
        return int(a), int(b)
    except Exception:
        return None, None


def pct_rank(values):
    """每个元素在序列中的分位（0~100，越大越强），并列取平均名次。"""
    n = len(values)
    if n == 0:
        return []
    order = sorted(range(n), key=lambda i: values[i])
    ranks = [0.0] * n
    i = 0
    while i < n:
        j = i
        while j + 1 < n and values[order[j + 1]] == values[order[i]]:
            j += 1
        avg = (i + j) / 2.0
        for k in range(i, j + 1):
            ranks[order[k]] = avg
        i = j + 1
    if n > 1:
        return [r * 100.0 / (n - 1) for r in ranks]
    return [100.0] * n


def chg_of(closes, win):
    if not closes or len(closes) < win + 1:
        return None
    base = closes[-(win + 1)]
    if not base:
        return None
    return (closes[-1] / base - 1.0) * 100.0


def streak(closes):
    """收盘序列（升序）末尾连续同向天数：正=连涨天数，负=连跌天数。"""
    if len(closes) < 2:
        return 0
    n = len(closes)
    step = 1 if closes[-1] >= closes[-2] else -1
    i = n - 1
    cnt = 0
    while i >= 1 and ((closes[i] >= closes[i - 1]) if step > 0 else (closes[i] <= closes[i - 1])):
        cnt += 1
        i -= 1
    return cnt * step


def fmt_signed(v, unit="", nd=2):
    return "%+.*f%s" % (nd, v, unit)


HEAD = ["板块", "涨跌", "换手%", "主力净流入(亿)", "资金强度%", "上涨家数", "领涨股", "判定"]


def row_of(r, with_extra=False):
    why = r.get("why", "")
    if with_extra:
        extra = []
        if r.get("chg5") is not None:
            extra.append("5日%+.2f%%" % r["chg5"])
        if r.get("chg10") is not None:
            extra.append("10日%+.2f%%" % r["chg10"])
        if r.get("streak"):
            extra.append("连%s%d日" % ("涨" if r["streak"] > 0 else "跌", abs(r["streak"])))
        if extra:
            why = "%s（%s）" % (why, "、".join(extra))
    return [r["name"],
            fmt_signed(r["chg"], "%"),
            "%.2f" % r["tr"],
            fmt_signed(r["net1"]),
            fmt_signed(r["intensity"], "", 2),
            r["cnt"],
            r["leader"],
            why]


# ---------------- 主计算 ----------------
def build(raw, top_n=6, min_members=5, min_amount=20.0, max_members=200):
    rows = raw.get("rows") or []
    klines = raw.get("klines") or {}
    dist = raw.get("dist") or {}
    kw_extra = tuple(raw.get("noise_kw_extra") or ())

    recs, warn = [], []
    n_noise = n_broad = 0
    for r in rows:
        code = str(r.get("code", "") or "")
        name = r.get("name") or code
        if not code:
            continue
        up_n, tot_n = parse_counts(r.get("upCount"))
        amt = num(r.get("turnover")) / YI                       # 亿元
        if tot_n is not None and tot_n < min_members:
            continue                                            # 成分股太少：噪声板块
        if tot_n is not None and max_members and tot_n > max_members:
            n_broad += 1
            continue                                            # 成分股太多：宽标签，不是题材
        if not raw.get("keep_noise") and is_noise(name, kw_extra):
            n_noise += 1
            continue                                            # 标签类 / 宽基类概念
        if amt < min_amount:
            continue                                            # 成交额太小：不构成"异动"的市场意义
        net1 = num(r.get("mainNetInflow")) / YI
        leader = r.get("leader") or {}
        recs.append({
            "code": code, "name": name,
            "chg": num(r.get("changePct")),
            "amt": amt,
            "tr": num(r.get("turnoverRate")),
            "net1": net1,
            "net5": num(r.get("mainNetInflow5d")) / YI,
            "net20": num(r.get("mainNetInflow20d")) / YI,
            "up_n": up_n, "tot_n": tot_n,
            "intensity": (net1 / amt * 100.0) if amt else 0.0,
            "ld_code": str(leader.get("code", "") or ""),
            "ld_name": leader.get("name", "-"),
            "ld_chg": num(leader.get("changePct")),
        })

    n_valid = len(recs)
    if n_valid < 10:
        warn.append("有效板块仅 %d 个，样本过小，榜单代表性不足（可下调 --min-members / --min-amount）"
                    % n_valid)

    out = {"asof": raw.get("asof", ""), "scope": raw.get("scope", "concept"),
           "n_input": len(rows), "n_valid": n_valid,
           "n_excluded": {"noise": n_noise, "too_broad": n_broad},
           "filters": {"min_members": min_members, "max_members": max_members,
                       "min_amount": min_amount, "trend_min": TREND_MIN},
           "lists": {}, "warnings": warn}

    if not recs:
        out["hint"] = "无有效板块数据，异动模块留空。"
        return out

    # 1) 全样本基准 + 各维度分位
    chgs = [r["chg"] for r in recs]
    med = sorted(chgs)[len(chgs) // 2] if len(chgs) % 2 else \
        (sorted(chgs)[len(chgs) // 2 - 1] + sorted(chgs)[len(chgs) // 2]) / 2.0
    for r in recs:
        r["excess"] = r["chg"] - med
        r["breadth"] = (r["up_n"] / r["tot_n"] * 100.0) if (r["up_n"] is not None and r["tot_n"]) else None

    p_ex = pct_rank([r["excess"] for r in recs])
    p_net = pct_rank([r["net1"] for r in recs])
    p_int = pct_rank([r["intensity"] for r in recs])
    p_tr = pct_rank([r["tr"] for r in recs])
    p_br = pct_rank([r["breadth"] if r["breadth"] is not None else 50.0 for r in recs])
    for i, r in enumerate(recs):
        r["p_ex"], r["p_net"], r["p_int"], r["p_tr"], r["p_br"] = \
            p_ex[i], p_net[i], p_int[i], p_tr[i], p_br[i]
        # 综合异动分（多头侧）：超额涨跌为主，资金强度次之，换手与内部一致性为辅
        r["score_up"] = 0.45 * p_ex[i] + 0.25 * p_int[i] + 0.20 * p_tr[i] + 0.10 * p_br[i]
        # 空头侧：取反向分位；换手率仍取正向（放量杀跌同样是异动）
        r["score_dn"] = 0.45 * (100 - p_ex[i]) + 0.25 * (100 - p_int[i]) \
            + 0.20 * p_tr[i] + 0.10 * (100 - p_br[i])

    # 2) K 线加成（可选）：5/10 日涨幅 + 连续同向天数
    for r in recs:
        nodes = klines.get(r["code"]) or []
        nodes = sorted(nodes, key=lambda x: str(x.get("date", "")))
        closes = [num(n.get("last")) for n in nodes if n.get("last") is not None]
        if len(closes) >= 6:
            r["chg5"] = chg_of(closes, 5)
            r["chg10"] = chg_of(closes, 10)
            r["streak"] = streak(closes)
        else:
            r["chg5"] = r["chg10"] = None
            r["streak"] = 0

    # 「C+汉字」= 上市未满 5 日的新股，「-U」= 未盈利科创标的：涨跌幅口径与常股不同，
    # 由它们领涨的板块数据是失真的，必须显式标注。
    NEWCOMER = re.compile(r"^C[\u4e00-\u9fa5]|-U")

    def cnt_str(r):
        return "%s/%s" % (r["up_n"], r["tot_n"]) if r["tot_n"] else "—"

    def leader_str(r):
        if r["ld_name"] == "-":
            return "—"
        tag = "（新股/未盈利）" if NEWCOMER.search(str(r["ld_name"])) else ""
        return "%s %+.2f%%%s" % (r["ld_name"], r["ld_chg"], tag)

    for r in recs:
        r["cnt"] = cnt_str(r)
        r["leader"] = leader_str(r)
        r["is_newcomer"] = bool(NEWCOMER.search(str(r["ld_name"])))

    # 3) 榜单
    def row(r, why):
        """每个榜单用 dict 副本带自己的判定理由——同一板块常同时命中多个信号，
        共用 dict 会让后写的理由覆盖先写的（模拟芯片曾因此在撤离榜里显示成"价涨钱出"）。"""
        rr = dict(r)
        rr["why"] = why
        return row_of(rr, True)

    def fold(items):
        """同一领涨股的多个概念板块只保留最高分之一，其余折叠提示。
        概念板块天然高度重叠（半导体 / 汽车芯片 / 大硅片 / CPU概念 往往由同一只龙头带动），
        不折叠的话 TOP6 看着像 6 个方向，实际可能只有 1~2 条链。"""
        keep, folded = [], []
        seen = {}
        for r in items:
            k = r.get("ld_code") or r["name"]
            if k in seen:
                folded.append((r["name"], seen[k]["name"]))
                continue
            seen[k] = r
            keep.append(r)
        return keep, folded

    def _tags_join(tags):
        return "；" + "、".join(tags) if tags else ""

    # (a) 强势异动
    ups, up_fold = fold(sorted(recs, key=lambda r: -r["score_up"])[:max(top_n * 3, top_n)])
    ups = ups[:top_n]
    up_rows = []
    for r in ups:
        tags = []
        if r["excess"] >= 3:
            tags.append("超额 %.1fpct" % r["excess"])
        if r["p_int"] >= 75:
            tags.append("资金强度居前")
        if r["breadth"] is not None and r["breadth"] >= 70:
            tags.append("内部普涨")
        elif r["breadth"] is not None and r["breadth"] <= 40:
            tags.append("⚠龙头独舞，多数成分股未跟涨")
        if r["net1"] < 0:
            tags.append("⚠价涨钱出，主力反而净流出")
        if r["is_newcomer"]:
            tags.append("⚠领涨股为新股，读数失真")
        up_rows.append(row(r, "涨幅居前" + _tags_join(tags)))

    # (b) 杀跌异动
    dns, dn_fold = fold(sorted(recs, key=lambda r: -r["score_dn"])[:max(top_n * 3, top_n)])
    dns = dns[:top_n]
    dn_rows = []
    for r in dns:
        tags = []
        if r["excess"] <= -3:
            tags.append("跑输板块中位数 %.1fpct" % abs(r["excess"]))
        if r["p_int"] <= 25:
            tags.append("资金强度垫底")
        if r["net1"] < 0:
            tags.append("主力净流出 %.2f 亿" % abs(r["net1"]))
        else:
            tags.append("⚠跌但资金净流入，或有承接")
        dn_rows.append(row(r, "跌幅居前" + _tags_join(tags)))

    # (c) 资金反转（趋势资金与边际资金方向相反）—— 两侧都要求跨过 TREND_MIN 门槛，
    #     否则 0.07 亿的噪声流出也能被算成"掉头"，榜首全是无意义的小体量板块。
    tin_pool = [r for r in recs if r["net5"] <= -TREND_MIN and r["net1"] >= TREND_MIN]
    tin_pool.sort(key=lambda r: -r["net1"])
    tin, tin_fold = fold(tin_pool[:max(top_n * 3, top_n)])
    tin = tin[:top_n]
    tin_rows = [row(r, "5 日净流出 %.2f 亿 → 当日净流入 %.2f 亿，回补 %.1f 倍"
                    % (abs(r["net5"]), r["net1"], abs(r["net1"] / r["net5"])))
                for r in tin]

    tout_pool = [r for r in recs if r["net5"] >= TREND_MIN and r["net1"] <= -TREND_MIN]
    tout_pool.sort(key=lambda r: r["net1"])
    tout, tout_fold = fold(tout_pool[:max(top_n * 3, top_n)])
    tout = tout[:top_n]
    tout_rows = [row(r, "5 日净流入 %.2f 亿 → 当日净流出 %.2f 亿，吐回 %.0f%%"
                     % (r["net5"], abs(r["net1"]), abs(r["net1"] / r["net5"]) * 100))
                 for r in tout]

    # (d) 隐性吸筹：涨跌平淡但资金强度居前
    q_pool = [r for r in recs if abs(r["excess"]) < 1.5 and r["p_int"] >= 80 and r["net1"] > 0]
    q_pool.sort(key=lambda r: -r["intensity"])
    quiet, q_fold = fold(q_pool[:max(top_n * 3, top_n)])
    quiet = quiet[:top_n]
    quiet_rows = [row(r, "超额 %+.1fpct（涨跌平淡）但资金强度居前，疑似低吸；"
                         % r["excess"]
                      + ("内部普涨" if (r["breadth"] or 0) >= 70 else "需次日放量确认"))
                  for r in quiet]

    # (e) 价涨钱出：涨超 3% 但主力净流出
    t_pool = [r for r in recs if r["chg"] >= 3 and r["net1"] < 0]
    t_pool.sort(key=lambda r: -r["chg"])
    trap, t_fold = fold(t_pool[:max(top_n * 3, top_n)])
    trap = trap[:top_n]
    trap_rows = [row(r, "涨 %.2f%% 但主力净流出 %.2f 亿；上涨家数 %s，持续性存疑"
                     % (r["chg"], abs(r["net1"]), r["cnt"])) for r in trap]

    def fold_note(pairs):
        return "；".join("%s 与 %s 由同一只个股带动，已折叠" % (a, b) for a, b in pairs)

    def joined(base, extra):
        return (base + "　" + extra) if extra else base

    if ups:
        out["lists"]["up"] = {"title": "强势异动 TOP%d" % len(ups),
                              "note": joined("综合分 = 超额涨跌 45% + 资金强度 25% + 换手率 20% "
                                             "+ 内部一致性 10%，各维度先转排名分位再加权。",
                                             fold_note(up_fold)),
                              "head": HEAD, "rows": up_rows}
    if dns:
        out["lists"]["dn"] = {"title": "杀跌异动 TOP%d" % len(dns),
                              "note": joined("取各维度的反向分位；换手率仍取正向——放量杀跌同样是异动。",
                                             fold_note(dn_fold)),
                              "head": HEAD, "rows": dn_rows}
    if tin:
        out["lists"]["turn_in"] = {
            "title": "资金反转·流入 TOP%d（5 日流出 → 当日流入）" % len(tin),
            "note": joined("5 日主力净流入代表趋势资金，当日代表边际资金，两者反向即资金掉头；"
                           "两侧均需跨过 %.1f 亿门槛，按当日净流入绝对额排序。" % TREND_MIN,
                           fold_note(tin_fold)),
            "head": HEAD, "rows": tin_rows}
    if tout:
        out["lists"]["turn_out"] = {
            "title": "资金反转·撤离 TOP%d（5 日流入 → 当日流出）" % len(tout),
            "note": joined("趋势资金还在、边际资金已走，多为高位退潮的早期信号，"
                           "不代表板块立刻转弱。", fold_note(tout_fold)),
            "head": HEAD, "rows": tout_rows}
    if quiet:
        out["lists"]["quiet"] = {
            "title": "隐性吸筹 TOP%d（涨跌平淡 + 资金强度居前）" % len(quiet),
            "note": joined("超额涨跌在 ±1.5pct 以内、资金强度分位 ≥80、当日净流入为正。"
                           "这类板块当日不显眼，常是次日接力方向；也可能只是被动承接，"
                           "必须结合次日量能确认。", fold_note(q_fold)),
            "head": HEAD, "rows": quiet_rows}
    if trap:
        out["lists"]["trap"] = {
            "title": "价涨钱出 TOP%d（涨超 3%% 但主力净流出）" % len(trap),
            "note": joined("当日涨幅 ≥3% 而主力资金净流出，属典型价量背离，"
                           "不能作为次日强势延续的依据。", fold_note(t_fold)),
            "head": HEAD, "rows": trap_rows}

    # 4) 市场背景
    # 注意：这里**刻意不输出**各板块成交额 / 资金流的横向加总。
    # 概念板块互相高度重叠（同一只票同属十几个概念），加总会把同一批资金重复计数数百次，
    # 出来的数字（实测 615 个概念加总 4437 亿，而全市场成交额才 2.08 万亿的合理量级看似相近）
    # 极易被误读成"全市场主力净流入"，实际没有任何经济含义。需要全市场口径就用 dist 里的值。
    mk_stat = {
        "n_valid": n_valid,
        "median_chg": round(med, 2),
        "p25_chg": round(sorted(chgs)[int(len(chgs) * 0.25)], 2),
        "p75_chg": round(sorted(chgs)[int(len(chgs) * 0.75)], 2),
        "dispersion": round(sorted(chgs)[int(len(chgs) * 0.75)]
                            - sorted(chgs)[int(len(chgs) * 0.25)], 2),
        "up_share": round(sum(1 for c in chgs if c > 0) * 100.0 / len(chgs), 1),
    }
    if dist:
        mk_stat["dist"] = {
            "up": dist.get("upCount"), "down": dist.get("downCount"),
            "flat": dist.get("flatCount"),
            "up_limit": dist.get("upLimitCount"), "down_limit": dist.get("downLimitCount"),
            "suspension": dist.get("suspensionCount"),
            "comment": dist.get("upRatioComment"),
            "amount_yi": round(num(dist.get("totalAmount")) / 1e8, 0),
            "amount_chg_yi": round(num(dist.get("amountChange")) / 1e8, 0),
        }
    out["market"] = mk_stat

    # 5) 兜底解读（config 未给 pulse.note 时使用）
    d = mk_stat.get("dist") or {}
    parts = []
    parts.append("全样本 %d 个%s板块（过滤后）当日涨跌中位数 %+.2f%%，上涨占比 %.0f%%。"
                 % (n_valid, "概念" if out["scope"] == "concept" else "行业",
                    med, mk_stat["up_share"]))
    if d.get("up_limit") is not None:
        parts.append("全市场涨停 %d 家 / 跌停 %d 家，成交额 %.0f 亿元（较上日 %+.0f 亿元）。"
                     % (d["up_limit"], d["down_limit"], d["amount_yi"], d["amount_chg_yi"]))
    if tin:
        parts.append("资金掉头流入集中在 %s。" % "、".join(r["name"] for r in tin[:3]))
    if tout:
        parts.append("%s 趋势资金仍在但边际资金已撤，留意高位退潮。"
                     % "、".join(r["name"] for r in tout[:3]))
    if trap:
        parts.append("%s 涨超 3%% 但主力净流出，属价涨钱出，次日不宜按强势延续对待。"
                     % "、".join(r["name"] for r in trap[:3]))
    if quiet:
        parts.append("隐性吸筹（涨跌平淡但资金强度居前）观察 %s。"
                     % "、".join(r["name"] for r in quiet[:3]))
    else:
        parts.append("无符合「隐性吸筹」条件的板块。")
    parts.append("口径：资金与成交额接口单位为万元，此处已折算亿元；"
                 "「超额涨跌」为相对全样本板块中位数的偏离，非绝对涨跌幅；"
                 "已排除成分股少于 %d 家、超过 %d 家及标签类（融资融券 / 昨日连板等）板块。"
                 % (min_members, max_members))
    out["hint"] = "".join(parts)
    return out


def print_human(res):
    print("=== 异动板块扫描（%s）　数据截至 %s ===" % (res.get("scope"), res.get("asof")))
    m = res.get("market") or {}
    print("有效板块 %d / 原始 %d　涨跌中位数 %+.2f%%（P25 %+.2f%% / P75 %+.2f%%）　上涨占比 %.0f%%"
          % (res.get("n_valid", 0), res.get("n_input", 0), m.get("median_chg", 0),
             m.get("p25_chg", 0), m.get("p75_chg", 0), m.get("up_share", 0)))
    if m.get("dist"):
        d = m["dist"]
        print("全市场：涨 %s 跌 %s 平 %s，涨停 %s / 跌停 %s，成交额 %.0f 亿（%+.0f 亿）"
              % (d.get("up"), d.get("down"), d.get("flat"), d.get("up_limit"),
                 d.get("down_limit"), d.get("amount_yi"), d.get("amount_chg_yi")))
    for key in ("up", "dn", "turn_in", "turn_out", "quiet", "trap"):
        li = res.get("lists", {}).get(key)
        if not li:
            continue
        print("\n---- %s ----" % li["title"])
        for r in li["rows"]:
            print("  %-12s %8s 换手%7s 净流入%9s亿 强度%8s%% 家数%8s 领涨%-16s %s"
                  % (r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7]))
    for w in res.get("warnings", []):
        print("\n[warn] %s" % w)
    print("\n注：%s" % res.get("hint", ""))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="异动板块数据包 JSON")
    ap.add_argument("--out", help="输出 JSON（可选，默认只打印）")
    ap.add_argument("--top", type=int, default=6, help="每类榜单条数，默认 6")
    ap.add_argument("--min-members", type=int, default=5,
                    help="成分股家数下限，默认 5（低于此值视为噪声板块）")
    ap.add_argument("--min-amount", type=float, default=20.0,
                    help="成交额下限（亿元），默认 20")
    ap.add_argument("--max-members", type=int, default=200,
                    help="成分股家数上限，默认 200（超过者为宽标签板块，如「转融券标的」2800+ 家）")
    ap.add_argument("--keep-noise", action="store_true",
                    help="保留标签类概念板块（昨日连板 / 融资融券 / MSCI 等），默认排除")
    a = ap.parse_args()

    raw = json.load(io.open(a.input, encoding="utf-8"))
    if a.keep_noise:
        raw["keep_noise"] = True
    res = build(raw, a.top, a.min_members, a.min_amount, a.max_members)
    print_human(res)
    if a.out:
        json.dump(res, io.open(a.out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print("\n[已写入] %s" % a.out)


if __name__ == "__main__":
    main()
