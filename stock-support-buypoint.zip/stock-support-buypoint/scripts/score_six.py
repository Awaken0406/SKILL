#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
购买指数六维评分（保守口径）——纯评分脚本，不拉数据。

定位：配合 westock-mcp 使用。每天 data_quote / data_technical / data_kline 拉回的
JSON 原样贴进输入文件，本脚本按《购买指数六维体系（保守口径）》算五个数值维度，
题材分(10)留人工判断（输入里可带 theme.score，缺省 6）。

用法:
    python score_six.py --input score_input.json
    python score_six.py --input score_input.json --out result.md --rsi-window 6
    python score_six.py --input score_input.json --history score_history.jsonl   # 把评分快照追加落库(供回测)

单股场景（stock-support-buypoint）：输入 JSON 顶层可加 "pe_benchmark": <行业PE中枢>，
无候选池中位数可用时以它为估值基准；缺省时单股自身PE即中位数（比值=1 → 中枢档7分）。

估值基准优先级（2026-08-25 增强, 与 stock-support-buypoint 对齐）:
  ① 每只标的自带 "pe_benchmark": <该股行业PE>   ← 逐股指定, scan 场景推荐
  ② 输入 JSON 顶层 "pe_benchmark": <数值>       ← 单股/同行业批量
  ③ 候选池 PE 中位数                              ← 仅兜底, 会误伤低估值池里的题材股

回测落库（--history）：每次运行把每只标的的评分快照(日期/代码/名称/总分/评级/六维分项)追加入
JSONL。backtest.py 读取该文件 + westock 后续K线，算 T+5/10/20 分组收益/胜率/相对基准，验证体系预测力。

输入 JSON 结构（MCP 返回原样粘贴，kline 正序倒序均可）:
{
  "stocks": [
    {
      "code": "sh601088",
      "name": "中国神华",
      "quote":  { ...data_quote 返回的原对象... },
      "tech":   { ...data_technical 返回的原对象(ma/kdj/macd/rsi[/boll])... },
      "kline":  [ ...data_kline 的 nodes 数组(至少65根, 建议120根)... ],
      "theme":  {"score": 6, "note": "煤炭保供+高股息"}   # 可选
    }
  ]
}

评分细则来源: stock-directional-scan/references/scoring.md
规则文本未细化处的确定性插值，全部集中在本文件顶部 CONFIG 区，可调可查。
"""
import argparse
import json
import os
import sys
from datetime import datetime
from statistics import median

# 技术位计算内核（ATR / 摆动点 / 支撑阻力 / 止损 / R:R 档位）—— 与 levels.py 共用同一实现，
# 避免"评分里的止损"和"报告里展示的止损"漂移。详见 ta_core.py 顶部说明。
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ta_core as TA

ATR_WINDOW = TA.ATR_WINDOW
STOP_PCT_FLOOR = TA.STOP_PCT_FLOOR
ATR_MULT = TA.ATR_MULT
STOP_MAX_ATR_FROM_PX = TA.STOP_MAX_ATR_FROM_PX
RESIST_MIN_ATR = TA.RESIST_MIN_ATR
RESIST_BUFFER = TA.RESIST_BUFFER
RESIST_LOOKBACK = TA.RESIST_LOOKBACK
NO_RESIST_ATR_MULT = TA.NO_RESIST_ATR_MULT
RR_BANDS = TA.RR_BANDS
RR_BANDS_OLD = TA.RR_BANDS_OLD

# ============================================================
# CONFIG：规则歧义点的确定性实现（改动前先读注释）
# ============================================================
RSI_WINDOW = "RSI_6"      # 规则未指明 RSI 窗口；默认 RSI_6（短线敏感，保守），可用 --rsi-window 改 RSI_12
STOP_PCT = 0.985          # 【旧口径保留】止损 = 支撑(MA20) 下方 1.5%（规则"支撑下方1-2%"取中值）
TARGET_LOOKBACK = 60      # 【旧口径保留】第一目标 = 近 60 个交易日最高价（仅供对照/兜底）
MA60_SLOPE_DAYS = 5       # MA60 上行 = 今值 > 5 个交易日前的 MA60 值
THEME_DEFAULT = 6         # 题材缺省分（"有题材无事件"档）
VAL_POOL_RATIO = True     # 估值用候选池 PE 中位数作"行业中枢"代理（无行业PE接口时的替代）

# ------------------------------------------------------------
# 【2026-08-29 重构】盈亏比维度（权重15）此前已退化为常数：
# 105 个真实样本中 103 个拿满分(98.1%)，全维度仅 2 种取值。
# 根因: 止损固定为 MA20 下方 1.5%（分母极小） + 目标恒取 60 日最高（分子极大），
#       只要 60 日最高比 MA20 高 4.5% 即满分，几乎所有股票都满足。
# 实测崩盘中的思源电气(R:R=19.6→15分) 与多头豪尔赛(22.1→15分) 同分。
# 本次三项修正:
#   (a) 止损改与波动率挂钩: stop = min(支撑×(1−1.5%), 支撑 − ATR_MULT×ATR14)
#   (b) 目标改"最近实质阻力"替代 60 日最高（由 levels.py 同算法计算）
#   (c) 现价已高于买点时改用现价口径 R:R 计分（此前仅供对照，不参与评分）
# ------------------------------------------------------------
USE_NEW_RR = True         # 置 False 可回到旧口径做 A/B 对照
# 注：ATR_MULT / RESIST_MIN_ATR / RR_BANDS 等已上移到 ta_core.py，此处不再重复定义。
#     参数标定依据见 ta_core.py 顶部注释，以及在生益科技 66 日 walk-forward 上的实测分布。
VAL_NO_BENCH_SCORE = 5    # 【2026-08-29 修正】无估值基准时的兜底分（原恒给7，与估值高低完全无关）
                          #   且必须在报告标注【无法确认】，不再伪装成"中枢档"评价结果
POOL_MIN_N = 5            # 【2026-08-29 二次修正】候选池 PE 中位数生效所需的最少样本数。
                          #   样本不足(尤其单股场景)时池中位数退化为"自己的 PE" → 恒 1.00 倍 → 恒 7 分，
                          #   估值维度失去区分度。此时一律视为基准缺失，走【无法确认】分支。
CHIP_ADJ_MAX = 6          # 筹码结构加减分项上限（正:集中度改善 / 负:散户化预警）

# 题材分锚定规则（2026-08-29 新增）：禁止无依据地落缺省值。
#   10 = 强题材 + 近期(≤30天)明确事件催化（政策/订单/业绩预告/并购）
#    8 = 强题材 + 有催化预期但无确定时点
#    6 = 有题材无事件（缺省值，**必须在 note 中写明具体题材，否则视为未评分**）
#    3 = 纯技术、逻辑模糊
#    0 = 无催化
THEME_ANCHOR = {10: "强题材+≤30天内明确事件催化", 8: "强题材+催化预期无确定时点",
                6: "有题材无事件(缺省)", 3: "纯技术/逻辑模糊", 0: "无催化"}
THEME_NOTE_REQUIRED = ("", "默认:有题材无事件", "有题材无事件")  # 这些 note 视为"未给依据"

# 【规则文本修正①】scoring.md 原文 dist=(支撑−现价)/现价 且 "dist<0 → 已跌破"，
# 两者互相矛盾（支撑在现价下方时 dist 恒为负）。按档位语义修正为:
#   dist = (现价 − 支撑) / 现价   → 现价高于支撑为正（距支撑的距离），
#   dist < 0 表示现价已跌破支撑。
# 档位（|dist|）：≤2% → 20；2–5% → 14；5–8% → 8；>8% → 3
# 跌破(dist<0)插值: >−1% → 3；−1~−3% → 1；≤−3% → 0
POS_BREAK_BANDS = [(-0.01, 3), (-0.03, 1), (None, 0)]

# 【规则文本修正②】"跌破MA5位置分降一档"：20→14→8→3，已至 3 不再降；
# 若同时已跌破支撑（dist<0），直接取 0（最保守）。

# 反转日击穿修正（四条件全部满足才触发）扣分: 基础5 + 跌幅≥5%再扣3 + 换手创20日新高再扣2，封底0
BREAK_BASE, BREAK_DEEP, BREAK_VOL = 5, 3, 2

# 趋势档（保守口径①的确定性插值）:
#   价>MA60 且 MA60上行 且 价>MA20        → 25  干净多头
#   价>MA60 且 MA60上行 但 价≤MA20        → 18  多头但短线走弱
#   价>MA60 且 MA60走平/下行              → 15  反弹/震荡
#   价≤MA60 且 价>MA20                    → 12  反弹/震荡(弱)
#   价≤MA60 且 价≤MA20(未破MA120与MA250)  → 8
#   价<MA120 且 价<MA250                  → 3   空头
TREND_TABLE = "见上注释"

# 【2026-08-29 新增·趋势交叉约束】盈亏比不是独立维度：趋势崩坏时，"支撑"和"阻力"
#   都只是下跌途中的临时驿站，R:R 的分子（目标）和分母（止损）同样不可信。
#   实测反例：思源电气 8/28 崩穿全部均线（趋势 3 分），却因"目标=刚跌穿的MA5(162.38)"
#   和"止损=支撑−1×ATR"算出 R:R=2.03 → 11 分，与趋势/位置（3 分 / 0 分）严重矛盾。
#   约束：趋势分 ≤ 阈值时，盈亏比上限压到 cap。[(趋势分上限, R:R上限)] 按趋势分升序。
RR_TREND_CAPS = [(8, 7), (15, 11)]
#   趋势 ≤8（价≤MA20 或已破长均线）→ R:R 上限 7
#   趋势 ≤15（反弹/震荡，MA60 未上行）→ R:R 上限 11
#   趋势 ≥18（多头）→ 不设限

# 【2026-08-29 新增·位置维度区间分位约束】"距最近支撑多远"单独用会被贴身支撑骗到高分：
#   股价一路阴跌时，最近支撑始终在脚下 1–2%，dist 恒为小正数 → 位置满分，
#   但该股其实处于下跌中继。叠加近 120 日区间分位做交叉校验：
#   分位 > 阈值（贴近区间顶部）说明仍是追高，位置分降一档。
RANGE_POS_HIGH = 0.80
RANGE_POS_MID = 0.60
POS_DEMOTE_ONE = {20: 14, 14: 8, 8: 3, 3: 3, 1: 1, 0: 0}

# 【2026-08-29 新增·位置维度趋势约束】与盈亏比同理：位置分衡量"距支撑多远"，
#   但崩盘股的最近支撑会被不断刷新并紧跟现价（实测思源电气支撑 143.16 = 现价 143.18，
#   dist=+0.0% → "贴支撑≤2%" → 满分档 20，仅因跌破MA5降到 14）。
#   下跌趋势中"贴支撑"不是买点而是下跌中继，故按趋势分设上限。
#   ⚠️ 副作用：六维不再相互独立，趋势的实际权重被放大（趋势→位置+盈亏比两个上限）。
#      这是有意为之：趋势是本体系唯一有稳定方向性证据的维度，让弱趋势压制其他维度
#      比让各维度独立投票更符合"宁可错过、不可做错"的保守定位。
POS_TREND_CAPS = [(8, 8), (15, 14)]

# 动能（基础10, 封顶20, 保底0）:
#   J<20  → +6，仅当 现价≥MA20 且 量比≥1.0（保守口径③: 缩量/资金弱不加）
#   20≤J≤50 → +3；50<J≤90 → 0；J>90 → −6
#   MACD(12,26,9) 自算自K线（2026-08-25 增强, 修正"只看单点红柱"退化）:
#     金叉(DIF上穿DEA) 或 红柱放大(柱今>昨) → +4；死叉(DIF下穿DEA) 或 绿柱放大(柱今<昨<0) → −4
#     否则按柱正负给 ±2（红柱收缩/绿柱收缩）; 缺K线回退用接口MACD单点: >0→+4, <0→−4
#   RSI 30–60 → +3; >80 → −4; <30 → +2
MOM_J_BONUS_VOL_RATIO = 1.0
MACD_SELF_USE = True      # 用K线自算MACD(12,26,9)做金叉/放大判断
MACD_FAST, MACD_SLOW, MACD_SIGNAL = 12, 26, 9

# 【④ 追高修正（2026-08-25 新增, 2026-08-29 保留）】买点口径R:R会奖励"现价已飞离买点"的票
#   (位置分3但盈亏比15), 与"现在值不值得买"的定位冲突。本修正用现价口径风险兜底:
#   现价距买点(MA20)>8% 且 现价口径R:R<1.0 → 总分扣 CHASE_PENALTY(默认4), 明细标注"已远离买点,现价追高风险高"
# 注: 新盈亏比口径(c)已让现价口径参与评分，追高修正仍保留作为叠加惩罚（两者不重复计分，
#     因为 (c) 只决定盈亏比维度取哪个 R:R，追高修正是在总分外额外扣分）。
CHASE_PENALTY = 4
CHASE_DIST = 0.08          # 现价距买点阈值
CHASE_RR_NOW = 1.0         # 现价口径R:R阈值

# 估值（PE_TTM vs 候选池中位数 med, 无行业PE接口, 池中位数作代理）:
#   PE≤0(亏损) → 0; ≤0.7*med → 10; ≤1.0*med → 7; ≤1.5*med → 4; >1.5*med → 0
#   且 chg_10d>40% 且 >1.5*med → 0（透支条款已含）
#   【2026-08-29 修正】缺基准时不再恒给7（PE 8/15/33/80/300 同分），改给
#   VAL_NO_BENCH_SCORE(=5) 并在理由中显式标注【无法确认】。

RATING = [(80, "强烈建议买入"), (65, "建议买入"), (50, "轻仓试探/等回踩"), (35, "观望"), (0, "不建议买入")]

# 【2026-08-29 新增·评级否决规则】六维加权总分是"平均意义上的好坏"，会掩盖单项致命风险：
#   一只趋势满分、盈亏比满分但公司亏损、散户占比 91% 的题材票，总分可以很高，
#   却恰恰是最不该重仓的类型。故在总分评级之上叠加硬性上限。
#   这里刻意用"规则"而非"再次调阈值"：阈值重标定需要回测样本（P2-8，样本 T+20 未到期），
#   而否决规则是可解释的风险约束，不依赖统计标定。
#   (检查名, 评级上限, 触发条件说明)
VETO_ORDER = ["强烈建议买入", "建议买入", "轻仓试探/等回踩", "观望", "不建议买入"]


def apply_vetoes(base_rating, dims, chip_adj, warns, exec_risk=None):
    """按风险约束把评级压到上限。返回 (最终评级, [触发的否决说明])。"""
    cur = base_rating
    hits = []
    trend = dims["trend"][0]
    val = dims["val"][0]

    def tighten(cap, why):
        nonlocal cur
        if VETO_ORDER.index(cap) > VETO_ORDER.index(cur):
            hits.append(f"{why} → 评级上限压到「{cap}」")
            cur = cap

    if trend <= 8:
        tighten("观望", f"趋势{trend}分(价≤MA20或已破MA120/250)，空头排列不建仓")
    if chip_adj <= -4:
        tighten("轻仓试探/等回踩", f"筹码调整{chip_adj}分(散户化预警显著)，筹码结构不支持重仓")
    if val == 0:
        tighten("轻仓试探/等回踩", "估值0分(亏损/无PE)，无基本面估值锚")
    if warns:
        idx = min(VETO_ORDER.index(cur) + 1, len(VETO_ORDER) - 1)
        tighten(VETO_ORDER[idx], f"一致性校验未过({'; '.join(warns)})")
    if exec_risk:
        tighten("轻仓试探/等回踩", f"执行风险：{exec_risk}")
    return cur, hits


def rating_of(total):
    for floor, name in RATING:
        if total >= floor:
            return name
    return RATING[-1][1]


# A股涨跌停幅度（按板块）: 主板10% / 创业板(30x)科创板(688)20% / 北交所(4x,8x)30%
def _limit_pct(code):
    num = "".join(ch for ch in (code or "") if ch.isdigit())[-6:]
    if num.startswith(("30", "68")):
        return 0.20
    if num.startswith(("4", "8")):
        return 0.30
    return 0.10


def exec_risk_of(s):
    """【A股执行风险】跌停封板/涨停封板/一字板时，纸面止损止盈可能根本无法成交。

    返回说明字符串或 None。这是 A 股特有的、必须写进报告的执行约束：
    计划止损位再精确，跌停封板当日也卖不出去。"""
    lim = _limit_pct(s.code)
    if s.prev_close and s.px:
        chg = (s.px - s.prev_close) / s.prev_close
        if chg <= -(lim - 0.003):
            return f"当日跌停({chg:.2%})，封板下止损指令当日无法成交，只能次日处理"
        if chg >= (lim - 0.003):
            return f"当日涨停({chg:.2%})，追高挂单可能无法成交"
    if s.high and s.low and s.high == s.low:
        return "一字板，全天无有效成交区间，无可执行的价格锚"
    return None


# ============================================================
# 数据读取（MCP 原生结构适配）
# ============================================================
class Stock:
    def __init__(self, raw):
        self.code = raw.get("code", "")
        self.name = raw.get("name", self.code)
        q = raw.get("quote", {}) or {}
        t = raw.get("tech", {}) or {}
        ma = t.get("ma", {}) or {}
        self.px = q.get("price") or t.get("closePrice")
        self.high, self.low = q.get("high"), q.get("low")
        self.prev_close = q.get("prev_close")
        self.turnover = q.get("turnover_rate")
        self.vol_ratio = q.get("volume_ratio")
        self.pe = q.get("pe_ratio")
        self.chg_10d = q.get("chg_10d")
        self.pe_benchmark = raw.get("pe_benchmark")  # 该股自己的行业PE基准(逐股指定, 2026-08-25新增)
        self.ma = {k: ma.get(k) for k in ("MA_5", "MA_10", "MA_20", "MA_60", "MA_120", "MA_250")}
        boll = t.get("boll") or {}
        boll_mid = boll.get("BOLL_MID")
        self.boll_mid = boll_mid
        self.boll_upper = boll.get("BOLL_UPPER")
        self.boll_lower = boll.get("BOLL_LOWER")
        self.j = (t.get("kdj") or {}).get("KDJ_J")
        self.macd = (t.get("macd") or {}).get("MACD")
        rsi = t.get("rsi") or {}
        self.rsi = rsi.get(RSI_WINDOW)
        self.theme = raw.get("theme") or {}
        self.chip = raw.get("chip") or {}   # 2026-08-29: 筹码结构(retail_ratio.py 输出)
        self.notes = []
        kl = raw.get("kline") or []
        nodes = []
        if isinstance(kl, list):
            nodes = [n for n in kl if isinstance(n, dict) and "date" in n]
            if kl and not nodes:
                self.notes.append("kline字段非节点数组, 按缺K线处理")
        elif kl:
            self.notes.append("kline字段非数组, 按缺K线处理")
        nodes.sort(key=lambda n: n["date"])
        self.kline = nodes
        self.closes = [float(n["last"]) for n in nodes if n.get("last") is not None]
        if nodes and len(self.closes) < len(nodes):
            self.notes.append(f"{len(nodes)-len(self.closes)}根K线缺last字段")

    @property
    def support(self):
        """最近实质支撑（委托 ta_core，与 levels.py 报告展示值完全同一实现）。

        【2026-08-29 修正】原为 min(MA20, 布林中轨)：
          ① 股价崩穿所有均线时该"支撑"反在现价**上方**，据此算的止损高于现价，R:R 完全失真；
          ② 与 levels.py 报告的脚本化支撑位口径不一致，同一份报告出现两个支撑（思源电气
             评分用 138.10、报告展示 143.16）。
        现改为 ta_core.nearest_support：均线 ∪ 布林下轨 ∪ 摆动低点 ∪ 成交密集区
          ∪ 缺口沿 ∪ 近120日最低，取现价下方最大值。"""
        return TA.nearest_support(self.px, self.ma,
                                  {"upper": self.boll_upper, "lower": self.boll_lower},
                                  self._bars())[0]

    def ma60_slope_up(self):
        """MA60 上行: 今值 > MA60_SLOPE_DAYS 日前的值(自算, 不依赖接口历史)。"""
        n = 60 + MA60_SLOPE_DAYS
        if len(self.closes) < n:
            self.notes.append(f"K线不足{n}根, MA60斜率不可算")
            return None
        today = sum(self.closes[-60:]) / 60
        ago = sum(self.closes[-n:-MA60_SLOPE_DAYS]) / 60
        # 与接口 MA_60 交叉校验
        api = self.ma.get("MA_60")
        if api and abs(today - api) / api > 0.01:
            self.notes.append(f"自算MA60({today:.2f})与接口({api:.2f})偏差>1%")
        return today > ago

    def hh(self, days=TARGET_LOOKBACK):
        """近 days 日最高价(含当日)。"""
        if not self.kline:
            return None
        return max(float(n["high"]) for n in self.kline[-days:])

    # ---- 2026-08-29 新增：波动率与"最近实质阻力"（与 levels.py 同口径）----
    def _bars(self):
        """bars 由 ta_core 统一构造（含 open 缺失时的前收回退），保证与 levels.py 完全一致。"""
        return TA.bars_from_kline(self.kline)

    def atr(self, window=ATR_WINDOW):
        """Wilder 平滑 ATR14（ta_core 实现，与 levels.py 同一份代码）。"""
        return TA.atr_wilder(self._bars(), window)

    def stop_level(self, support):
        """止损（ta_core 实现）。返回 (止损价, 说明)。旧口径为固定的 支撑×0.985。"""
        return TA.stop_from_support(support, self.atr(), self.px)

    def swing_highs(self, lookback=RESIST_LOOKBACK, lr=3):
        return TA.swing_pivots(self._bars(), lr=lr, lookback=lookback)[0]

    def swing_lows(self, lookback=RESIST_LOOKBACK, lr=3):
        return TA.swing_pivots(self._bars(), lr=lr, lookback=lookback)[1]

    def ll(self, days=RESIST_LOOKBACK):
        """近 days 日最低价(含当日)。"""
        if not self.kline:
            return None
        return min(float(n["low"]) for n in self.kline[-days:])

    def nearest_resistance(self):
        """最近且"够远"的实质阻力 → (价格, 依据)。

        候选（ta_core 统一口径）：均线 ∪ 布林上轨 ∪ 摆动高点 ∪ 成交密集区
              ∪ 缺口沿 ∪ 区间高点 ∪ 整数关口
        门槻：须在现价上方 ≥ RESIST_MIN_ATR×ATR，否则视为噪声级障碍、改用 ATR 外推。
        """
        return TA.nearest_resistance(
            self.px, self.ma,
            {"upper": self.boll_upper, "lower": self.boll_lower},
            self._bars(), self.atr())

    def macd_state(self):
        """用K线自算 MACD(12,26,9)，返回 dict(金叉/死叉/红柱放大/绿柱放大/柱正负)。

        确定性实现（EMA 用平滑系数 2/(N+1)，与主流行情软件一致）：
          dif = EMA12 - EMA26；dea = EMA9(dif)；柱 = 2*(dif-dea)（A股口径乘以2）
        返回 None 表示 K线不足无法自算（由调用方回退到接口单点）。
        """
        c = self.closes
        n_req = MACD_SLOW + MACD_SIGNAL + 2
        if len(c) < n_req:
            return None
        ema_f, ema_s, ema_d = [c[0]] * 3
        dif_prev = None
        difs = []
        for i in range(1, len(c)):
            ema_f = ema_f + 2 / (MACD_FAST + 1) * (c[i] - ema_f)
            ema_s = ema_s + 2 / (MACD_SLOW + 1) * (c[i] - ema_s)
            dif = ema_f - ema_s
            difs.append(dif)
        # dea = EMA9(dif)
        dea = difs[0]
        deas = [dea]
        for dif in difs[1:]:
            dea = dea + 2 / (MACD_SIGNAL + 1) * (dif - dea)
            deas.append(dea)
        hist = [2 * (d - e) for d, e in zip(difs, deas)]  # 柱
        if len(hist) < 2:
            return None
        h0, h1 = hist[-1], hist[-2]
        dif0, dif1 = difs[-1], difs[-2]
        dea0, dea1 = deas[-1], deas[-2]
        cross_up = dif1 <= dea1 and dif0 > dea0      # 金叉
        cross_dn = dif1 >= dea1 and dif0 < dea0      # 死叉
        bar_grow = h0 > h1                            # 红柱放大或绿柱收缩
        green_grow = h0 < h1 and h0 < 0 and h1 < 0    # 绿柱放大(更负)
        return {"cross_up": cross_up, "cross_dn": cross_dn,
                "bar_grow": bar_grow, "green_grow": green_grow,
                "bar_pos": h0 > 0}


# ============================================================
# 六维评分
# ============================================================
def score_trend(s):
    px = s.px
    ma60_up = s.ma60_slope_up()
    m60, m20, m120, m250 = (s.ma.get(k) for k in ("MA_60", "MA_20", "MA_120", "MA_250"))
    if m250 and m120 and px < m120 and px < m250:
        return 3, "空头(价<MA120且<MA250)"
    if m60 and px > m60:
        if ma60_up is True:
            if m20 and px > m20:
                return 25, "干净多头(价>上行MA60且价>MA20)"
            return 18, "多头但短线走弱(价>上行MA60, 价≤MA20)"
        return 15, "反弹/震荡(价>MA60但MA60未上行)"
    if m20 and px > m20:
        return 12, "反弹/震荡弱(价≤MA60, 价>MA20)"
    return 8, "价≤MA60且≤MA20(未全破长均线)"


def score_position(s):
    sup = s.support
    if sup is None or s.px is None:
        return 0, "缺MA20/布林中轨"
    dist = (s.px - sup) / s.px
    # 基础档
    if dist < 0:  # 已跌破支撑
        for bound, sc in POS_BREAK_BANDS:
            if bound is None or dist > bound:
                base, why = sc, f"已跌破支撑{dist:.1%}"
                break
    else:
        ad = abs(dist)
        base, why = (20, "贴支撑≤2%") if ad <= 0.02 else \
                    (14, "距支撑2-5%") if ad <= 0.05 else \
                    (8,  "距支撑5-8%") if ad <= 0.08 else (3, "距支撑>8%")
    # 跌破MA5降一档
    ma5 = s.ma.get("MA_5")
    below_ma5 = ma5 is not None and s.px < ma5
    if below_ma5 and dist >= 0:
        base = {20: 14, 14: 8, 8: 3, 3: 3}[base]
        why += "; 跌破MA5降一档"
    elif below_ma5 and dist < 0:
        base = 0
        why += "; 跌破MA5且已破支撑, 取0"
    # 【区间分位约束】光看"距最近支撑多远"会被贴身支撑骗到高分：
    #   阴跌途中最近支撑始终在脚下 1–2%，dist 恒为小正数 → 位置满分，实为下跌中继。
    #   叠加近120日区间分位：贴近区间顶部说明仍是追高，降一档。
    pos, pos_why = TA.range_position(s.px, s._bars())
    if pos is not None and pos > RANGE_POS_HIGH:
        base = POS_DEMOTE_ONE.get(base, base)
        why += f"; 区间分位{pos:.0%}>{RANGE_POS_HIGH:.0%}(追高)降一档"
    # 【趋势约束】下跌趋势中"贴支撑"是下跌中继而非买点，按趋势分设上限
    tr, tr_why = score_trend(s)
    for tr_max, cap in POS_TREND_CAPS:
        if tr <= tr_max:
            if base > cap:
                why += f"; 趋势{tr}({tr_why})下 {base}→{cap}分封顶"
                base = cap
            break
    # 反转日击穿修正
    pen = reversal_break_penalty(s)
    if pen:
        why += f"; 反转日击穿扣{pen}"
    if pos is not None:
        why += f"; {pos_why}"
    return max(0, base - pen), f"{why}(支撑{sup:.2f}, dist={dist:+.1%})"


def reversal_break_penalty(s):
    """四条件: 跌幅≥3%收阴 / 换手>10%或创20日高 / 收盘贴最低≤1.02 / 收盘破MA5且盘中击穿MA20或MA60或布林中轨。"""
    if s.prev_close is None or s.px is None:
        return 0
    chg = (s.px - s.prev_close) / s.prev_close
    cond_a = chg <= -0.03
    if not cond_a:
        return 0
    if s.turnover is not None:
        hi20 = None
        if s.kline:
            hist = [float(n["exchange"]) for n in s.kline[-21:-1] if n.get("exchange") is not None]
            hi20 = max(hist) if hist else None
        cond_b = s.turnover > 10 or (hi20 is not None and s.turnover > hi20)
    else:
        cond_b = False
    cond_c = s.low and s.px / s.low <= 1.02
    ma5 = s.ma.get("MA_5")
    intr = [m for m in (s.ma.get("MA_20"), s.ma.get("MA_60"), s.boll_mid) if m]
    cond_d = ma5 is not None and s.px < ma5 and any(s.low < m for m in intr)
    if not (cond_a and cond_b and cond_c and cond_d):
        return 0
    pen = BREAK_BASE + (BREAK_DEEP if chg <= -0.05 else 0) + (BREAK_VOL if cond_b else 0)
    return pen


def score_momentum(s):
    v = 10
    if s.j is not None:
        if s.j < 20:
            ok = (s.ma.get("MA_20") is None or s.px >= s.ma["MA_20"]) and \
                 (s.vol_ratio is None or s.vol_ratio >= MOM_J_BONUS_VOL_RATIO)
            if ok:
                v += 6  # 超卖+站稳MA20+量能未缩
        elif s.j <= 50:
            v += 3
        elif s.j > 90:
            v -= 6
    # MACD 动能（2026-08-25 增强: 优先K线自算金叉/放大）
    if MACD_SELF_USE:
        st = s.macd_state()
        if st is None:
            # 回退: 接口单点
            if s.macd is not None:
                v += 4 if s.macd > 0 else -4
        else:
            if st["cross_up"] or st["bar_grow"]:
                v += 4
            elif st["cross_dn"] or st["green_grow"]:
                v -= 4
            else:
                v += 2 if st["bar_pos"] else -2
    elif s.macd is not None:
        v += 4 if s.macd > 0 else -4
    if s.rsi is not None:
        if 30 <= s.rsi <= 60:
            v += 3
        elif s.rsi > 80:
            v -= 4
        elif s.rsi < 30:
            v += 2
    return max(0, min(20, v)), ""


def nearest_support_below(s):
    """现价下方最近的实质支撑 → (价格, 依据)。委托 ta_core，与 levels.py 完全同一实现。

    为什么不能继续用 min(MA20, 布林中轨)：
      旧口径在"股价已崩穿所有均线"时（如思源电气 8/28 跌破 MA5/10/20/60/120/250）
      得到的支撑反而在现价**上方**，据此算出的止损价高于现价，R:R 分母为负、完全失真。
    候选集（ta_core）：均线 ∪ 布林下轨 ∪ 摆动低点 ∪ 成交密集区 ∪ 缺口沿
                      ∪ 近120日最低 ∪ 整数关口，取现价下方**最大**者。"""
    if s.px is None:
        return None, "缺现价"
    return TA.nearest_support(
        s.px, s.ma, {"upper": s.boll_upper, "lower": s.boll_lower}, s._bars())


def rr_score(rr, bands=RR_BANDS):
    """R:R → 分值（委托 ta_core，单一真值源）。"""
    return TA.rr_score(rr, bands)


def score_rr(s):
    """盈亏比（2026-08-29 重构）。返回 (分, 现价口径R:R或None, 说明)。

    旧口径（退化）: entry=MA20, stop=MA20×0.985, target=近60日最高
        → 分母恒为 MA20 的 1.5%、分子是 60 日区间最大涨幅，
          60日最高比MA20高 4.5% 即满分 → 105 样本中 103 个满分，维度失效。
    新口径:
        support = 现价下方最近实质支撑（nearest_support_below）
        stop    = min(支撑×(1−1.5%), 支撑 − ATR_MULT×ATR14)     ← 与波动率挂钩
        target  = 现价上方最近且 ≥RESIST_MIN_ATR×ATR 的实质阻力  ← 非 60 日最高、非贴身噪声
        rr_now  = (target − 现价) / (现价 − stop)               ← 现价口径，参与计分
        rr_pull = (target − 支撑) / (支撑 − stop)               ← 回踩买点口径，仅展示
    计分取 rr_now（回答"现在买进去值不值"）；rr_pull 用于报告里"回踩到 X 再买"的建议。

    参数来源（生益科技 sh600183，130 根K线 → 66 个可评交易日，walk-forward 逐日重算）:
        ATR_MULT=1.0 / RESIST_MIN_ATR=2.0 / NO_RESIST_ATR_MULT=5.0 / RR_BANDS 重标
      ┌──────────────┬──────┬──────┬──────┬──────┬──────┬────────┐
      │ 口径         │ 15分 │ 11分 │ 7分  │ 3分  │ 种类 │ 中位R:R │
      ├──────────────┼──────┼──────┼──────┼──────┼──────┼────────┤
      │ 旧口径       │  41  │  0   │  0   │  25  │  2   │   —    │
      │ 新口径初版   │  0   │  0   │  1   │  65  │  2   │  0.44  │
      │ 新口径现行   │  8   │  23  │  24  │  11  │  4   │  1.77  │
      └──────────────┴──────┴──────┴──────┴──────┴──────┴────────┘
    ⚠️ 单标的标定，属【推断·待验证】，需多标的复检。
    """
    if not s.kline:
        return 0, None, "缺K线, 盈亏比给0(宁低勿高)"
    if not USE_NEW_RR:
        # ---- 旧口径（保留用于 A/B 对照，勿删）----
        sup = s.support
        if sup is None:
            return 0, None, "缺支撑, 盈亏比给0"
        entry, stop = sup, sup * STOP_PCT
        target = s.hh(TARGET_LOOKBACK)
        if target is None or target <= entry:
            return 3, None, f"近{TARGET_LOOKBACK}日无法定阻力(target≤买点), 给3"
        rr = (target - entry) / (entry - stop)
        sc = rr_score(rr, RR_BANDS_OLD)
        rr_now = (target - s.px) / (s.px - stop) if (s.px and s.px > stop) else None
        return sc, rr_now, (f"[旧口径] 买点{entry:.2f} 止损{stop:.2f} 目标{target:.2f} "
                            f"买点R:R={rr:.1f}" + (f" 现价口径R:R={rr_now:.1f}" if rr_now else ""))

    sup, sup_basis = nearest_support_below(s)
    if sup is None:
        return 3, None, f"{sup_basis}, 无有效止损参照 → 给3(宁低勿高)"
    stop, stop_why = s.stop_level(sup)
    if stop is None:
        return 3, None, "止损不可算 → 给3"
    target, t_basis = s.nearest_resistance()
    if target is None or target <= stop:
        return 3, None, f"目标({t_basis})≤止损, 无正风险收益 → 给3"
    rr_now = (target - s.px) / (s.px - stop) if (s.px and s.px > stop) else None
    rr_pull = (target - sup) / (sup - stop) if sup > stop else None
    rr_eff = rr_now if rr_now is not None else rr_pull
    if rr_eff is None:
        return 3, None, "R:R 不可算(现价≤止损) → 给3"
    sc = rr_score(rr_eff, RR_BANDS)
    # 【趋势交叉约束】R:R 依赖"支撑守得住 / 阻力够得着"两个前提，趋势崩坏时两者都不成立。
    tr, tr_why = score_trend(s)
    for tr_max, cap in RR_TREND_CAPS:
        if tr <= tr_max:
            if sc > cap:
                why_cap = (f" | 趋势{tr}({tr_why})下 R:R 不可信, "
                           f"{sc}→{cap}分封顶")
                sc = cap
            else:
                why_cap = f" | 趋势{tr}封顶{cap}, 未触发"
            break
    else:
        why_cap = f" | 趋势{tr}(多头), 不封顶"
    why = (f"支撑{sup:.2f}[{sup_basis}] 止损{stop:.2f}[{stop_why}] 目标{target:.2f}[{t_basis}] | "
           f"回踩买点R:R={rr_pull:.2f}" if rr_pull else "回踩买点R:R=NA")
    if rr_now is not None:
        why += f" | 现价口径R:R={rr_now:.2f} ← 计分口径"
    else:
        why += " | 现价≤止损, 计分口径=回踩买点R:R"
    why += f" | ATR14={s.atr():.2f}" if s.atr() else ""
    why += why_cap
    return sc, rr_now, why


def chase_penalty(s, rr_now):
    """【④ 追高修正】现价距买点(MA20)>8% 且 现价口径R:R<1.0 → 扣分，标注追高风险。

    返回 (扣分, 是否触发)。"""
    sup = s.support
    if sup is None or s.px is None:
        return 0, False
    dist = (s.px - sup) / s.px
    if rr_now is not None and dist > CHASE_DIST and rr_now < CHASE_RR_NOW:
        return CHASE_PENALTY, True
    return 0, False


def score_valuation(s, pool_med):
    if not VAL_POOL_RATIO or pool_med is None:
        # 【2026-08-29 修正】旧逻辑恒给 7 分（"中枢档"），实测 PE 为 8 / 15 / 33.7 / 80 / 300
        # 全部得 7 分，与估值高低完全无关 —— 泡沫股与价值股同分。改为显式标注【无法确认】。
        extra = f"（该股PE={s.pe:.1f}）" if s.pe else ""
        return VAL_NO_BENCH_SCORE, (f"【无法确认】未提供行业PE基准，无法判断估值高低{extra}；"
                                    f"给中性偏低 {VAL_NO_BENCH_SCORE} 分（不是评价结果，需人工补基准后重算）")
    if s.pe is None or s.pe <= 0:
        return 0, "亏损/无PE"
    r = s.pe / pool_med
    sc = 10 if r <= 0.7 else 7 if r <= 1.0 else 4 if r <= 1.5 else 0
    if sc == 0 and (s.chg_10d is not None and s.chg_10d > 40):
        return 0, f"PE为基准{r:.2f}倍且10日涨{s.chg_10d:.0f}%→透支0分"
    return sc, f"PE{s.pe:.1f}=估值基准({pool_med:.1f})的{r:.2f}倍"


def _normalize_chip(c):
    """把 retail_ratio.py 的原始输出（L1/L2/L3 三层）归一化为简化 chip 字段。

    为什么不要求调用方先转换一层：批量扫描时 20 只标的各转一次，既啰嗦又容易
    转错字段名。让内核同时吃两种格式，调用方把 retail_ratio 输出原样塞进
    "chip" 即可，减少一层格式漂移风险。"""
    if not any(k in c for k in ("L1_holding", "L2_alert", "L3_flow_20d")):
        return c                       # 已是简化格式（A），原样返回
    out = dict(c)
    l1 = c.get("L1_holding") or {}
    l2 = c.get("L2_alert") or {}
    flows = c.get("L3_flow_20d") or []
    if out.get("retail_pct") is None and l1.get("retail_ratio_est") is not None:
        out["retail_pct"] = l1["retail_ratio_est"]
    if out.get("signal") is None and l2.get("level"):
        out["signal"] = l2["level"]
    if out.get("main_flow_20d") is None and flows:
        tot = 0.0
        for r in flows:
            v = r.get("main_net")
            if isinstance(v, (int, float)):
                tot += v
        out["main_flow_20d"] = tot
    if l2.get("detail"):
        out["holder_trend"] = out.get("holder_trend") or l2["detail"]
    # 【2026-08-29】透传数据质量标记。retail_ratio.py v2 起会输出 basis /
    # degraded / warnings —— 筹码分必须能看出"是数据真的好"还是"数据没取到"。
    if l1.get("basis"):
        out["chip_basis"] = l1["basis"]
    if l1.get("retail_ratio_est") is None:
        out["chip_retail_missing"] = True
    # degraded 已含 "L1: " 前缀的 warnings, 二者不可重复拼接(实测会输出两次同一条)
    deg = list(c.get("degraded") or []) or [f"L1: {w}" for w in (l1.get("warnings") or [])]
    seen, uniq = set(), []
    for d in deg:                      # 再兜一层去重, 防止上游已拼过
        if d not in seen:
            seen.add(d)
            uniq.append(d)
    if uniq:
        out["chip_degraded"] = uniq
    return out


def chip_adjustment(s):
    """【2026-08-29 新增】筹码结构加减分项（不计入六维，作为总分外的显式调整）。

    依据：analysis-method.md 十三章自述户数是唯一有回测证据的独立 alpha
    （741 事件：集中度改善组 T+20 超额 +4.9%/胜率 59%，散户化组胜率仅 42%）。
    此前该信号"花力气算出来却只展示不进分"，与自身结论矛盾。

    输入（JSON 中可选字段 "chip"），两种格式都吃：
      A. 简化字段（批量扫描场景手工组装）:
         {"retail_pct": 61.15, "signal": "散户化预警"|"集中度改善"|"中性",
          "holder_trend": "up"|"down"|"flat", "main_flow_20d": -4.36e8}
      B. retail_ratio.py 原始输出（2026-08-29 起支持，可零转换直接塞）:
         {"L1_holding": {"retail_ratio_est": 35.92},
          "L2_alert":   {"level": "散户化预警", "detail": "..."},
          "L3_flow_20d":[{"main_net": -1.2e8, "small_net": 3e7}, ...]}
      映射：retail_pct ← L1_holding.retail_ratio_est
            signal     ← L2_alert.level
            main_flow_20d ← sum(L3_flow_20d[].main_net)（单位：元，与 A 格式一致）
      显式字段（A）优先于从 B 解析出的值，两者混用也可以。
    规则（保守，宁可少加不多加）:
      集中度改善（户数连续两期下降）      → +3
      中性                                → 0
      散户化预警（户数连增/环比≥+30%）    → −4
      叠加：散户比例 >85%（极端散户票）   → 再 −2
      叠加：散户化预警 且 主力20日净流出   → 再 −2（坐实派发）
    上限 ±CHIP_ADJ_MAX。
    返回 (调整分, 说明)；无 chip 字段返回 (0, 说明未接入)。"""
    c = getattr(s, "chip", None) or {}
    if not c:
        return 0, "未接入筹码数据(retail_ratio.py), 不加不减"
    c = _normalize_chip(c)
    sig = c.get("signal", "中性")
    adj, parts = 0, []
    if sig == "集中度改善":
        adj += 3
        parts.append("户数连续下降(集中度改善) +3")
    elif sig == "散户化预警":
        adj -= 4
        parts.append("散户化预警 −4")
    rp = c.get("retail_pct")
    if rp is not None and rp > 85:
        adj -= 2
        parts.append(f"散户比例{rp:.1f}%>85%(极端散户票) −2")
    mf = c.get("main_flow_20d")
    if sig == "散户化预警" and mf is not None and mf < 0:
        adj -= 2
        parts.append(f"散户化+主力20日净流出{mf/1e8:.2f}亿(坐实派发) −2")
    elif sig == "集中度改善" and mf is not None and mf > 0:
        adj += 1
        parts.append(f"集中度改善+主力净流入{mf/1e8:.2f}亿 +1")
    adj = max(-CHIP_ADJ_MAX, min(CHIP_ADJ_MAX, adj))
    why = "；".join(parts) if parts else f"{sig}, 无加减"
    # 【2026-08-29】数据质量标记：不改变分数，但必须让报告读者知道哪几项是"没取到"。
    # 背景：东财资金流接口 2026-08-29 实测 6/6 标的全部 RemoteDisconnected(限流)，
    # 若静默按"主力未净流出"处理，散户化票会系统性少扣 2 分。
    notes = []
    if sig == "散户化预警" and mf is None:
        notes.append("⚠主力20日资金流缺失→'散户化+主力净流出 −2'未触发, 筹码分偏乐观")
    if c.get("chip_retail_missing"):
        notes.append("⚠散户比例缺失(持股数据不可得)→极端散户票 −2 无法判定")
    if c.get("chip_basis") == "top10_degraded":
        notes.append("⚠筹码为十大降级口径(分母=总股本), A+H/高限售股失真")
    # 【2026-08-29 v2.1】L2 不可用(过期/不足2期/无记录)时, why 会写"无加减",
    # 极易被读成"筹码结构正常" —— 必须显式声明该维度缺失。
    # 背景: 东财 RPT_HOLDERNUM_DET 覆盖不全, 长飞光纤只有 1 期且是 2018 年数据,
    # 复星医药 0 条; 此时 adj=0 是"无法判断"而非"判断为中性"。
    if sig in ("数据过期", "数据不足", "无数据"):
        notes.append(f"⚠L2{sig}→筹码趋势维度缺失, 散户化/集中度均无法判断(不等于结构正常)")
    for d in (c.get("chip_degraded") or [])[:3]:
        # 只挑影响数值可信度的质量项: L1 分页/不同期, L3 资金流断供。
        # L2 上面已有专门的精简提示, 原始条目更啰嗦, 这里跳过避免重复表述。
        if any(k in d for k in ("分页触顶", "不同期", "L3: 无日频资金流")):
            notes.append("⚠" + d.split(": ", 1)[-1])
    # 去重保序: L3 资金流缺失在 sig==散户化预警 时上面已记过一条, 避免重复
    seen_n, uniq_n = set(), []
    for n in notes:
        if n not in seen_n:
            seen_n.add(n)
            uniq_n.append(n)
    if uniq_n:
        why = why + " [" + "；".join(uniq_n) + "]"
    return adj, why


def theme_check(s, theme_sc):
    """【2026-08-29 新增】题材分(唯一人工项)锚定校验。

    历史问题：52% 的样本落在缺省值 6（55/105），且 note 为空 —— 与 2026-08-25
    "人工解读波动"事故同源。这里强制：给分必须落在锚点档位上，且必须写明具体题材。
    返回警告列表。"""
    w = []
    note = (s.theme.get("note") or "").strip()
    if theme_sc not in THEME_ANCHOR:
        w.append(f"题材分{theme_sc}不在锚点档位{list(THEME_ANCHOR)}内, 须按下表取档: "
                 + "; ".join(f"{k}={v}" for k, v in THEME_ANCHOR.items()))
    if not note or note in THEME_NOTE_REQUIRED:
        w.append(f"题材分{theme_sc}未写明具体题材依据(仅缺省文案), 须在 note 中给出"
                 "「题材名称 + 事件催化时点」两个要素")
    return w


def consistency_check(s, dims):
    """scoring.md 交付前三查。返回警告列表。"""
    w = []
    px, m60, ma5 = s.px, s.ma.get("MA_60"), s.ma.get("MA_5")
    if m60 and px < m60 and dims["trend"][0] >= 15:
        w.append("价<MA60但趋势分≥15")
    # 【2026-08-29 修正】原阈值 14 会误报：跌破MA5 后位置分本就应降到 14（"降一档"规则），
    #   14 是预期结果而非矛盾。真正需要人工复核的是降档没生效（仍 ≥20）。
    if ma5 and px < ma5 and dims["pos"][0] >= 20:
        w.append("跌破MA5但位置分仍≥20(降档未生效)")
    if s.j is not None and s.j < 20 and (s.vol_ratio or 1) < 1 and dims["mom"][0] >= 14:
        w.append("J超卖且量缩但动能分≥14")
    return w


# ============================================================
# 主流程
# ============================================================
def append_history(history_path, rows, now=None):
    """把本次评分的快照追加到 JSONL（每行一条, 供 backtest.py 回测）。

    快照含: 日期/代码/名称/总分/评级/六维分项/是否追高修正/现价/现价口径R:R。
    失败不中断主流程（回测落库是辅助能力）。"""
    if not history_path:
        return
    now = now or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(history_path, "a", encoding="utf-8") as f:
            for r in rows:
                d = r["dims"]
                rec = {
                    "ts": now,
                    "date": r.get("score_date", ""),
                    "code": r["s"].code,
                    "name": r["s"].name,
                    "total": r["total"],
                    "rating": rating_of(r["total"]),
                    "six": [d["trend"][0], d["pos"][0], d["mom"][0], d["rr"][0], d["theme"][0], d["val"][0]],
                    "chased": r["chased"],
                    "px": r["s"].px,
                    "rr_now": r["rr_now"],
                    "six_sum": r["six_sum"],
                    "chip_adj": r["chip_adj"],
                    "rr_mode": "new" if USE_NEW_RR else "old",
                }
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        print(f"[历史落库] 追加 {len(rows)} 条 → {history_path}", file=sys.stderr)
    except Exception as e:
        print(f"[历史落库失败, 不影响本次评分] {e}", file=sys.stderr)


def run(path, out_path, history_path=None, score_date=""):
    with open(path, "r", encoding="utf-8-sig") as f:
        data = json.load(f)
    stocks = [Stock(r) for r in data.get("stocks", [])]
    # 估值基准优先级(逐股): 该股自带 pe_benchmark > 顶层 pe_benchmark > 候选池PE中位数 > None
    top_bench = data.get("pe_benchmark")
    # 【2026-08-29 二次修正】池中位数只在样本足够时才有统计意义。
    # 单股场景(len==1)下 median([自己]) == 自己的 PE → r 恒为 1.00 → 恒落"≤1.0"档给 7 分，
    # PE 是 8 还是 300 都一样，估值维度彻底失去区分度。这与上午修掉的
    # "pool_med is None 恒给 7 分"是同一个 bug 的另一个入口，必须一并堵死：
    # 样本不足时 pool_med = None → 走【无法确认】分支（给 5 分并显式标注），
    # 宁可承认无法判断，也不给一个伪装成"中枢档"的假分。
    _pe_pool = [s.pe for s in stocks if s.pe and s.pe > 0]
    pool_med = median(_pe_pool) if len(_pe_pool) >= POOL_MIN_N else None
    _bench_desc = (f"{pool_med:.1f}({len(_pe_pool)}只样本)" if pool_med
                   else f"N/A·有效PE样本{len(_pe_pool)}只<{POOL_MIN_N}·池中位数已禁用")

    rows = []
    for s in stocks:
        trend = score_trend(s)
        pos = score_position(s)
        mom = score_momentum(s)
        rr_sc, rr_now, rr_why = score_rr(s)
        theme_sc = int(s.theme.get("score", THEME_DEFAULT))
        bench = s.pe_benchmark or top_bench or pool_med  # 逐股 > 顶层 > 池中位数
        val = score_valuation(s, bench)
        dims = {
            "trend": trend, "pos": pos, "mom": mom,
            "rr": (rr_sc, rr_why),
            "theme": (theme_sc, s.theme.get("note", "默认:有题材无事件")),
            "val": val,
        }
        chase, chased = chase_penalty(s, rr_now)
        six_sum = sum(v[0] for v in dims.values())
        chip_adj, chip_why = chip_adjustment(s)
        total = six_sum - chase + chip_adj
        warns = consistency_check(s, dims) + theme_check(s, theme_sc)
        exr = exec_risk_of(s)
        final, veto_hits = apply_vetoes(rating_of(total), dims, chip_adj, warns, exr)
        rows.append({"s": s, "dims": dims, "total": total, "warns": warns,
                     "chase": chase, "chased": chased, "rr_now": rr_now,
                     "chip_adj": chip_adj, "chip_why": chip_why,
                     "six_sum": six_sum, "score_date": score_date,
                     "rating": final, "vetoes": veto_hits, "exec_risk": exr})

    rows.sort(key=lambda r: -r["total"])

    lines = []
    lines.append("## 六维评分结果（保守口径·脚本计算）\n")
    lines.append(f"评分维度: 趋势25/位置20/动能20/盈亏比15/题材10/估值10 | RSI窗口={RSI_WINDOW} | "
                 f"估值基准=逐股pe_benchmark(缺省回退候选池PE中位数{_bench_desc}) | "
                 f"追高修正: 现价距买点>{CHASE_DIST:.0%}且现价R:R<{CHASE_RR_NOW:.1f}扣{CHASE_PENALTY}分")
    lines.append(f"盈亏比口径(2026-08-29重构): 支撑=现价下方最近实质支撑, 止损=min(支撑下方"
                 f"{STOP_PCT_FLOOR:.1%}, 支撑−{ATR_MULT:g}×ATR14)且距现价≤{STOP_MAX_ATR_FROM_PX:g}×ATR, "
                 f"目标=现价上方最近实质阻力, 计分用现价口径R:R | "
                 f"筹码调整: 集中度改善+3 / 散户化预警−4(散户>85%再−2, 叠加主力净流出再−2), 上限±{CHIP_ADJ_MAX}\n")
    lines.append("| 名称 | 代码 | 六维和 | 筹码 | 追高 | 总分 | 评级 | 趋势 | 位置 | 动能 | 盈亏比 | 题材 | 估值 |")
    lines.append("|---|---|---|---|---|---|---|---|---|---|---|---|---|")
    for r in rows:
        s, d = r["s"], r["dims"]
        ch = f"−{r['chase']}" if r["chased"] else "—"
        cj = f"{r['chip_adj']:+d}" if r["chip_adj"] else "—"
        lines.append(
            f"| {s.name} | {s.code} | {r['six_sum']} | {cj} | {ch} | **{r['total']}** | "
            f"{r['rating']}"
            f"{(' ⚠' + str(len(r['vetoes']))) if r['vetoes'] else ''} | "
            f"{d['trend'][0]} | {d['pos'][0]} | {d['mom'][0]} | {d['rr'][0]} | "
            f"{d['theme'][0]} | {d['val'][0]} |"
        )
    lines.append("\n### 逐只明细\n")
    for r in rows:
        s, d = r["s"], r["dims"]
        lines.append(f"**{s.name}({s.code}) = {r['total']}分 → {r['rating']}**（现价 {s.px}）")
        for k, label in (("trend", "趋势"), ("pos", "位置"), ("mom", "动能"), ("rr", "盈亏比"), ("theme", "题材"), ("val", "估值")):
            sc, why = d[k]
            if why:
                lines.append(f"- {label} {sc}: {why}")
        if r["chased"]:
            lines.append(f"- ⚠️ **追高修正扣{r['chase']}分**: 现价距买点>8%且现价口径R:R<1.0, 已远离买点, 现价追高风险高")
        if r["chip_adj"]:
            lines.append(f"- 筹码调整 **{r['chip_adj']:+d}分**: {r['chip_why']}")
        else:
            lines.append(f"- 筹码调整 0分: {r['chip_why']}")
        if s.notes:
            lines.append(f"- 数据告警: {'; '.join(s.notes)}")
        if r["warns"]:
            lines.append(f"- ⚠️ 一致性校验未过: {'; '.join(r['warns'])}（需人工复核）")
        if r.get("exec_risk"):
            lines.append(f"- ⚠️ **A股执行风险**: {r['exec_risk']}"
                         f"（实际成交价可能显著劣于计划止损位）")
        if r["vetoes"]:
            lines.append(f"- 🚫 **评级否决**（总分 {r['total']} 对应「{rating_of(r['total'])}」，"
                         f"按风险约束下调为「{r['rating']}」）:")
            for v in r["vetoes"]:
                lines.append(f"  - {v}")
        lines.append("")

    report = "\n".join(lines)
    print(report)
    if out_path:
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(report + "\n")
        print(f"\n[已写入] {out_path}", file=sys.stderr)
    append_history(history_path, rows)


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="输入JSON路径")
    ap.add_argument("--out", help="输出Markdown路径(可选)")
    ap.add_argument("--rsi-window", default="RSI_6", choices=["RSI_2", "RSI_6", "RSI_12", "RSI_24"])
    ap.add_argument("--history", help="历史快照JSONL路径(回测落库, 可选)")
    ap.add_argument("--score-date", default="", help="评分交易日 YYYY-MM-DD, 写入快照date字段(建议填K线最后交易日)")
    ap.add_argument("--rr-old", action="store_true",
                    help="A/B对照: 盈亏比维度退回 2026-08-29 前的旧口径(MA20×0.985止损 + 60日最高目标)")
    ap.add_argument("--no-history", action="store_true", help="本次不落库(做A/B对照时用, 避免污染回测样本)")
    args = ap.parse_args()
    RSI_WINDOW = args.rsi_window
    if args.rr_old:
        USE_NEW_RR = False
    run(args.input, args.out,
        history_path=None if args.no_history else args.history,
        score_date=args.score_date)
