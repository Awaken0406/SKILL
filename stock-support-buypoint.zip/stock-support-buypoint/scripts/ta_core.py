# -*- coding: utf-8 -*-
"""ta_core —— 技术位计算内核（score_six.py 与 levels.py 的**唯一**真值源）。

为什么要单独抽出来（2026-08-29）：
    此前 score_six.py（评分）与 levels.py（报告展示）各自实现了一套"最近支撑/阻力"，
    候选集不同（score_six 缺成交密集区/整数关口/缺口），实测思源电气出现
        score_six  → 支撑 138.10（近120日最低）→ 止损 128.67 → 盈亏比 7 分
        levels.py  → 支撑 143.16（成交密集区）  → 止损 133.73 → 报告里写 133.73
    同一份报告自相矛盾。凡是"评分口径"与"展示口径"可能漂移的地方，都必须收敛到一处。

本模块只放**纯函数**（不依赖 Stock 类、不依赖任何脚本），可被两边安全 import，无循环依赖。

统一的算法口径：
    支撑/阻力候选 = 均线 ∪ 布林轨 ∪ 摆动高低点 ∪ 成交密集区(HVN) ∪ 跳空缺口沿
                    ∪ 区间高低点 ∪ 整数关口
    角色翻转       = 支撑型来源落在现价上方 → 标注"支撑转阻力"（反之"阻力转支撑"）
    最近支撑       = 现价下方候选中取**最大**者
    最近阻力       = 现价上方、且至少 RESIST_MIN_ATR×ATR 之外，取**最小**者；
                    不满足最小距离则视为"噪声级障碍、可突破"，改用 ATR 外推
    止损           = min(支撑×(1−1.5%), 支撑 − ATR_MULT×ATR14)，再对
                    "距现价 > STOP_MAX_ATR_FROM_PX×ATR" 收紧为跟踪止损
"""
import math

# ============================================================
# 常量（改这里 = 同时改评分与报告；勿在 score_six/levels 里重复定义）
# ============================================================
ATR_WINDOW = 14             # ATR 窗口（Wilder 平滑，与主流行情软件一致）
STOP_PCT_FLOOR = 0.015      # 止损至少在支撑下方 1.5%
# 【2026-08-29 参数扫描后回调】初版 2.0 在生益科技 66 日 walk-forward 上 65/66 得 3 分
#   （退化到另一端）。支撑本身通常已在现价下方约 1×ATR，再减 1×ATR ⇒ 止损约 2×ATR，
#   既落在"止损须在 2–3 ATR 之外"的经验区间，又与目标"至少 2×ATR"的量级匹配。
ATR_MULT = 1.0
STOP_MAX_ATR_FROM_PX = 3.0  # 止损距现价上限（强势趋势股用跟踪止损，不守远期支撑）
RESIST_LOOKBACK = 120       # 摆动点/区间高低点回溯根数
RESIST_BUFFER = 1.01        # 兜底：无 ATR 时，阻力须高于现价 1%
# 【2026-08-29 新增·本次修复的关键一项】目标须至少在现价上方 RESIST_MIN_ATR×ATR 之外。
#   贴身阻力（<2×ATR）在 ATR 尺度上属噪声级障碍，作为止盈目标会把 R:R 压到 0.4 量级
#   （实测中位 0.44，66 日里 65 个得 3 分）。加这一项后中位 R:R 回到 1.77。
RESIST_MIN_ATR = 2.0
# 【2026-08-29 5.0→3.0】外推目标须与"止损距现价上限 3×ATR"对称，否则分子分母不同尺度：
#   止损被压在 ≤3×ATR，目标却外推到 5×ATR，等于凭空造出 R:R≈1.7 的乐观下限。
#   取 3.0 后，无阻力时 R:R 天然收敛到 ≈1.0（分子 3×ATR / 分母约 2–3×ATR），
#   即"上方无阻力"不再自动等于"好买卖"，需要真实结构位才能拿高分。
NO_RESIST_ATR_MULT = 3.0    # 无合格阻力时，目标 = 现价 + 3×ATR（再对齐到整数关口）
# 【2026-08-29 反复试验后的结论：不要用固定 ATR 上限约束目标】
#   曾试过 RESIST_MAX_ATR=3.0（目标最远 3×ATR），结果 R:R 被压进 1.63~2.47，
#   且 66 个交易日里 0 个落入 3 分档 —— 该维度再也不会说"这笔赔率差"。
#   根因：固定上限把分子钉死在 3×ATR，而分母随"支撑距现价"变化，
#   R:R 于是退化成 3/(d/ATR+1)，等于把"位置"维度重算一遍（实测与支撑距离相关性虽只有
#   0.182，但那是因为支撑几乎总在 0.12~0.30 ATR 内，分母本身没变化空间）。
#   **R:R 必须分子分母同尺度（都以 ATR 计）才是波动率中性的**，固定上限会破坏这一点。
#   实测生益科技选中的 183.04 成交密集区（+25.7%）看似很远，但它是真实成交过的价位，
#   且 25.7% 仅 3.5×ATR，对该股 7.4% 的日波动属正常幅度，不是虚增赔率。
#   改用唯一一条护栏：目标不得超出近 RANGE_LOOKBACK 日最高（超出即属凭空想象）。
RESIST_MAX_BEYOND_RANGE = 0.0   # 允许超出区间最高的比例（0 = 不允许）

SWING_LR = 3                # 摆动点左右各看几根（fractal 半宽）
SWING_LOOKBACK = 120        # 摆动点回溯根数
VP_LOOKBACK = 120           # 成交量分布回溯根数
VP_BINS = 40                # 成交量分布分箱数
VP_HVN_FACTOR = 1.3         # HVN 阈值：箱内量 ≥ 均值×该系数 且为局部峰
GAP_LOOKBACK = 60           # 缺口回溯根数
RANGE_LOOKBACK = 120        # 区间高低点回溯根数
CLUSTER_TOL = 0.010         # 聚类容差（占现价比例）

# R:R → 分值。新门槛是按 ATR 挂钩的宽止损口径重新标定的（旧门槛针对 1.5% 窄止损）。
# ⚠️ 标定仅基于生益科技 1 只标的 66 个交易日，属【推断·待验证】，需多标的复检。
RR_BANDS = [(2.5, 15), (1.8, 11), (1.2, 7)]
RR_BANDS_OLD = [(3.0, 15), (2.0, 11), (1.5, 7)]   # 旧口径门槛（A/B 对照用，勿改）

# 依据的"原生角色"：neutral=中性 / support=支撑型 / resistance=阻力型
#   决定候选落到现价另一侧时是否要标注"支撑转阻力"或"阻力转支撑"。
NATIVE_ROLE = {
    "布林上轨": "resistance", "布林下轨": "support",
    "摆动高点": "resistance", "摆动低点": "support",
    "向上跳空缺口下沿": "support", "向下跳空缺口上沿": "resistance",
}

MA_KEYS = ("MA_5", "MA_10", "MA_20", "MA_30", "MA_60", "MA_120", "MA_250")


# ============================================================
# 基础工具
# ============================================================
def _f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def bars_from_kline(nodes):
    """把 score_six/输入JSON 的 kline 节点转成 bars。

    容错：输入常缺 open（行情接口未返回或组装时漏掉）→ 回退为前一根收盘，
    首根回退为自身收盘。缺一个可选字段不该让整个技术位计算静默失效。
    """
    bars, prev_close = [], None
    for n in (nodes or []):
        if not isinstance(n, dict) or "date" not in n:
            continue
        h, l, c = _f(n.get("high")), _f(n.get("low")), _f(n.get("last"))
        if None in (h, l, c):
            continue
        o = _f(n.get("open"))
        imputed = False
        if o is None:
            o = prev_close if prev_close is not None else c
            imputed = True
        bars.append({"date": n["date"], "open": o, "high": h, "low": l, "last": c,
                     "volume": _f(n.get("volume")) or 0.0,
                     "exchange": _f(n.get("exchange")) or 0.0,
                     "open_imputed": imputed})
        prev_close = c
    bars.sort(key=lambda b: b["date"])
    return bars


def true_ranges(bars):
    return [max(b["high"] - b["low"],
                abs(b["high"] - bars[i - 1]["last"]),
                abs(b["low"] - bars[i - 1]["last"]))
            for i, b in enumerate(bars) if i >= 1]


def atr_wilder(bars, window=ATR_WINDOW):
    """Wilder 平滑 ATR。K线不足 window 根时退化为全体简单均值。"""
    trs = true_ranges(bars)
    if not trs:
        return None
    if len(trs) < window:
        return sum(trs) / len(trs)
    a = sum(trs[:window]) / window
    for tr in trs[window:]:
        a = (a * (window - 1) + tr) / window
    return a


def swing_pivots(bars, lr=SWING_LR, lookback=SWING_LOOKBACK):
    """摆动高低点（fractal）。返回 (highs, lows) 价格列表。"""
    seq = bars[-lookback:] if len(bars) > lookback else bars
    highs, lows = [], []
    for i in range(lr, len(seq) - lr):
        h, l = seq[i]["high"], seq[i]["low"]
        if all(h >= seq[j]["high"] for j in range(i - lr, i + lr + 1) if j != i):
            highs.append(h)
        if all(l <= seq[j]["low"] for j in range(i - lr, i + lr + 1) if j != i):
            lows.append(l)
    return highs, lows


def volume_profile_nodes(bars, nbins=VP_BINS, factor=VP_HVN_FACTOR,
                         lookback=VP_LOOKBACK):
    """成交量分布高量节点(HVN)。按典型价 (H+L+C)/3 分箱，取局部峰且 ≥均值×factor 的箱。

    成交量全缺失时（如只存了换手率）用换手率作代理 —— 与成交量近似成正比，分布形状一致。
    返回 [(价格, 该箱成交量占比), ...] 按占比降序。"""
    seq = bars[-lookback:] if len(bars) > lookback else bars
    if len(seq) < 3:
        return []
    lo, hi = min(b["low"] for b in seq), max(b["high"] for b in seq)
    if hi <= lo:
        return []
    size = (hi - lo) / nbins
    bins = [0.0] * nbins
    total = 0.0
    use_turnover = all(not float(b.get("volume") or 0) for b in seq)
    for b in seq:
        tp = (b["high"] + b["low"] + b["last"]) / 3.0
        k = max(0, min(nbins - 1, int((tp - lo) / size)))
        v = float(b.get("exchange") or 0) if use_turnover else float(b.get("volume") or 0)
        bins[k] += v
        total += v
    if total <= 0:
        return []
    mean = total / nbins
    nodes = []
    for k in range(nbins):
        if bins[k] < mean * factor:
            continue
        left = bins[k - 1] if k > 0 else 0
        right = bins[k + 1] if k < nbins - 1 else 0
        if bins[k] < left or bins[k] < right:      # 必须是局部峰
            continue
        nodes.append((lo + (k + 0.5) * size, bins[k] / total))
    nodes.sort(key=lambda x: -x[1])
    return nodes


def gaps(bars, lookback=GAP_LOOKBACK):
    """跳空缺口沿。返回 [(价格, 依据), ...]。"""
    seq = bars[-lookback:] if len(bars) > lookback else bars
    out = []
    for i in range(1, len(seq)):
        prev_h, prev_l = seq[i - 1]["high"], seq[i - 1]["low"]
        h, l = seq[i]["high"], seq[i]["low"]
        if l > prev_h:
            out.append((prev_h, "向上跳空缺口下沿"))
        elif h < prev_l:
            out.append((prev_l, "向下跳空缺口上沿"))
    return out


def round_step(px):
    """按价格量级自适应整数关口步长。"""
    if px >= 100:
        return 10.0
    if px >= 50:
        return 5.0
    if px >= 20:
        return 2.0
    return 1.0


def round_levels(px, n=3):
    """现价上/下各 n 个整数关口。"""
    step = round_step(px)
    base = int(px / step) * step
    return [base + k * step for k in range(-n, n + 1) if base + k * step > 0]


# ============================================================
# 候选位（带角色翻转标注）
# ============================================================
def _role_label(basis, price, px):
    """候选落到现价另一侧时标注角色翻转，避免报告出现"摆动低点当阻力"这类费解表述。"""
    native = NATIVE_ROLE.get(basis)
    if native == "support" and price > px:
        return f"{basis}(支撑转阻力)"
    if native == "resistance" and price < px:
        return f"{basis}(阻力转支撑)"
    return basis


def all_candidates(px, ma, boll, bars, include_round=True):
    """全部候选位。返回 [(price, basis, native_role), ...]（未过滤方向）。

    include_round=False 时剔除整数关口 —— 用于选"止盈目标"。
    【2026-08-29】整数关口是心理位而非结构位，且是本函数唯一"凭空生成"的候选：
      实测生益科技(ATR≈7.4%)因 2×ATR 门槛=+14.7% 把所有结构阻力都筛掉，
      结果选中 170 这个第 3 档人造整数关口作目标，把 R:R 从真实的 1.85 虚增到 4.08。
      故：找目标时整数关口不参与竞争，只在"必须外推"时用作对齐参考。"""
    if px is None:
        return []
    c = []
    for k in MA_KEYS:
        v = _f((ma or {}).get(k))
        if v:
            c.append((v, k, "neutral"))
    for key, basis, native in (("upper", "布林上轨", "resistance"),
                               ("lower", "布林下轨", "support")):
        v = _f((boll or {}).get(key))
        if v:
            c.append((v, basis, native))
    if bars:
        highs, lows = swing_pivots(bars)
        for h in sorted(set(highs)):
            c.append((h, "摆动高点", "resistance"))
        for l in sorted(set(lows)):
            c.append((l, "摆动低点", "support"))
        for p, r in volume_profile_nodes(bars):
            c.append((p, f"成交密集区(占量{r:.1%})", "neutral"))
        for p, b in gaps(bars):
            c.append((p, b, NATIVE_ROLE.get(b, "neutral")))
        seq = bars[-RANGE_LOOKBACK:]
        c.append((max(b["high"] for b in seq), f"近{RANGE_LOOKBACK}日最高", "resistance"))
        c.append((min(b["low"] for b in seq), f"近{RANGE_LOOKBACK}日最低", "support"))
    if include_round:
        for p in round_levels(px):
            c.append((p, f"整数关口{p:g}", "neutral"))
    return c


def support_candidates(px, ma, boll, bars, include_round=True):
    """现价下方的候选支撑。返回 [(price, 标注后的依据)]，按价格降序。"""
    out = [(p, _role_label(b, p, px))
           for p, b, _ in all_candidates(px, ma, boll, bars, include_round)
           if p < px]
    return sorted(out, key=lambda x: -x[0])


def resistance_candidates(px, ma, boll, bars, include_round=True):
    """现价上方的候选阻力。返回 [(price, 标注后的依据)]，按价格升序。"""
    out = [(p, _role_label(b, p, px))
           for p, b, _ in all_candidates(px, ma, boll, bars, include_round)
           if p > px]
    return sorted(out, key=lambda x: x[0])


def nearest_support(px, ma, boll, bars):
    """现价下方最近的实质支撑 → (价格, 依据)。无候选返回 (None, 原因)。

    为什么不能再用 min(MA20, 布林中轨)：
      股价崩穿所有均线时（如思源电气 8/28 跌破 MA5/10/20/60/120/250），旧口径得到的
      支撑反在现价**上方**，据此算出的止损价高于现价，R:R 分母为负、完全失真。"""
    c = support_candidates(px, ma, boll, bars)
    if not c:
        return None, "现价已跌破全部候选支撑"
    return c[0]


def nearest_resistance(px, ma, boll, bars, atr=None):
    """现价上方最近、且至少 RESIST_MIN_ATR×ATR 之外的实质阻力 → (价格, 依据)。

    近在咫尺的阻力在 ATR 尺度上属噪声级障碍，视为可突破、不作为止盈目标；
    不满足最小距离时改用 ATR 外推（结果向下对齐到整数关口，避免出现 177.81 这类价位）。
    注：整数关口不参与竞争（见 all_candidates 注释），只在外推时作对齐参考。"""
    if px is None:
        return None, "缺现价"
    c = resistance_candidates(px, ma, boll, bars, include_round=False)
    thr = px + RESIST_MIN_ATR * atr if atr else px * RESIST_BUFFER
    far = [x for x in c if x[0] >= thr]
    if far and bars:
        # 唯一护栏：目标不得超出近 RANGE_LOOKBACK 日最高（超出即属凭空想象）
        ceiling = max(b["high"] for b in bars[-RANGE_LOOKBACK:]) * (1 + RESIST_MAX_BEYOND_RANGE)
        if far[0][0] <= ceiling:
            return far[0]
        return (ceiling,
                f"最近合格结构阻力 {far[0][0]:.2f}[{far[0][1]}] 超出近{RANGE_LOOKBACK}日最高"
                f"{ceiling:.2f}，按区间上沿取")
    if far:
        return far[0]
    if atr:
        raw = px + NO_RESIST_ATR_MULT * atr
        step = round_step(px)
        aligned = int(raw / step) * step          # 向下对齐，不夸大目标
        if aligned <= px:
            aligned = raw
        near = f"（最近结构阻力 {c[0][0]:.2f}[{c[0][1]}] < {RESIST_MIN_ATR:g}×ATR，视为可突破）" \
               if c else ""
        return (aligned,
                f"无≥{RESIST_MIN_ATR:g}×ATR的实质阻力{near}，"
                f"ATR外推({NO_RESIST_ATR_MULT:g}×ATR)={raw:.2f}→对齐{aligned:.2f}")
    return None, "无阻力且缺ATR"


def range_position(px, bars, lookback=RANGE_LOOKBACK):
    """现价在近 lookback 日区间中的分位 → (分位0~1, 说明)。

    用于"位置"维度的交叉校验：光看"距最近支撑多远"会被贴身支撑骗到高分
    （股价一路阴跌时最近支撑总在脚下），叠加区间分位才能识别真正的追高。"""
    if px is None or not bars:
        return None, "缺K线"
    seq = bars[-lookback:]
    hi = max(b["high"] for b in seq)
    lo = min(b["low"] for b in seq)
    if hi <= lo:
        return None, "区间退化"
    pos = (px - lo) / (hi - lo)
    return pos, f"近{len(seq)}日区间 {lo:.2f}~{hi:.2f} 分位 {pos:.0%}"


# ============================================================
# 止损 / 计分
# ============================================================
def stop_from_support(support_px, atr, px=None):
    """止损 = min(支撑×(1−1.5%), 支撑 − ATR_MULT×ATR)，取更低者；
    再对"距现价 > STOP_MAX_ATR_FROM_PX×ATR"收紧为跟踪止损。返回 (止损, 说明)。"""
    if support_px is None:
        return None, ""
    floor = support_px * (1 - STOP_PCT_FLOOR)
    stop = floor
    why = f"支撑{support_px:.2f} 下方 {STOP_PCT_FLOOR:.1%} = {floor:.2f}"
    if atr:
        atr_stop = support_px - ATR_MULT * atr
        if atr_stop < floor:
            stop = atr_stop
            why = (f"支撑{support_px:.2f} − {ATR_MULT:g}×ATR({atr:.2f}) = {atr_stop:.2f}"
                   f"（宽于支撑下方{STOP_PCT_FLOOR:.1%}的{floor:.2f}，取宽者）")
        if px:
            cap = px - STOP_MAX_ATR_FROM_PX * atr
            if stop < cap and cap < support_px:
                stop = cap
                why += f" → 距现价>{STOP_MAX_ATR_FROM_PX:g}×ATR，收紧为跟踪止损 {stop:.2f}"
    return stop, why


def rr_score(rr, bands=RR_BANDS):
    """R:R → 分值。bands = [(下限, 分值)] 降序，都不满足 → 3。"""
    for thr, sc in bands:
        if rr >= thr:
            return sc
    return 3


def cluster(cands, px, tol=CLUSTER_TOL):
    """把候选按价位聚类成"共振区"。cands = [(price, basis, weight)]。

    1% 内的候选合并：价格为加权平均，依据合并（去重），权重累加（越多依据共振越强）。"""
    if not cands:
        return []
    items = sorted(cands, key=lambda x: x[0])
    tol_abs = abs(px or items[0][0]) * tol
    zones = []
    for p, b, w in items:
        if zones and p - zones[-1]["hi"] <= tol_abs:
            z = zones[-1]
            tot = z["weight"] + w
            z["price"] = (z["price"] * z["weight"] + p * w) / tot if tot else p
            z["hi"] = max(z["hi"], p)
            z["weight"] = tot
            if b not in z["bases"]:
                z["bases"].append(b)
        else:
            zones.append({"price": p, "hi": p, "weight": w, "bases": [b]})
    return zones
