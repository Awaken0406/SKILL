#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
低价低位扫描 —— score_input.json 组装器（可复用模板）

用法：
  1. 跑完 L1(tool_filter) / L2(data_quote) / L3(data_kline + data_technical) 后，
     把数据填进下面的 QUOTE / TECH / IND / NAME / THEME 五个字典。
  2. K 线不用手填：本脚本自动扫描 tool-results 目录下被自动落盘的
     mcp-westock-mcp-data_kline-*.txt（批量 K 线过大时工具会自动落盘），
     直接 json.load 读取，避免把十几万字符读进上下文。
  3. python assemble_score_input.py   → 生成 score_input.json
  4. python D:/News/score_six.py --input score_input.json --out score_out.md \
         --no-history --score-date YYYY-MM-DD

铁律：
  - 行业 PE 只从 D:/News/scan.db 的 industry_pe 取；未命中必须 WebSearch 后回写，
    禁止手写，也禁止让内核回退到候选池 PE 中位数（低价池中位数偏低会误判高估）。
  - 行业名必须与缓存中的字符串完全一致，否则静默未命中。
  - 评分一律交给 score_six.py 内核，禁止 LLM 心算。
"""
import json, os, glob, sqlite3

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
DB = "D:/News/scan.db"

# 工具自动落盘目录（批量返回过大时）；多个项目目录都要扫
TR_GLOB = os.path.expanduser(
    r"~\.workbuddy\projects\*\tool-results\mcp-westock-mcp-data_kline-*.txt")

# ---------------- ↓↓↓ 每次扫描需替换的部分：开始 ↓↓↓ ----------------

# 股票 → 行业（名字必须能在 industry_pe 表中命中）
IND = {
    # "sh600987": "纺织制造",
}

# 行情快照（data_quote 关键字段，其余字段内核不用，可省略）
QUOTE = {
    # "sh600987": dict(price=6.32, high=6.47, low=6.31, prev_close=6.47,
    #                  turnover_rate=0.86, volume_ratio=1.91, pe_ratio=8.96,
    #                  pe_fwd=10.75, chg_10d=-4.82, chg_20d=-4.82,
    #                  dividend_ratio_ttm=5.54, pb_ratio=0.96,
    #                  high_52week=8.59, low_52week=5.97, change_percent=-2.32),
}

# 技术指标（data_technical 原样结构）
TECH = {
    # "sh600987": dict(closePrice=6.32,
    #     ma={"MA_5":6.486,"MA_10":6.52,"MA_20":6.5495,"MA_30":6.5907,"MA_60":6.5158,
    #         "MA_120":6.6798,"MA_250":6.9053,"EMA_12":6.5124,"EMA_26":6.547,"EMA_50":6.5667},
    #     macd={"DIF":-0.0346,"DEA":-0.0123,"MACD":-0.0447},
    #     kdj={"KDJ_K":19.1308,"KDJ_D":30.9445,"KDJ_J":-4.4967},
    #     rsi={"RSI_2":2.909,"RSI_6":18.2256,"RSI_12":31.4704,"RSI_24":41.0623},
    #     boll={"BOLL_UPPER":6.7065,"BOLL_MID":6.5495,"BOLL_LOWER":6.3925}),
}

NAME = {
    # "sh600987": "航民股份",
}

# 题材：扫描场景未核查 30 天内事件，统一 6 分 + 必须写明具体题材
THEME = {
    # "sh600987": "印染+黄金双主业，黄金业务受益金价",
}

# ---------------- ↑↑↑ 每次扫描需替换的部分：结束 ↑↑↑ ----------------


def load_klines():
    """读工具自动落盘的批量 K 线 JSON。返回 {symbol: [nodes 正序]}"""
    files = sorted(glob.glob(TR_GLOB))
    kl = {}
    for p in files:
        try:
            with open(p, encoding="utf-8") as f:
                d = json.load(f)
        except Exception as e:
            print("[warn] 读取失败", p, e)
            continue
        for item in (d.get("data") or {}).get("data", []):
            sym = item.get("symbol")
            nodes = (item.get("data") or {}).get("nodes") or []
            if sym and nodes:
                kl[sym] = sorted(nodes, key=lambda n: n["date"])
    return kl, files


def get_pe(industry):
    conn = sqlite3.connect(DB)
    cur = conn.cursor()
    cur.execute("SELECT pe FROM industry_pe WHERE industry=?", (industry,))
    r = cur.fetchone()
    conn.close()
    return r[0] if r else None


def main():
    kl, files = load_klines()
    print("K线文件:", [os.path.basename(f) for f in files])
    print("K线覆盖:", {c: len(v) for c, v in kl.items()})

    stocks, missing = [], []
    for code, name in NAME.items():
        q = dict(QUOTE[code])
        q["code"], q["name"] = code, name
        st = {"code": code, "name": name, "quote": q, "tech": TECH[code],
              "kline": kl.get(code, []),
              "theme": {"score": 6, "note": THEME[code]}}
        ind = IND.get(code)
        pe = get_pe(ind) if ind else None
        if pe:
            st["pe_benchmark"] = pe
        else:
            missing.append((code, name, ind))
        stocks.append(st)

    path = os.path.join(OUT_DIR, "score_input.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"stocks": stocks}, f, ensure_ascii=False)
    print("written:", path, "stocks:", len(stocks))
    print("无K线:", [c for c in NAME if c not in kl])
    if missing:
        print("!!! 缺行业PE基准（会回退到池中位数，务必先搜索回写）:", missing)
    else:
        print("行业PE基准: 全部命中")


if __name__ == "__main__":
    main()
