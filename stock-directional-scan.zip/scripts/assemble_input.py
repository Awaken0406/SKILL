#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""组装 score_input.json：合并 raw_quote/raw_tech/raw_kline(+kl/*.csv) 为 score_six.py 输入。
逐股注入 pe_benchmark（行业PE中枢，WebSearch 获取，注明来源）与 theme.score（人工题材判断）。
"""
import json, csv, glob, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pe_cache

# 工作目录：优先用环境变量 NEWS_DIR，否则落到脚本自身所在目录。
# 这样装到别的机器（无 D:/News）时自动用脚本目录，本机因脚本就在 D:/News 行为不变。
NEWS = os.environ.get("NEWS_DIR") or os.path.dirname(os.path.abspath(__file__))

# code -> 规范行业名（与 industry_pe 表的 industry 键一致）。
# pe_benchmark 不再硬编码：组装时先查 industry_pe 缓存，命中即用；
# 只有缓存缺失的行业才需要 WebSearch（抓到后 pe_cache.set_pe 回写）。
CODE_INDUSTRY = {
    "sh600598": "种植业", "sh601869": "通信设备", "sh601898": "煤炭",
    "sh601975": "航运港口", "sh603112": "汽车零部件", "sz000017": "重组综合",
    "sz002033": "旅游景区", "sz002041": "种植业", "sz002215": "农药",
    "sz003010": "化妆品电商", "sh600508": "煤炭", "sh601088": "煤炭",
    "sh601886": "建筑装饰", "sh603268": "船舶重组", "sh603519": "白色家电",
    "sz002017": "通信设备", "sz002412": "中药", "sz002491": "通信设备",
    "sz002746": "肉鸡养殖", "sz002901": "医疗器械",
}

# 逐股 题材分（人工判断）：10=强题材+事件 / 6=有题材无事件 / 3=纯技术 / 0=无催化
THEME = {
    "sz002215": (6,  "农资/种植景气,有题材无单独事件"),
    "sh600598": (10, "粮食安全+种业振兴+AI育种政策(农业农村部重大引领性技术)"),
    "sh603112": (6,  "汽车出口高增+新能源"),
    "sh601869": (10, "AI算力/光通信/CPO强主线+光纤涨价"),
    "sz002041": (10, "种业振兴+AI育种+转基因"),
    "sh601975": (10, "油运高景气,VLCC运价高位"),
    "sh601898": (10, "高股息红利+煤价支撑/供给收缩"),
    "sz003010": (6,  "美妆电商代运营,有题材"),
    "sz002033": (6,  "旅游复苏/节假日"),
    "sz000017": (10, "重组预期+10日涨39%强势"),
    "sh601088": (10, "高股息红利标杆+煤价"),
    "sz002412": (10, "中药政策利好(11部门发文/基药目录)+10日涨70%强势"),
    "sz002017": (6,  "eSIM/数字人民币题材"),
    "sz002491": (6,  "光通信题材,无单独强事件确认"),
    "sh603519": (3,  "纯技术,小众家电材料无明确催化"),
    "sz002901": (6,  "器械集采缓和+设备更新政策"),
    "sh603268": (10, "恒力重工借壳重组+船舶制造"),
    "sz002746": (6,  "白羽肉鸡景气温和复苏"),
    "sh601886": (10, "10日涨40%强势+医疗(BIVD)/订单催化"),
    "sh600508": (10, "煤炭高股息+涨停强势"),
}

def load_ok(path):
    with open(path, "r", encoding="utf-8-sig") as f:
        return json.load(f).get("data", {})

quotes = {}
quotes.update(load_ok(f"{NEWS}/raw_quote_1.json"))
quotes.update(load_ok(f"{NEWS}/raw_quote_2.json"))

techs = {}
techs.update(load_ok(f"{NEWS}/raw_tech_1.json"))
techs.update(load_ok(f"{NEWS}/raw_tech_2.json"))

klines = {}
with open(f"{NEWS}/raw_kline.json", "r", encoding="utf-8-sig") as f:
    klines.update(json.load(f))
with open(f"{NEWS}/raw_kline_b.json", "r", encoding="utf-8-sig") as f:
    klines.update(json.load(f))

# kl/*.csv -> nodes
for fp in glob.glob(f"{NEWS}/kl/*.csv"):
    code = os.path.splitext(os.path.basename(fp))[0]
    nodes = []
    with open(fp, "r", encoding="utf-8-sig") as f:
        for row in csv.reader(f):
            if len(row) < 4 or not row[0].strip():
                continue
            nodes.append({
                "date": row[0].strip(),
                "last": float(row[1]),
                "high": float(row[2]),
                "exchange": float(row[3]),
            })
    klines[code] = nodes

# 合并
codes = list(quotes.keys())
missing_ind = [c for c in codes if c not in CODE_INDUSTRY]
assert not missing_ind, f"以下 code 缺行业映射(需补 CODE_INDUSTRY): {missing_ind}"
assert set(codes) == set(THEME.keys()), \
    f"code mismatch: quotes={len(codes)} theme={len(THEME)}"

stocks = []
for code in codes:
    q = quotes[code]
    t = techs.get(code, {})
    kl = klines.get(code, [])
    ts, tnote = THEME[code]
    # —— 行业PE：先查 industry_pe 缓存，命中即用；缺失才需 WebSearch 回写 ——
    ind = pe_cache.get_industry(code) or CODE_INDUSTRY.get(code)
    pe_info = pe_cache.get_pe(ind) if ind else None
    if pe_info:
        pb, psrc = pe_info["pe"], pe_info["source"]
    else:
        pb, psrc = None, f"[待WebSearch]行业={ind}"
        print(f"  [缺行业PE] {code} -> {ind} 需 WebSearch 后 pe_cache.set_pe 回写")
    stocks.append({
        "code": code,
        "name": q.get("name", code),
        "quote": q,
        "tech": t,
        "kline": kl,
        "pe_benchmark": pb,
        "theme": {"score": ts, "note": tnote, "pe_src": psrc},
    })

out = {"stocks": stocks}
with open(f"{NEWS}/score_input.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1)

print(f"[组装完成] 共 {len(stocks)} 只, 已写入 D:/News/score_input.json")
for s in stocks:
    print(f"  {s['name']}({s['code']}) quote={len(s['quote'])}keys tech={'ma' in s['tech']} kline={len(s['kline'])}nodes pe_b={s['pe_benchmark']} theme={s['theme']['score']}")
