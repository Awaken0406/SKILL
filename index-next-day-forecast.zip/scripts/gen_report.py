# -*- coding: utf-8 -*-
"""
把 analyze_index.py 的统计结果 + 人工研判配置渲染成 HTML 研报。

用法:
    python gen_report.py --kline kline.json --stats stats.json --config config.json [--out xxx.html]

说明:
  - 模板用 __XXX__ 占位符 + replace 替换，规避 % 格式化与 CSS/JS 字面 % 的冲突。
  - 渲染后自动抽取内联 <script> 做 node --check 语法校验，不通过则报错退出。
"""
import argparse, json, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_TPL = os.path.join(HERE, "..", "assets", "report-template.html")


# ---------------- 通用渲染助手 ----------------
def esc_num(v):
    """按正负号给数字单元格上色（A股：红涨绿跌）。"""
    s = str(v).strip()
    if s.startswith("+"):
        return '<span class="up">%s</span>' % s
    if s.startswith("-"):
        return '<span class="dn">%s</span>' % s
    return s


def kpi_html(items):
    out = []
    for it in items or []:
        out.append('<div class="kpi"><div class="lb">%s</div>'
                   '<div class="vl %s">%s</div><div class="ex">%s</div></div>'
                   % (it.get("lb", ""), it.get("cls", ""), it.get("vl", ""), it.get("ex", "")))
    return "".join(out)


def table_html(head, rows, num_cols=None):
    """num_cols: 需要右对齐+按正负着色的列索引集合。"""
    num_cols = num_cols or set()
    h = "".join('<th class="%s">%s</th>' % ("num" if i in num_cols else "", c)
                for i, c in enumerate(head))
    body = []
    for r in rows:
        tds = []
        for i, c in enumerate(r):
            cls = "num" if i in num_cols else ""
            val = esc_num(c) if i in num_cols else c
            tds.append('<td class="%s">%s</td>' % (cls, val))
        body.append("<tr>%s</tr>" % "".join(tds))
    return ('<table><thead><tr>%s</tr></thead><tbody>%s</tbody></table>'
            % (h, "".join(body)))


def badges_html(items):
    out = []
    for txt, kind in items or []:
        out.append('<span class="badge b-%s">%s</span>' % (kind, txt))
    return "".join(out)


def paras_html(items):
    if isinstance(items, str):
        return items
    return "".join(items or [])


# ---------------- 数据准备 ----------------
def load_nodes(path):
    d = json.load(open(path, "r", encoding="utf-8"))
    if isinstance(d, list):
        nodes = d
    elif isinstance(d, dict) and "nodes" in d:
        nodes = d["nodes"]
    elif isinstance(d, dict) and "data" in d:
        nodes = d["data"]["nodes"] if isinstance(d["data"], dict) else d["data"]
    else:
        raise ValueError("无法识别的 K 线格式")
    nodes = sorted(nodes, key=lambda x: x["date"])

    def g(n, *ks):
        for k in ks:
            if k in n and n[k] is not None:
                return float(n[k])
        return 0.0
    return nodes, g


def ma_series(close, n, i):
    if i + 1 < n:
        return None
    return sum(close[i - n + 1:i + 1]) / n


# ---------------- 主流程 ----------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kline", required=True)
    ap.add_argument("--stats", required=True)
    ap.add_argument("--config", required=True)
    ap.add_argument("--out", default=None)
    ap.add_argument("--template", default=DEFAULT_TPL)
    ap.add_argument("--no-check", action="store_true", help="跳过 node 语法校验")
    args = ap.parse_args()

    cfg = json.load(open(args.config, "r", encoding="utf-8"))
    stats = json.load(open(args.stats, "r", encoding="utf-8"))
    nodes, g = load_nodes(args.kline)

    close = [g(n, "last", "close") for n in nodes]
    N = len(close)
    recent = nodes[-30:]
    W = int(cfg.get("ma_window") or stats.get("meta", {}).get("ma_window") or 60)
    dates = [n["date"][5:] for n in recent]
    ohlc = [[round(g(n, "open"), 2), round(g(n, "last", "close"), 2),
             round(g(n, "low"), 2), round(g(n, "high"), 2)] for n in recent]
    ma20 = [round(ma_series(close, 20, N - len(recent) + k), 2) for k in range(len(recent))]
    maline = [round(ma_series(close, W, N - len(recent) + k), 2) for k in range(len(recent))]

    C = float(stats["meta"]["close"])

    # --- 板块图 ---
    sec_up = cfg.get("sectors", {}).get("up", [])
    sec_dn = cfg.get("sectors", {}).get("dn", [])
    sec_names = [s[0] for s in sec_dn[::-1]] + [s[0] for s in sec_up[::-1]]
    sec_vals = [s[1] for s in sec_dn[::-1]] + [s[1] for s in sec_up[::-1]]

    # --- 情景表与图 ---
    scen = cfg.get("scen", [])
    scen_rows, scen_labels, scen_vals, scen_data = [], [], [], []
    PAL_UP = "#c0392b"
    PAL_DN = "#128a55"
    for name, pt, prob in scen:
        chg = (pt / C - 1) * 100
        cls = "up" if chg > 0.02 else ("dn" if chg < -0.02 else "flat")
        scen_rows.append([name, "%d" % pt, "%+.2f%%" % chg, "%d%%" % prob])
        scen_labels.append(name)
        scen_vals.append(prob)
        if chg > 0.4:
            col = PAL_UP
        elif chg > 0.02:
            col = "#e08b8b"
        elif chg < -0.4:
            col = PAL_DN
        elif chg < -0.02:
            col = "#5cb85c"
        else:
            col = "#9ca3af"
        scen_data.append({"value": prob, "itemStyle": {"color": col}})

    # --- 点位阶梯 ---
    lad = []
    for px, tag, kind, desc in cfg.get("ladder", []):
        tcls = {"r": "t-r", "g": "t-g", "n": "t-n"}.get(kind, "t-n")
        rcls = {"r": "r-r", "g": "r-g", "n": "r-n"}.get(kind, "r-n")
        lad.append('<div class="rung %s"><span class="px">%s</span>'
                   '<span class="tg %s">%s</span><span class="ds">%s</span></div>'
                   % (rcls, px, tcls, tag, desc))

    tpl = open(args.template, "r", encoding="utf-8").read()

    html = (tpl
            .replace("__TITLE__", cfg["title"])
            .replace("__SUBTITLE__", cfg.get("subtitle", ""))
            .replace("__TLDR__", paras_html(cfg.get("tldr")))
            .replace("__BADGES__", badges_html(cfg.get("badges")))
            .replace("__KPI__", kpi_html(cfg.get("kpi")))
            .replace("__INTRADAY__", paras_html(cfg.get("intraday")))
            .replace("__INDICES__", table_html(cfg["indices"]["head"], cfg["indices"]["rows"],
                                               {1, 2, 3, 4, 5}))
            .replace("__SECTORS__", table_html(cfg["sectors"].get("head", ["方向", "代表板块", "资金特征"]),
                                               cfg["sectors"].get("rows", [])))
            .replace("__BREADTH_KPI__", kpi_html(cfg.get("breadth", {}).get("kpi")))
            .replace("__BREADTH_NOTE__", paras_html(cfg.get("breadth", {}).get("note")))
            .replace("__TECH__", table_html(cfg["tech"]["ma"]["head"], cfg["tech"]["ma"]["rows"], {1, 2})
                     + table_html(cfg["tech"]["ind"]["head"], cfg["tech"]["ind"]["rows"]))
            .replace("__TECH_NOTE__", cfg.get("tech", {}).get("note", ""))
            .replace("__CAPITAL_KPI__", kpi_html(cfg.get("capital", {}).get("kpi")))
            .replace("__CAPITAL_NOTE__", paras_html(cfg.get("capital", {}).get("note")))
            .replace("__STATS__", table_html(cfg["stats"]["head"], cfg["stats"]["rows"], {1, 2, 3, 4})
                     + '<div class="note">%s</div>' % cfg.get("stats", {}).get("note", ""))
            .replace("__VOLTABLE__", "".join("<tr><td>%s</td><td class=\"num\">%s</td></tr>" % (a, b)
                                             for a, b in cfg.get("vol", {}).get("rows", [])))
            .replace("__VOLNOTE__", cfg.get("vol", {}).get("note", ""))
            .replace("__SCENTABLE__", table_html(["情景", "收盘参考位", "相对现价", "概率"],
                                                 scen_rows, {1, 2, 3})
                     + paras_html(cfg.get("scen_note")))
            .replace("__LADDER__", "".join(lad))
            .replace("__EVENTS__", table_html(cfg["events"]["head"], cfg["events"]["rows"])
                     + '<div class="note">%s</div>' % cfg.get("events", {}).get("note", ""))
            .replace("__DECISIONS__", table_html(cfg["decisions"]["head"], cfg["decisions"]["rows"]))
            .replace("__RISKS__", "".join("<li>%s</li>" % r for r in cfg.get("risks", [])))
            .replace("__SOURCES__", "".join('<span class="pill">%s</span>' % s
                                            for s in cfg.get("sources", [])))
            .replace("__SEC_N__", json.dumps(sec_names, ensure_ascii=False))
            .replace("__SEC_V__", json.dumps(sec_vals))
            .replace("__DATES__", json.dumps(dates, ensure_ascii=False))
            .replace("__OHLC__", json.dumps(ohlc))
            .replace("__MA20__", json.dumps(ma20))
            .replace("__MALINE__", json.dumps(maline))
            .replace("__SCEN_L__", json.dumps(scen_labels, ensure_ascii=False))
            .replace("__SCEN_V__", json.dumps(scen_data)))

    out = args.out or cfg.get("out") or "index_forecast.html"
    with open(out, "w", encoding="utf-8") as f:
        f.write(html)
    print("WROTE %s (%d bytes)" % (out, os.path.getsize(out)))

    # --- 自检 ---
    left = re.findall(r"__[A-Z0-9_]+__", html)
    if left:
        print("!! 残留占位符:", set(left))
    else:
        print("占位符自检: 全部替换 OK")
    print("div 开=%d 闭=%d" % (html.count("<div"), html.count("</div>")))

    if not args.no_check:
        m = re.search(r"<script>\s*\n(.*?)\n</script>", html, re.DOTALL)
        if not m:
            print("!! 未找到内联 script，跳过校验")
            return
        import tempfile
        tmp = os.path.join(tempfile.gettempdir(), "_idxfc_check.js")
        with open(tmp, "w", encoding="utf-8") as tf:
            tf.write(m.group(1))
        try:
            r = subprocess.run(["node", "--check", tmp], capture_output=True, text=True, shell=True)
        except FileNotFoundError:
            print("!! 未找到 node，跳过 JS 校验（请确认 node 在 PATH 中）")
            return
        try:
            os.remove(tmp)   # 沙箱可能拦截删除，失败不影响交付
        except Exception:
            pass
        if r.returncode == 0:
            print("JS 语法校验: OK")
        else:
            print("!! JS 语法错误:\n%s\n%s" % (r.stdout, r.stderr))
            sys.exit(1)


if __name__ == "__main__":
    main()
